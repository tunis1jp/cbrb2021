/*
Run this script on:

        SQL2016SVR\R8.TdbIccNetDevR8    -  This database will be modified

to synchronize it with:

        SQL2016SVR\R8.ICCNet2020

You are recommended to back up your database before running this script

Script created by SQL Compare version 12.2.1.4077 from Red Gate Software Ltd at 2/10/2021 8:42:15 AM

*/
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL Serializable
GO
BEGIN TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[aaaDbUpdateApplied]'
GO
CREATE TABLE [dbo].[aaaDbUpdateApplied]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[DbVersion] [int] NOT NULL CONSTRAINT [DF_aaaDbUpdateApplied_DbVersion] DEFAULT ((0)),
[Description] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_aaaDbUpdateApplied_Description] DEFAULT (''),
[DateApplied] [datetime] NOT NULL CONSTRAINT [DF_aaaDbUpdateApplied_DataGenerated] DEFAULT ('1-1-1900')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_aaaDbUpdateApplied_PKey] on [dbo].[aaaDbUpdateApplied]'
GO
ALTER TABLE [dbo].[aaaDbUpdateApplied] ADD CONSTRAINT [PK_aaaDbUpdateApplied_PKey] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BankCalendar]'
GO
CREATE TABLE [dbo].[BankCalendar]
(
[BankCalendarPkey] [int] NOT NULL IDENTITY(1, 1),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BankCalendar_LegalEntity] DEFAULT (''),
[Holiday] [datetime] NOT NULL CONSTRAINT [DF_BankCalendar_Holiday] DEFAULT ('1900-01-01'),
[CalYear] [int] NOT NULL CONSTRAINT [DF_BankCalendar_CalYear] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK__BankCalendarPkey] on [dbo].[BankCalendar]'
GO
ALTER TABLE [dbo].[BankCalendar] ADD CONSTRAINT [PK__BankCalendarPkey] PRIMARY KEY CLUSTERED  ([BankCalendarPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_BankCalendar_BankCalendarPkey] on [dbo].[BankCalendar]'
GO
CREATE NONCLUSTERED INDEX [IX_BankCalendar_BankCalendarPkey] ON [dbo].[BankCalendar] ([BankCalendarPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ReportScheduler]'
GO
CREATE TABLE [dbo].[ReportScheduler]
(
[SchedulerPkey] [int] NOT NULL IDENTITY(1, 1),
[ReportFkey] [int] NOT NULL CONSTRAINT [DF_ReportScheduler_ReportFkey] DEFAULT ((0)),
[BankID] [int] NOT NULL CONSTRAINT [DF_ReportScheduler_BankID] DEFAULT ((0)),
[CustomerID] [int] NOT NULL CONSTRAINT [DF_ReportScheduler_CustomerID] DEFAULT ((0)),
[BranchID] [int] NOT NULL CONSTRAINT [DF_ReportScheduler_BranchID] DEFAULT ((0)),
[HowDelivered] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportScheduler_HowDelivered] DEFAULT (''),
[ReportFormat] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportScheduler_ReportFormat] DEFAULT (''),
[Runtime] [datetime2] NULL CONSTRAINT [DF_ReportScheduler_Runtime] DEFAULT ('1-1-1900'),
[Monday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Monday] DEFAULT ((0)),
[Tuesday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Tuesday] DEFAULT ((0)),
[Wednesday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Wednesday] DEFAULT ((0)),
[Thursday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Thursday] DEFAULT ((0)),
[Friday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Friday] DEFAULT ((0)),
[Saturday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Saturday] DEFAULT ((0)),
[Sunday] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Sunday] DEFAULT ((0)),
[QTR_First] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_QTR_First] DEFAULT ((0)),
[QTR_Last] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_QTR_Last] DEFAULT ((0)),
[MNTH_First] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_MNTH_First] DEFAULT ((0)),
[MNTH_Last] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_MNTH_Last] DEFAULT ((0)),
[Email_NoData] [bit] NOT NULL CONSTRAINT [DF_ReportScheduler_Email_NoData] DEFAULT ((0)),
[ArchiveDays] [int] NOT NULL CONSTRAINT [DF_ReportScheduler_ArchiveDays] DEFAULT ((0)),
[RptLastRun] [datetime2] NULL CONSTRAINT [DF_ReportScheduler_RptLastRun] DEFAULT ('1-1-1900'),
[TimeZone] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportScheduler_TimeZone] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_SchedulePkey] on [dbo].[ReportScheduler]'
GO
ALTER TABLE [dbo].[ReportScheduler] ADD CONSTRAINT [PK_SchedulePkey] PRIMARY KEY CLUSTERED  ([SchedulerPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ReportScheduler_SchedulerPkey] on [dbo].[ReportScheduler]'
GO
CREATE NONCLUSTERED INDEX [IX_ReportScheduler_SchedulerPkey] ON [dbo].[ReportScheduler] ([SchedulerPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LCPledgeHistory]'
GO
CREATE TABLE [dbo].[LCPledgeHistory]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_PKey] DEFAULT ((0)),
[TransPKey] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_TransPKey] DEFAULT ((0)),
[PledgeID] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_PledgeID] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_BranchId] DEFAULT ((0)),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_BankReference] DEFAULT (''),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_GtsProduct] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LCPledgeHistory_StatusDate] DEFAULT ('1/1/1900'),
[Amount] [money] NOT NULL CONSTRAINT [DF_LCPledgeHistory_Amount] DEFAULT ((0)),
[DepositorsPkey] [int] NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsPkey] DEFAULT ((0)),
[DepositorsName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsName] DEFAULT (''),
[DepositorsAddress1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsAddress1] DEFAULT (''),
[DepositorsAddress2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsAddress2] DEFAULT (''),
[DepositorsAddress3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsAddress3] DEFAULT (''),
[DepositorsPhone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsPhone] DEFAULT (''),
[DepositorsZip] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsZip] DEFAULT (''),
[DepositorsEmail] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsEmail] DEFAULT (''),
[StartDate] [datetime] NOT NULL CONSTRAINT [DF_LCPledgeHistory_Email] DEFAULT ('1/1/1900'),
[Adjustment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeHistory_Adjustment] DEFAULT (''),
[TransactionAmount] [money] NOT NULL CONSTRAINT [DF_LcPledgeHistory_TransactionAmount] DEFAULT ((0)),
[DepositorsGtsPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsGtsPartyId] DEFAULT (''),
[DepositorsAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LCPledgeHistory_DepositorsAttnLine1] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LCPledgeHistory] on [dbo].[LCPledgeHistory]'
GO
ALTER TABLE [dbo].[LCPledgeHistory] ADD CONSTRAINT [PK_LCPledgeHistory] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LCPledgeHistory_BankReference] on [dbo].[LCPledgeHistory]'
GO
CREATE NONCLUSTERED INDEX [IX_LCPledgeHistory_BankReference] ON [dbo].[LCPledgeHistory] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ReportSchedulerParms]'
GO
CREATE TABLE [dbo].[ReportSchedulerParms]
(
[ParmsPKey] [int] NOT NULL IDENTITY(1, 1),
[ReportSchedulerFKey] [int] NOT NULL CONSTRAINT [DF_ReportSchedulerParms_ReportSchedulerFKey] DEFAULT ((0)),
[FieldName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerParms_FieldName] DEFAULT (''),
[Operator] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerParms_Operator] DEFAULT (''),
[ValueForComparison] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerParms_ValueForComparison] DEFAULT (''),
[Formula] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerParms_Formula] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ReportSchedulerParms_ParmsPKeyPKey] on [dbo].[ReportSchedulerParms]'
GO
ALTER TABLE [dbo].[ReportSchedulerParms] ADD CONSTRAINT [PK_ReportSchedulerParms_ParmsPKeyPKey] PRIMARY KEY CLUSTERED  ([ParmsPKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ReportSchedulerParms_ReportSchedulerFKey] on [dbo].[ReportSchedulerParms]'
GO
CREATE NONCLUSTERED INDEX [IX_ReportSchedulerParms_ReportSchedulerFKey] ON [dbo].[ReportSchedulerParms] ([ReportSchedulerFKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ReportSchedulerAvailableFormulas]'
GO
CREATE TABLE [dbo].[ReportSchedulerAvailableFormulas]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[Category] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableFormulas_Category] DEFAULT (''),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableFormulas_GtsService] DEFAULT (''),
[FieldName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableFormulas_Prompt] DEFAULT (''),
[Description] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableFormulas_Description] DEFAULT (''),
[Formula] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableFormulas_Formula] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ReportSchedulerAvailableFormulas_PKey] on [dbo].[ReportSchedulerAvailableFormulas]'
GO
ALTER TABLE [dbo].[ReportSchedulerAvailableFormulas] ADD CONSTRAINT [PK_ReportSchedulerAvailableFormulas_PKey] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ReportSchedulerAvailableFormulas_Category_GtsService] on [dbo].[ReportSchedulerAvailableFormulas]'
GO
CREATE NONCLUSTERED INDEX [IX_ReportSchedulerAvailableFormulas_Category_GtsService] ON [dbo].[ReportSchedulerAvailableFormulas] ([Category], [GtsService]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ReportSchedulerAvailableFormulas_FieldName] on [dbo].[ReportSchedulerAvailableFormulas]'
GO
CREATE NONCLUSTERED INDEX [IX_ReportSchedulerAvailableFormulas_FieldName] ON [dbo].[ReportSchedulerAvailableFormulas] ([FieldName]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[GeneratedReports]'
GO
CREATE TABLE [dbo].[GeneratedReports]
(
[RptRecordPkey] [int] NOT NULL IDENTITY(1, 1),
[SchedulerFkey] [int] NOT NULL CONSTRAINT [DF_GeneratedReports_SchedulerFkey] DEFAULT ((0)),
[ReportName] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_GeneratedReports_ReportName] DEFAULT (''),
[ReportTextBytes] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_GeneratedReports_ReportTextBytes] DEFAULT (''),
[DateGenerated] [datetime] NOT NULL CONSTRAINT [DF_GeneratedReports_DataGenerated] DEFAULT ('1-1-1900')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_RptRecordPkey] on [dbo].[GeneratedReports]'
GO
ALTER TABLE [dbo].[GeneratedReports] ADD CONSTRAINT [PK_RptRecordPkey] PRIMARY KEY CLUSTERED  ([RptRecordPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_GeneratedReports_RptRecordPkey] on [dbo].[GeneratedReports]'
GO
CREATE NONCLUSTERED INDEX [IX_GeneratedReports_RptRecordPkey] ON [dbo].[GeneratedReports] ([RptRecordPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ReportDeliverTo]'
GO
CREATE TABLE [dbo].[ReportDeliverTo]
(
[DeliverToPkey] [int] NOT NULL IDENTITY(1, 1),
[UsersFkey] [int] NOT NULL CONSTRAINT [DF_ReportDeliverTo_UsersFkey] DEFAULT ((0)),
[BankCustomer] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportDeliverTo_BankCustomer] DEFAULT (''),
[ReportSchedulerFkey] [int] NOT NULL CONSTRAINT [DF_ReportDeliverTo_ReportSchedulerFkey] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_DeliverToPkey] on [dbo].[ReportDeliverTo]'
GO
ALTER TABLE [dbo].[ReportDeliverTo] ADD CONSTRAINT [PK_DeliverToPkey] PRIMARY KEY CLUSTERED  ([DeliverToPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ReportDeliverTo_DeliverToPkey] on [dbo].[ReportDeliverTo]'
GO
CREATE NONCLUSTERED INDEX [IX_ReportDeliverTo_DeliverToPkey] ON [dbo].[ReportDeliverTo] ([DeliverToPkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LcCertOfUtil]'
GO
CREATE TABLE [dbo].[LcCertOfUtil]
(
[PKey] [int] NOT NULL CONSTRAINT [DF__LcCertOfUt__PKey__54575F1A] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtil_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtil_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtil_BranchId] DEFAULT ((0)),
[GtsId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtil_GtsId] DEFAULT (''),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtil_BankReference] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtil_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LcCertOfUtil_StatusDate] DEFAULT ('1/1/1900'),
[StatusUserId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtil_StatusUserId] DEFAULT ((0)),
[UtilizedAmount] [money] NOT NULL CONSTRAINT [DF_LcCertOfUtil_UtilizedAmount] DEFAULT ((0)),
[AverageDailyBalance] [money] NOT NULL CONSTRAINT [DF_LcCertOfUtil_AverageDailyBalance] DEFAULT ((0)),
[CollateralizationPercentage] [float] NOT NULL CONSTRAINT [DF_LcCertOfUtil_CollateralizationPercentage] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LcCertOfUtil] on [dbo].[LcCertOfUtil]'
GO
ALTER TABLE [dbo].[LcCertOfUtil] ADD CONSTRAINT [PK_LcCertOfUtil] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LcCertOfUtil_BankReference] on [dbo].[LcCertOfUtil]'
GO
CREATE NONCLUSTERED INDEX [IX_LcCertOfUtil_BankReference] ON [dbo].[LcCertOfUtil] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPaymentAuthorization]'
GO
CREATE TABLE [dbo].[ScfPaymentAuthorization]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_PKey] DEFAULT ((0)),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_LegalEntity] DEFAULT (''),
[BankId] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_BranchId] DEFAULT ((0)),
[Division] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_Division] DEFAULT (''),
[Department] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_Department] DEFAULT (''),
[SellerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_SellerReference] DEFAULT (''),
[BuyerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_BuyerReference] DEFAULT (''),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_BankReference] DEFAULT (''),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsProduct] DEFAULT (''),
[GtsUserPKey] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsUserPKey] DEFAULT ((0)),
[GtsUserName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsUserName] DEFAULT (''),
[GtsPaymentPKey] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsPaymentPKey] DEFAULT ((0)),
[GtsWipPKey] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsWipPKey] DEFAULT ((0)),
[TypeFlag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_TypeFlag] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_StatusDate] DEFAULT ('1/1/1900'),
[StatusUserId] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_StatusUserId] DEFAULT ((0)),
[SubjectLine] [varchar] (65) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_SubjectLine] DEFAULT (''),
[DrawingAmount] [float] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_DrawingAmount] DEFAULT ((0)),
[DrawingDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_DrawingDate] DEFAULT ('1/1/1900'),
[Presenter] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_Presenter] DEFAULT (''),
[RunningText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_RunningText] DEFAULT (''),
[ResponseText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_ResponseText] DEFAULT (''),
[GTSOpenerPkey] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GTSOpenerPkey] DEFAULT ((0)),
[Response] [varchar] (72) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_Response] DEFAULT (''),
[GtsId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_GtsId] DEFAULT (''),
[ImageType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_ImageType] DEFAULT (''),
[ImageFileName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_ImageFileName] DEFAULT (''),
[ResponseCode] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_ResponseCode] DEFAULT (''),
[SellerName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_SellerName] DEFAULT (''),
[TenorDays] [int] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_TenorDays] DEFAULT ((0)),
[TenorPhrase] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_TenorPhrase] DEFAULT (''),
[POADate] [datetime] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_POADate] DEFAULT ('1/1/1900'),
[AmountOutstanding] [float] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_AmountOutstanding] DEFAULT ((0)),
[AmountOutstandingBase] [float] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_AmountOutstandingBase] DEFAULT ((0)),
[BankCharges] [float] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_BankCharges] DEFAULT ((0)),
[SellerCharges] [float] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_SellerCharges] DEFAULT ((0)),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_MaturityDate] DEFAULT ('1/1/1900'),
[PresBankChargesWaivable] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_PresBankChargesWaivable] DEFAULT (''),
[OurBankChargesWaivable] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_OurBankChargesWaivable] DEFAULT (''),
[DocumentDisposition] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_DocumentDisposition] DEFAULT (''),
[PresBankChargesWaived] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_PresBankChargesWaived] DEFAULT (''),
[OurBankChargesWaived] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPaymentAuthorization_OurBankChargesWaived] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ScfPaymentAuthorization] on [dbo].[ScfPaymentAuthorization]'
GO
ALTER TABLE [dbo].[ScfPaymentAuthorization] ADD CONSTRAINT [PK_ScfPaymentAuthorization] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ScfPaymentAuthorization_BankReference] on [dbo].[ScfPaymentAuthorization]'
GO
CREATE NONCLUSTERED INDEX [IX_ScfPaymentAuthorization_BankReference] ON [dbo].[ScfPaymentAuthorization] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ScfPaymentAuthorization_BuyerReference] on [dbo].[ScfPaymentAuthorization]'
GO
CREATE NONCLUSTERED INDEX [IX_ScfPaymentAuthorization_BuyerReference] ON [dbo].[ScfPaymentAuthorization] ([BuyerReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ScfPaymentAuthorization_SellerReference] on [dbo].[ScfPaymentAuthorization]'
GO
CREATE NONCLUSTERED INDEX [IX_ScfPaymentAuthorization_SellerReference] ON [dbo].[ScfPaymentAuthorization] ([SellerReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[xxxBondPurpose]'
GO
CREATE TABLE [dbo].[xxxBondPurpose]
(
[PKeyIdentity] [int] NOT NULL IDENTITY(1, 1),
[BankId] [int] NOT NULL CONSTRAINT [DF_xxxBondPurpose_BankId] DEFAULT ((1)),
[Code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxBondPurpose_Code] DEFAULT (''),
[Description] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxBondPurpose_Description] DEFAULT (''),
[Active] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxBondPurpose_Active] DEFAULT ('Y'),
[OrderBy] [int] NOT NULL CONSTRAINT [DF_xxxBondPurpose_OrderBy] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_xxxBondPurpose] on [dbo].[xxxBondPurpose]'
GO
ALTER TABLE [dbo].[xxxBondPurpose] ADD CONSTRAINT [PK_xxxBondPurpose] PRIMARY KEY CLUSTERED  ([PKeyIdentity]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LcPledgeEntry]'
GO
CREATE TABLE [dbo].[LcPledgeEntry]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_Pkey] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_BranchId] DEFAULT ((0)),
[GtsId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_GtsId] DEFAULT (''),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_BankReference] DEFAULT (''),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_GtsProduct] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LcPledgeEntry_StatusDate] DEFAULT ('1/1/1900'),
[StatusUserId] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_StatusUserId] DEFAULT ((0)),
[Amount] [money] NOT NULL CONSTRAINT [DF_LcPledgeEntry_Amount] DEFAULT ((0)),
[DepositorsPkey] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_DepositorsPkey] DEFAULT ((0)),
[DepositorsEmail] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_DepositorsEmail] DEFAULT (''),
[StartDate] [datetime] NOT NULL CONSTRAINT [DF_LcPledgeEntry_Email] DEFAULT ('1/1/1900'),
[Notes] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeEntry_Notes] DEFAULT (''),
[PledgeId] [int] NOT NULL CONSTRAINT [DF_LcPledgeEntry_PledgeId] DEFAULT ((0))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LcPledgeEntry] on [dbo].[LcPledgeEntry]'
GO
ALTER TABLE [dbo].[LcPledgeEntry] ADD CONSTRAINT [PK_LcPledgeEntry] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LcPledgeEntry_BankReference] on [dbo].[LcPledgeEntry]'
GO
CREATE NONCLUSTERED INDEX [IX_LcPledgeEntry_BankReference] ON [dbo].[LcPledgeEntry] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[xxxRatingAgency]'
GO
CREATE TABLE [dbo].[xxxRatingAgency]
(
[PKeyIdentity] [int] NOT NULL IDENTITY(1, 1),
[BankId] [int] NOT NULL CONSTRAINT [DF_xxxRatingAgency_BankId] DEFAULT ((1)),
[Code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxRatingAgency_Code] DEFAULT (''),
[Description] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxRatingAgency_Description] DEFAULT (''),
[Active] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxRatingAgency_Active] DEFAULT ('Y'),
[OrderBy] [int] NOT NULL CONSTRAINT [DF_xxxRatingAgency_OrderBy] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_xxxRatingAgency] on [dbo].[xxxRatingAgency]'
GO
ALTER TABLE [dbo].[xxxRatingAgency] ADD CONSTRAINT [PK_xxxRatingAgency] PRIMARY KEY CLUSTERED  ([PKeyIdentity]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FHLFeeCharges]'
GO
CREATE TABLE [dbo].[FHLFeeCharges]
(
[PKeyIdentity] [int] NOT NULL IDENTITY(1, 1),
[ApplicationPKey] [int] NOT NULL CONSTRAINT [DF_FHLFeeCharges_ApplicationPKey] DEFAULT ((0)),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_FHLFeeCharges_StatusDate] DEFAULT ('1/1/1900'),
[AnnualRate] [float] NOT NULL CONSTRAINT [DF_FHLFeeCharges_AnnualRate] DEFAULT ((0)),
[FeeAmount] [float] NOT NULL CONSTRAINT [DF_FHLFeeCharges_FeeAmount] DEFAULT ((0)),
[FeeDescription] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLFeeCharges_FeeDescription] DEFAULT (''),
[FeeEndDate] [datetime] NOT NULL CONSTRAINT [DF_FHLFeeCharges_FeeEndDate] DEFAULT ('1/1/1900'),
[FeeName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLFeeCharges_FeeName] DEFAULT (''),
[FeePKey] [int] NOT NULL CONSTRAINT [DF_FHLFeeCharges_FeePKey] DEFAULT ((0)),
[FeeStartDate] [datetime] NOT NULL CONSTRAINT [DF_FHLFeeCharges_FeeStartDate] DEFAULT ('1/1/1900')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_FHLFeeCharges] on [dbo].[FHLFeeCharges]'
GO
ALTER TABLE [dbo].[FHLFeeCharges] ADD CONSTRAINT [PK_FHLFeeCharges] PRIMARY KEY CLUSTERED  ([PKeyIdentity]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_FHLFeeCharges_ApplicationPKey] on [dbo].[FHLFeeCharges]'
GO
CREATE NONCLUSTERED INDEX [IX_FHLFeeCharges_ApplicationPKey] ON [dbo].[FHLFeeCharges] ([ApplicationPKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[AffiliateBanks]'
GO
CREATE TABLE [dbo].[AffiliateBanks]
(
[AffiliatePkey] [int] NOT NULL IDENTITY(1, 1),
[AffiliateName] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_AffiliateBanks_AffiliateName] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK__AffiliatePkey] on [dbo].[AffiliateBanks]'
GO
ALTER TABLE [dbo].[AffiliateBanks] ADD CONSTRAINT [PK__AffiliatePkey] PRIMARY KEY CLUSTERED  ([AffiliatePkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[xxxFinanceType]'
GO
CREATE TABLE [dbo].[xxxFinanceType]
(
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxFinanceType_LegalEntity] DEFAULT (''),
[BankId] [int] NOT NULL CONSTRAINT [DF_xxxFinanceType_BankId] DEFAULT ((1)),
[Code] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxFinanceType_Code] DEFAULT (''),
[Description] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxFinanceType_Description] DEFAULT (''),
[Active] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxFinanceType_Active] DEFAULT (''),
[OrderBy] [int] NOT NULL CONSTRAINT [DF_xxxFinanceType_OrderBy] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_xxxFinanceType] on [dbo].[xxxFinanceType]'
GO
ALTER TABLE [dbo].[xxxFinanceType] ADD CONSTRAINT [PK_xxxFinanceType] PRIMARY KEY CLUSTERED  ([LegalEntity], [Code]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_xxxFinanceType_Description] on [dbo].[xxxFinanceType]'
GO
CREATE NONCLUSTERED INDEX [IX_xxxFinanceType_Description] ON [dbo].[xxxFinanceType] ([Description]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LcPledgeMod]'
GO
CREATE TABLE [dbo].[LcPledgeMod]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_Pkey] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_BranchId] DEFAULT ((0)),
[GtsId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeMod_GtsId] DEFAULT (''),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeMod_BankReference] DEFAULT (''),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeMod_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeMod_GtsProduct] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeMod_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LcPledgeMod_StatusDate] DEFAULT ('1/1/1900'),
[StatusUserId] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_StatusUserId] DEFAULT ((0)),
[Amount] [money] NOT NULL CONSTRAINT [DF_LcPledgeMod_Amount] DEFAULT ((0)),
[DepositorsPkey] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_DepositorsPkey] DEFAULT ((0)),
[DepositorsEmail] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeMod_DepositorsEmail] DEFAULT (''),
[StartDate] [datetime] NOT NULL CONSTRAINT [DF_LcPledgeMod_Email] DEFAULT ('1/1/1900'),
[Adjustment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LcPledgeMod_Adjustment] DEFAULT (''),
[PledgeId] [int] NOT NULL CONSTRAINT [DF_LcPledgeMod_PledgeId] DEFAULT ((0)),
[Notes] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeMod_Notes] DEFAULT (''),
[DepositorsGtsPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeMod_DepositorsGtsPartyId] DEFAULT (''),
[DepositorsAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LCPledgeMod_DepositorsAttnLine1] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LcPledgeMod] on [dbo].[LcPledgeMod]'
GO
ALTER TABLE [dbo].[LcPledgeMod] ADD CONSTRAINT [PK_LcPledgeMod] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LcPledgeMod_BankReference] on [dbo].[LcPledgeMod]'
GO
CREATE NONCLUSTERED INDEX [IX_LcPledgeMod_BankReference] ON [dbo].[LcPledgeMod] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LcCertOfUtilBalance]'
GO
CREATE TABLE [dbo].[LcCertOfUtilBalance]
(
[PKey] [int] NOT NULL CONSTRAINT [DF__LcCertOfUt__PKey__007FFA1B] DEFAULT ((0)),
[TransPKey] [int] NOT NULL CONSTRAINT [DF__LcCertOfU__Trans__01741E54] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_BranchId] DEFAULT ((0)),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_BankReference] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_StatusDate] DEFAULT ('1/1/1900'),
[UtilizedAmount] [money] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_UtilizedAmount] DEFAULT ((0)),
[AverageDailyBalance] [money] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_AverageDailyBalance] DEFAULT ((0)),
[CollateralizationPercentage] [float] NOT NULL CONSTRAINT [DF_LcCertOfUtilBalance_CollateralizationPercentage] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LcCertOfUtilBalance] on [dbo].[LcCertOfUtilBalance]'
GO
ALTER TABLE [dbo].[LcCertOfUtilBalance] ADD CONSTRAINT [PK_LcCertOfUtilBalance] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LcCertOfUtilBalance_BankReference] on [dbo].[LcCertOfUtilBalance]'
GO
CREATE NONCLUSTERED INDEX [IX_LcCertOfUtilBalance_BankReference] ON [dbo].[LcCertOfUtilBalance] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[SCFApplication]'
GO
CREATE TABLE [dbo].[SCFApplication]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_SCFApplication_PKey] DEFAULT ((0)),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_LegalEntity] DEFAULT (''),
[BankId] [int] NOT NULL CONSTRAINT [DF_SCFApplication_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_SCFApplication_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_SCFApplication_BranchId] DEFAULT ((0)),
[GtsId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_GtsId] DEFAULT (''),
[SellerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_SellerReference] DEFAULT (''),
[BuyerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_BuyerReference] DEFAULT (''),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_BankReference] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_SCFApplication_StatusDate] DEFAULT ('1/1/1900'),
[StatusUserId] [int] NOT NULL CONSTRAINT [DF_SCFApplication_StatusUserId] DEFAULT ((0)),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_GtsProduct] DEFAULT (''),
[SellerPkey] [int] NOT NULL CONSTRAINT [DF_SCFApplication_SellerPkey] DEFAULT ((0)),
[BuyerPkey] [int] NOT NULL CONSTRAINT [DF_SCFApplication_BuyerPkey] DEFAULT ((0)),
[OriginalAmount] [float] NOT NULL CONSTRAINT [DF_SCFApplication_OriginalAmount] DEFAULT ((0)),
[OriginalAmountBase] [float] NOT NULL CONSTRAINT [DF_SCFApplication_OriginalAmountBase] DEFAULT ((0)),
[CurrencyCode] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_CurrencyCode] DEFAULT (''),
[DocumentDate] [datetime] NOT NULL CONSTRAINT [DF_SCFApplication_DocumentDate] DEFAULT ('1/1/1900'),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_SCFApplication_MaturityDate] DEFAULT ('1/1/1900'),
[TenorDays] [int] NOT NULL CONSTRAINT [DF_SCFApplication_TenorDays] DEFAULT ((0)),
[TenorPhrase] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_TenorPhrase] DEFAULT (''),
[FixedDate] [datetime] NOT NULL CONSTRAINT [DF_SCFApplication_FixedDate] DEFAULT ('1/1/1900'),
[TenorSelected] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_TenorSelected] DEFAULT (''),
[OtherTenor] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_OtherTenor] DEFAULT (''),
[FinanceType] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_FinanceType] DEFAULT (''),
[SpecialInstructions] [varchar] (216) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SCFApplication_SpecialInstructions] DEFAULT (''),
[Notes] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfApplication_Notes] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_SCFApplication] on [dbo].[SCFApplication]'
GO
ALTER TABLE [dbo].[SCFApplication] ADD CONSTRAINT [PK_SCFApplication] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_SCFApplication_BankReference] on [dbo].[SCFApplication]'
GO
CREATE NONCLUSTERED INDEX [IX_SCFApplication_BankReference] ON [dbo].[SCFApplication] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_SCFApplication_BuyerReference] on [dbo].[SCFApplication]'
GO
CREATE NONCLUSTERED INDEX [IX_SCFApplication_BuyerReference] ON [dbo].[SCFApplication] ([BuyerReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_SCFApplication_SellerReference] on [dbo].[SCFApplication]'
GO
CREATE NONCLUSTERED INDEX [IX_SCFApplication_SellerReference] ON [dbo].[SCFApplication] ([SellerReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[xxxPurposeOfStandby]'
GO
CREATE TABLE [dbo].[xxxPurposeOfStandby]
(
[PKeyIdentity] [int] NOT NULL IDENTITY(1, 1),
[BankId] [int] NOT NULL CONSTRAINT [DF_xxxPurposeOfStandby_BankId] DEFAULT ((1)),
[Code] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxPurposeOfStandby_Code] DEFAULT (''),
[Description] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxPurposeOfStandby_Description] DEFAULT (''),
[Active] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxPurposeOfStandby_Active] DEFAULT ('Y'),
[OrderBy] [int] NOT NULL CONSTRAINT [DF_xxxPurposeOfStandby_OrderBy] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_xxxPurposeOfStandby] on [dbo].[xxxPurposeOfStandby]'
GO
ALTER TABLE [dbo].[xxxPurposeOfStandby] ADD CONSTRAINT [PK_xxxPurposeOfStandby] PRIMARY KEY CLUSTERED  ([PKeyIdentity]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LcCertOfUtilHistory]'
GO
CREATE TABLE [dbo].[LcCertOfUtilHistory]
(
[PKey] [int] NOT NULL CONSTRAINT [DF__LcCertOfUt__PKey__0AFD888E] DEFAULT ((0)),
[TransPKey] [int] NOT NULL CONSTRAINT [DF__LcCertOfU__Trans__0BF1ACC7] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_BranchId] DEFAULT ((0)),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_BankReference] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_StatusDate] DEFAULT ('1/1/1900'),
[UtilizedAmount] [money] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_UtilizedAmount] DEFAULT ((0)),
[AverageDailyBalance] [money] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_AverageDailyBalance] DEFAULT ((0)),
[CollateralizationPercentage] [float] NOT NULL CONSTRAINT [DF_LcCertOfUtilHistory_CollateralizationPercentage] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LcCertOfUtilHistory] on [dbo].[LcCertOfUtilHistory]'
GO
ALTER TABLE [dbo].[LcCertOfUtilHistory] ADD CONSTRAINT [PK_LcCertOfUtilHistory] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LcCertOfUtilHistory_BankReference] on [dbo].[LcCertOfUtilHistory]'
GO
CREATE NONCLUSTERED INDEX [IX_LcCertOfUtilHistory_BankReference] ON [dbo].[LcCertOfUtilHistory] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[UserAgreementFiles]'
GO
CREATE TABLE [dbo].[UserAgreementFiles]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementFiles_GtsService] DEFAULT (''),
[DisplayName] [varchar] (75) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementFiles_DisplayName] DEFAULT (''),
[FileName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementFiles_FileName] DEFAULT (''),
[FileData] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementFiles_FileData] DEFAULT (''),
[AddedOnDate] [datetime] NOT NULL CONSTRAINT [DF_UserAgreementFiles_AddedOnDate] DEFAULT (((1)/(1))/(1900)),
[AddedBy] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementFiles_AddedBy] DEFAULT (''),
[Active] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [UserAgreementFiles_Active] DEFAULT ('Y'),
[OrderBy] [int] NOT NULL CONSTRAINT [UserAgreementFiles_OrderBy] DEFAULT ((0))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_UserAgreementFiles_PKey] on [dbo].[UserAgreementFiles]'
GO
ALTER TABLE [dbo].[UserAgreementFiles] ADD CONSTRAINT [PK_UserAgreementFiles_PKey] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_UserAgreementFiles_GtsService] on [dbo].[UserAgreementFiles]'
GO
CREATE NONCLUSTERED INDEX [IX_UserAgreementFiles_GtsService] ON [dbo].[UserAgreementFiles] ([GtsService]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfHistoryBalance]'
GO
CREATE TABLE [dbo].[ScfHistoryBalance]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_PKey] DEFAULT ((0)),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_LegalEntity] DEFAULT (''),
[BankId] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BranchId] DEFAULT ((0)),
[GtsPKey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_GtsPKey] DEFAULT ((0)),
[FlagBH] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_FlagBH] DEFAULT (''),
[SellerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerReference] DEFAULT (''),
[BuyerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerReference] DEFAULT (''),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BankReference] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_StatusDate] DEFAULT ('1/1/1900'),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_GtsProduct] DEFAULT (''),
[TranType] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_TranType] DEFAULT (''),
[TranDate] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_TranDate] DEFAULT ('1/1/1900'),
[TransactionAmount] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_TransactionAmount] DEFAULT ((0)),
[TransactionAmountBase] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_TransactionAmountBase] DEFAULT ((0)),
[SellerPkey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerPkey] DEFAULT ((0)),
[SellerId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerId] DEFAULT (''),
[BuyerPkey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerPkey] DEFAULT ((0)),
[BuyerId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerId] DEFAULT (''),
[OriginalAmount] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_OriginalAmount] DEFAULT ((0)),
[OriginalAmountBase] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_OriginalAmountBase] DEFAULT ((0)),
[AmountOutstanding] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_AmountOutstanding] DEFAULT ((0)),
[AmountOutstandingBase] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_AmountOutstandingBase] DEFAULT ((0)),
[CurrencyCode] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_CurrencyCode] DEFAULT (''),
[EntryDate] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_EntryDate] DEFAULT ('1/1/1900'),
[DocumentDate] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_DocumentDate] DEFAULT ('1/1/1900'),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_MaturityDate] DEFAULT ('1/1/1900'),
[DateAccepted] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_DateAccepted] DEFAULT ('1/1/1900'),
[TenorDays] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_TenorDays] DEFAULT ((0)),
[TenorPhrase] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_TenorPhrase] DEFAULT (''),
[FinanceType] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_FinanceType] DEFAULT (''),
[LastPaymentDate] [datetime] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_LastPaymentDate] DEFAULT ('1/1/1900'),
[LastPaymentAmount] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_LastPaymentAmount] DEFAULT ((0)),
[LastPaymentAmountBase] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_LastPaymentAmountBase] DEFAULT ((0)),
[AmountCollected] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_AmountCollected] DEFAULT ((0)),
[ChargesDeducted] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_ChargesDeducted] DEFAULT ((0)),
[DisburseAmount] [float] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_DisburseAmount] DEFAULT ((0)),
[SellerIccPKey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerIccPKey] DEFAULT ((0)),
[SellerGtsPKey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerGtsPKey] DEFAULT ((0)),
[SellerGtsPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerGtsPartyId] DEFAULT (''),
[SellerIccPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerIccPartyId] DEFAULT (''),
[SellerLegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerLegalEntity] DEFAULT (''),
[SellerName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerName] DEFAULT (''),
[SellerAddress1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerAddress1] DEFAULT (''),
[SellerAddress2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerAddress2] DEFAULT (''),
[SellerAddress3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerAddress3] DEFAULT (''),
[SellerAddress4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerAddress4] DEFAULT (''),
[SellerCountryCode] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerCountryCode] DEFAULT (''),
[SellerCity] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerCity] DEFAULT (''),
[SellerState] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerState] DEFAULT (''),
[SellerPostalCode] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_SellerPostalCode] DEFAULT (''),
[BuyerIccPKey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerIccPKey] DEFAULT ((0)),
[BuyerGtsPKey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerGtsPKey] DEFAULT ((0)),
[BuyerGtsPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerGtsPartyId] DEFAULT (''),
[BuyerIccPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerIccPartyId] DEFAULT (''),
[BuyerLegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerLegalEntity] DEFAULT (''),
[BuyerName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerName] DEFAULT (''),
[BuyerAddress1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerAddress1] DEFAULT (''),
[BuyerAddress2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerAddress2] DEFAULT (''),
[BuyerAddress3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerAddress3] DEFAULT (''),
[BuyerAddress4] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerAddress4] DEFAULT (''),
[BuyerCountryCode] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerCountryCode] DEFAULT (''),
[BuyerCity] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerCity] DEFAULT (''),
[BuyerState] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerState] DEFAULT (''),
[BuyerPostalCode] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfHistoryBalance_BuyerPostalCode] DEFAULT (''),
[ApplicationPkey] [int] NOT NULL CONSTRAINT [DF_ScfHistoryBalance_ApplicationPkey] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ScfHistoryBalance] on [dbo].[ScfHistoryBalance]'
GO
ALTER TABLE [dbo].[ScfHistoryBalance] ADD CONSTRAINT [PK_ScfHistoryBalance] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ScfHistoryBalance_BankReference] on [dbo].[ScfHistoryBalance]'
GO
CREATE NONCLUSTERED INDEX [IX_ScfHistoryBalance_BankReference] ON [dbo].[ScfHistoryBalance] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ScfHistoryBalance_BuyerReference] on [dbo].[ScfHistoryBalance]'
GO
CREATE NONCLUSTERED INDEX [IX_ScfHistoryBalance_BuyerReference] ON [dbo].[ScfHistoryBalance] ([BuyerReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ScfHistoryBalance_SellerReference] on [dbo].[ScfHistoryBalance]'
GO
CREATE NONCLUSTERED INDEX [IX_ScfHistoryBalance_SellerReference] ON [dbo].[ScfHistoryBalance] ([SellerReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[UserAgreementTracking]'
GO
CREATE TABLE [dbo].[UserAgreementTracking]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[UserPKey] [int] NOT NULL CONSTRAINT [DF_UserAgreementTracking_UserPKey] DEFAULT ((0)),
[AgreementFilePKey] [int] NOT NULL CONSTRAINT [DF_UserAgreementTracking_AgreementFilePKey] DEFAULT ((0)),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementTracking_GtsService] DEFAULT (''),
[UserEntitled] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementTracking_UserEntitled] DEFAULT ('N'),
[AgreementVerified] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementTracking_AgreementVerified] DEFAULT ('N'),
[VerifiedDate] [datetime] NOT NULL CONSTRAINT [DF_UserAgreementTracking_VerifiedDate] DEFAULT (((1)/(1))/(1900))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_UserAgreementTracking_PKey] on [dbo].[UserAgreementTracking]'
GO
ALTER TABLE [dbo].[UserAgreementTracking] ADD CONSTRAINT [PK_UserAgreementTracking_PKey] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_UserAgreementTracking_AgreementFilePKey] on [dbo].[UserAgreementTracking]'
GO
CREATE NONCLUSTERED INDEX [IX_UserAgreementTracking_AgreementFilePKey] ON [dbo].[UserAgreementTracking] ([AgreementFilePKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_UserAgreementTracking_GtsService] on [dbo].[UserAgreementTracking]'
GO
CREATE NONCLUSTERED INDEX [IX_UserAgreementTracking_GtsService] ON [dbo].[UserAgreementTracking] ([GtsService]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_UserAgreementTracking_UserPKey] on [dbo].[UserAgreementTracking]'
GO
CREATE NONCLUSTERED INDEX [IX_UserAgreementTracking_UserPKey] ON [dbo].[UserAgreementTracking] ([UserPKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LCPledgeBalance]'
GO
CREATE TABLE [dbo].[LCPledgeBalance]
(
[PKey] [int] NOT NULL CONSTRAINT [DF_LcPledgeBalance_PKey] DEFAULT ((0)),
[TransPKey] [int] NOT NULL CONSTRAINT [DF_LcPledgeBalance_TransPKey] DEFAULT ((0)),
[PledgeID] [int] NOT NULL CONSTRAINT [DF_LcPledgeBalance_PledgeId] DEFAULT ((0)),
[BankId] [int] NOT NULL CONSTRAINT [DF_LCPledgeBalance_BankId] DEFAULT ((1)),
[CustomerId] [int] NOT NULL CONSTRAINT [DF_LCPledgeBalance_CustomerId] DEFAULT ((0)),
[BranchId] [int] NOT NULL CONSTRAINT [DF_LCPledgeBalance_BranchId] DEFAULT ((0)),
[BankReference] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_BankReference] DEFAULT (''),
[GtsService] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_GtsService] DEFAULT (''),
[GtsProduct] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_GtsProduct] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_Status] DEFAULT (''),
[StatusDate] [datetime] NOT NULL CONSTRAINT [DF_LCPledgeBalance_StatusDate] DEFAULT ('1/1/1900'),
[Amount] [money] NOT NULL CONSTRAINT [DF_LCPledgeBalance_Amount] DEFAULT ((0)),
[DepositorsPkey] [int] NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsPkey] DEFAULT ((0)),
[DepositorsName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsName] DEFAULT (''),
[DepositorsAddress1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsAddress1] DEFAULT (''),
[DepositorsAddress2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsAddress2] DEFAULT (''),
[DepositorsAddress3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsAddress3] DEFAULT (''),
[DepositorsPhone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsPhone] DEFAULT (''),
[DepositorsZip] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsZip] DEFAULT (''),
[DepositorsEmail] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsEmail] DEFAULT (''),
[StartDate] [datetime] NOT NULL CONSTRAINT [DF_LCPledgeBalance_Email] DEFAULT ('1/1/1900'),
[Adjustment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcPledgeBalance_Adjustment] DEFAULT (''),
[TransactionAmount] [money] NOT NULL CONSTRAINT [DF_LcPledgeBalance_TransactionAmount] DEFAULT ((0)),
[DepositorsGtsPartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsGtsPartyId] DEFAULT (''),
[DepositorsAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LCPledgeBalance_DepositorsAttnLine1] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LCPledgeBalance] on [dbo].[LCPledgeBalance]'
GO
ALTER TABLE [dbo].[LCPledgeBalance] ADD CONSTRAINT [PK_LCPledgeBalance] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_LCPledgeBalance_BankReference] on [dbo].[LCPledgeBalance]'
GO
CREATE NONCLUSTERED INDEX [IX_LCPledgeBalance_BankReference] ON [dbo].[LCPledgeBalance] ([BankReference]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[UserAgreementControl]'
GO
CREATE TABLE [dbo].[UserAgreementControl]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementControl_GtsService] DEFAULT (''),
[Description] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementControl_Description] DEFAULT (''),
[Enabled] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_UserAgreementControl_Enabled] DEFAULT ('N')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_UserAgreementControl_PKey] on [dbo].[UserAgreementControl]'
GO
ALTER TABLE [dbo].[UserAgreementControl] ADD CONSTRAINT [PK_UserAgreementControl_PKey] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_UserAgreementControl_GtsService] on [dbo].[UserAgreementControl]'
GO
CREATE NONCLUSTERED INDEX [IX_UserAgreementControl_GtsService] ON [dbo].[UserAgreementControl] ([GtsService]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ReportSchedulerAvailableParms]'
GO
CREATE TABLE [dbo].[ReportSchedulerAvailableParms]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[Category] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableParms_Category] DEFAULT (''),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableParms_GtsService] DEFAULT (''),
[FieldName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableParms_Prompt] DEFAULT (''),
[FieldType] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableParms_FieldType] DEFAULT (''),
[FieldLength] [int] NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableParms_FieldLength] DEFAULT ((0)),
[Description] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ReportSchedulerAvailableParms_Description] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ReportSchedulerAvailableParms_PKey] on [dbo].[ReportSchedulerAvailableParms]'
GO
ALTER TABLE [dbo].[ReportSchedulerAvailableParms] ADD CONSTRAINT [PK_ReportSchedulerAvailableParms_PKey] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_ReportSchedulerAvailableParms_Category_GtsService] on [dbo].[ReportSchedulerAvailableParms]'
GO
CREATE NONCLUSTERED INDEX [IX_ReportSchedulerAvailableParms_Category_GtsService] ON [dbo].[ReportSchedulerAvailableParms] ([Category], [GtsService]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
COMMIT TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
DECLARE @Success AS BIT
SET @Success = 1
SET NOEXEC OFF
IF (@Success = 1) PRINT 'The database update succeeded'
ELSE BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
	PRINT 'The database update failed'
END
GO