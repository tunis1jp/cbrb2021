﻿function CheckAll(master) {
    var iCnt;
    var checked = master.checked;
    
    chkRpts = document.getElementsByName("chkReports");
	iCnt = chkRpts.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        chkRpts[iIdx].checked = checked;
    }
}
