--Create Report and TaskStatus record for FeesCollected Report
Declare @Name varchar (50)
Declare @ProgName varchar (50)
declare @ListName varchar(50)
Declare @Description varchar(50)


set @Name = 'RPT_MIS_FeesCollectedBrowse'
set @ProgName = 'RPT_MIS_FeesCollectedBrowse.exe'
set @ListName = 'Fees Collected Report'
set @Description = 'Fees Collected Report'


if not exists (select * from Reports where SaveName = @Name)
begin
	INSERT [dbo].[Reports] ([ListName], [Description], [Frequency], [ReportDay], [Printer], [DistributionList], [Directory], [SaveName], [TimeOfDay], [Program], [ProgName], [ReportGroup], [Active], [FontSize], [OutputType], [PrintOrientation], [FirstPageHL], [NextPageHL]) VALUES (@Description, @ListName, N'O', 1, N'', N'', N'MIS', @Name, N'', 1, N'', N'MISC', 1, 7, N'PDF', N'L', 0, 0)
	Print 'Successfully added report record for SaveName: ' + @Name
end
else
begin
	print 'Report Record already exists for SaveName: ' + @Name
end
if not exists (select * from TaskStatus where Executable = @ProgName)
begin
	INSERT [dbo].[TaskStatus] ([Task], [StartTime], [StopTime], [LastProcessDate], [RunTime], [Status], [OrderField], [FailedValue], [FailedLE], [Restart], [Export], [Report], [OrderFieldType], [ErrorDescription], [ReferenceNumber], [AllowedStepFails], [OnDemand], [Executable], [Param1], [Param2], [Param3], [UpdateStatus], [TimeStarted], [BatchProcess], [FormDisplay], [Program], [TaskCanBeSkipped], [ParentTask], [TaskRestarted], [RerunPeriod], [kdkd]) VALUES (@Name, N'     ', N'     ', CAST(N'1900-01-01T00:00:00.000' AS DateTime), N'3', 0, N'', N'', N'', 0, 0, 1, N'', N'', N'', N'', N'N', @ProgName, N'Y', N'', N'', 1, CAST(N'1900-01-01T00:00:00.000' AS DateTime), 0, 0, 0, 1, 0, 0, 0, 0)
	Print 'Successfully added TaskStatus record for Executable: ' + @ProgName
end
else
begin
	print 'TaskStatus Record already exists for Executable: ' + @ProgName
end