BEGIN TRY
	BEGIN TRAN
Update AR
set ar.Title = Case 	
	when R.GroupLevelEntKey = 'DIR' then  iif(AR.Title like '%Direct Collections%', ar.Title, 'Direct Collections ' + ar.Title)
	when R.GroupLevelEntKey = 'CEX' then  iif(AR.Title like '%Export Collections%', ar.Title, 'Export Collections ' + ar.Title)
	when R.GroupLevelEntKey = 'CIM' then  iif(AR.Title like '%Incoming Collections%', ar.Title, 'Incoming Collections ' + ar.Title)
	when R.GroupLevelEntKey = 'IMP' then  iif(AR.Title like '%Import%', ar.Title, 'Import ' + ar.Title)
	when R.GroupLevelEntKey = 'EXP' then  iif(AR.Title like '%Export%', ar.Title, 'Export ' + ar.Title)
	when R.GroupLevelEntKey = 'STB' then  iif(AR.Title like '%Standby%', ar.Title, 'Standby ' + ar.Title)
end
from ActiveReports AR
inner join Reports R on R.Pkey = AR.ReportsPKey
where R.GroupLevelEntKey in ('STB','IMP','EXP','DIR','CEX','CIM')
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH