DECLARE @Category varchar(50)
DECLARE @GtsService varchar(4)
DECLARE @FieldName varchar(100)
DECLARE @FieldType varchar(1)
DECLARE @FieldLength int
DECLARE @Description varchar(50)

/* ---------------------------------------------------------------- */
/* The following are all for the ColBalance category */
/* ---------------------------------------------------------------- */
SET @Category = 'ColBalance'
SET @GtsService = ''
SET @FieldName = 'MaturityDate'
SET @FieldType = 'D'
SET @FieldLength = 10
SET @Description = 'Maturity Date'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'BankReference'
SET @FieldType = 'S'
SET @FieldLength = 8
SET @Description = 'Bank Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'DrweName'
SET @FieldType = 'S'
SET @FieldLength = 35
SET @Description = 'Drawee Name'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'DrwrName'
SET @FieldType = 'S'
SET @FieldLength = 35
SET @Description = 'Drawer Name'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'DrweCountries.Name'
SET @FieldType = 'S'
SET @FieldLength = 50
SET @Description = 'Drawee Country'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'DrwrCountries.Name'
SET @FieldType = 'S'
SET @FieldLength = 50
SET @Description = 'Drawer Country'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'RemitterReference'
SET @FieldType = 'S'
SET @FieldLength = 25
SET @Description = 'Drawer Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END
