/* ******************************************* */
/* xxxRatingAgency */
/* ******************************************* */
IF NOT EXISTS (SELECT *
           FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_TYPE='BASE TABLE' 
           AND TABLE_NAME='xxxRatingAgency') BEGIN
	CREATE TABLE xxxRatingAgency(
		PKeyIdentity int IDENTITY(1,1) NOT NULL,
		BankId int NOT NULL CONSTRAINT DF_xxxRatingAgency_BankId DEFAULT (1),
		Code varchar(4) NOT NULL CONSTRAINT DF_xxxRatingAgency_Code DEFAULT (''),
		Description varchar(25) NOT NULL CONSTRAINT DF_xxxRatingAgency_Description DEFAULT (''),
		Active varchar(1) NOT NULL CONSTRAINT DF_xxxRatingAgency_Active DEFAULT ('Y'),
		OrderBy int NOT NULL CONSTRAINT DF_xxxRatingAgency_OrderBy DEFAULT (0)
	);
	
	ALTER TABLE xxxRatingAgency ADD 
		CONSTRAINT PK_xxxRatingAgency PRIMARY KEY  CLUSTERED 
		(
			PKeyIdentity ASC
		);
	
	print 'Created xxxRatingAgency table'
END
ELSE BEGIN
	print 'xxxRatingAgency table already exists in this DB'
END

