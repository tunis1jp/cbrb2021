DECLARE @TypeId int
DECLARE @AppType varchar(15)
DECLARE @Clause_Type varchar(10)
DECLARE @Description varchar(25)
DECLARE @Columns int
DECLARE @Lines int

SET @AppType = 'STBENT'

/******************************************************/
/* 45C Document and Presentation Instructions 100x65z */
/******************************************************/
set @TypeId = 121
SET @Clause_Type = 'DOCPRESINS'
SET @Description = 'Presentation Instructions'
SET @Columns = 65
SET @Lines = 100

IF NOT EXISTS (SELECT TypeId FROM ClauseTypes WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)) BEGIN
	INSERT ClauseTypes (TypeId, AppType, Clause_Type, Description, Columns, Lines) 
		VALUES (@TypeId, @AppType, @Clause_Type, @Description, @Columns, @Lines)
	print 'Added ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END
ELSE BEGIN
	UPDATE ClauseTypes SET Description = @Description, TypeId = @TypeId, Columns = @Columns, Lines = @Lines 
					WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)
	print 'Updated ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END

/******************************************************/
/* 77U Undertaking Terms and Conditions 150x65z */
/******************************************************/
set @TypeId = 122
SET @Clause_Type = 'UTERMSCOND'
SET @Description = 'Undertaking Terms'
SET @Columns = 65
SET @Lines = 150

IF NOT EXISTS (SELECT TypeId FROM ClauseTypes WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)) BEGIN
	INSERT ClauseTypes (TypeId, AppType, Clause_Type, Description, Columns, Lines) 
		VALUES (@TypeId, @AppType, @Clause_Type, @Description, @Columns, @Lines)
	print 'Added ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END
ELSE BEGIN
	UPDATE ClauseTypes SET Description = @Description, TypeId = @TypeId, Columns = @Columns, Lines = @Lines 
					WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)
	print 'Updated ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END

/******************************************************/
/* 45L Underlying Transaction Details 50x65z */
/******************************************************/
set @TypeId = 123
SET @Clause_Type = 'UTRANSDTL'
SET @Description = 'Underlying Trans. Details'
SET @Columns = 65
SET @Lines = 50

IF NOT EXISTS (SELECT TypeId FROM ClauseTypes WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)) BEGIN
	INSERT ClauseTypes (TypeId, AppType, Clause_Type, Description, Columns, Lines) 
		VALUES (@TypeId, @AppType, @Clause_Type, @Description, @Columns, @Lines)
	print 'Added ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END
ELSE BEGIN
	UPDATE ClauseTypes SET Description = @Description, TypeId = @TypeId, Columns = @Columns, Lines = @Lines 
					WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)
	print 'Updated ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END

  
SET @AppType = 'STBXMD'

/******************************************************/
/* 45C Document and Presentation Instructions 100x65z */
/******************************************************/
set @TypeId = 125
SET @Clause_Type = 'DOCPRESINS'
SET @Description = 'Presentation Instructions'
SET @Columns = 65
SET @Lines = 100

IF NOT EXISTS (SELECT TypeId FROM ClauseTypes WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)) BEGIN
	INSERT ClauseTypes (TypeId, AppType, Clause_Type, Description, Columns, Lines) 
		VALUES (@TypeId, @AppType, @Clause_Type, @Description, @Columns, @Lines)
	print 'Added ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END
ELSE BEGIN
	UPDATE ClauseTypes SET Description = @Description, TypeId = @TypeId, Columns = @Columns, Lines = @Lines 
					WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)
	print 'Updated ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END

/******************************************************/
/* 77U Undertaking Terms and Conditions 150x65z */
/******************************************************/
set @TypeId = 126
SET @Clause_Type = 'UTERMSCOND'
SET @Description = 'Undertaking Terms'
SET @Columns = 65
SET @Lines = 150

IF NOT EXISTS (SELECT TypeId FROM ClauseTypes WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)) BEGIN
	INSERT ClauseTypes (TypeId, AppType, Clause_Type, Description, Columns, Lines) 
		VALUES (@TypeId, @AppType, @Clause_Type, @Description, @Columns, @Lines)
	print 'Added ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END
ELSE BEGIN
	UPDATE ClauseTypes SET Description = @Description, TypeId = @TypeId, Columns = @Columns, Lines = @Lines 
					WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)
	print 'Updated ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END

/******************************************************/
/* 45L Underlying Transaction Details 50x65z */
/******************************************************/
set @TypeId = 127
SET @Clause_Type = 'UTRANSDTL'
SET @Description = 'Underlying Trans. Details'
SET @Columns = 65
SET @Lines = 50

IF NOT EXISTS (SELECT TypeId FROM ClauseTypes WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)) BEGIN
	INSERT ClauseTypes (TypeId, AppType, Clause_Type, Description, Columns, Lines) 
		VALUES (@TypeId, @AppType, @Clause_Type, @Description, @Columns, @Lines)
	print 'Added ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END
ELSE BEGIN
	UPDATE ClauseTypes SET Description = @Description, TypeId = @TypeId, Columns = @Columns, Lines = @Lines 
					WHERE (AppType = @AppType) AND (Clause_Type = @Clause_Type)
	print 'Updated ClauseTypes record: ' + @AppType + '-' + @Clause_Type + '-' + @Description
END

  
   