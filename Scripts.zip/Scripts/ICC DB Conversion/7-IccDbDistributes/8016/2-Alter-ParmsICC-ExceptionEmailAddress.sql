/* ******************************************* */
/* Alter ParmsICC Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF  NOT EXISTS (SELECT * FROM sys.columns  WHERE NAME = N'ExceptionEmailAddress' and Object_ID = Object_ID(N'ParmsICC'))
		BEGIN
			ALTER TABLE ParmsICC ADD
				ExceptionEmailAddress VarChar(200) NOT NULL CONSTRAINT DF_ParmsICC_ExceptionEmailAddress DEFAULT (0);
			print 'ExceptionEmailAddress added to ParmsICC table'
		END
		ELSE BEGIN
			print 'ExceptionEmailAddress already in ParmsICC table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

