/* ******************************************* */
/* Alter OldPasswords Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF  NOT EXISTS (SELECT * FROM sys.columns  WHERE NAME = N'OldSalt' and Object_ID = Object_ID(N'OldPasswords'))
		BEGIN
			ALTER TABLE OldPasswords ADD
				OldSalt VARCHAR(256) NOT NULL CONSTRAINT DF_OldPasswords_OldSalt DEFAULT '';
			print 'Salt added to OldPasswords table'
		END
		ELSE BEGIN
			print 'Salt already in OldPasswords table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

