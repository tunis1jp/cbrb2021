/* ******************************************* */
/* Alter ReportScheduler Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF EXISTS (SELECT * FROM sys.columns 
		            WHERE NAME = N'RunTime' and Object_ID = Object_ID(N'ReportScheduler')
											AND type_name(user_type_id) = 'datetime')
		BEGIN
			ALTER TABLE ReportScheduler DROP CONSTRAINT DF_ReportScheduler_RunTime;
			
			ALTER TABLE ReportScheduler ALTER COLUMN Runtime datetime2;
			print 'Runtime changed to datetime2 in ReportScheduler table'
			
			ALTER TABLE ReportScheduler ADD  CONSTRAINT DF_ReportScheduler_Runtime  DEFAULT ('1-1-1900') FOR Runtime;
		END
		ELSE BEGIN
			print 'Runtime already datetime2 in ReportScheduler table'
		END
	COMMIT TRAN	
END TRY

BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

BEGIN TRY
	BEGIN TRAN
		IF EXISTS (SELECT * FROM sys.columns 
		            WHERE NAME = N'RptLastRun' and Object_ID = Object_ID(N'ReportScheduler')
											AND type_name(user_type_id) = 'datetime')
		BEGIN
			ALTER TABLE ReportScheduler DROP CONSTRAINT DF_ReportScheduler_RptLastRun;
			
			ALTER TABLE ReportScheduler ALTER COLUMN RptLastRun datetime2;
			print 'RptLastRun changed to datetime2 in ReportScheduler table'
			
			ALTER TABLE ReportScheduler ADD  CONSTRAINT DF_ReportScheduler_RptLastRun  DEFAULT ('1-1-1900') FOR RptLastRun;
		END
		ELSE BEGIN
			print 'RptLastRun already datetime2 in ReportScheduler table'
		END
	COMMIT TRAN	
END TRY

BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH
