--update ballocprimarypkey in locevent from 0 because it was causing it to not work for current balance on any collection amendment.
UPDATE LocEvent
  SET 
      BalLocPrimaryPkey = LocPrimaryPkey
WHERE BalLocPrimaryPkey = 0
      AND ServiceCategory = 'COL'
      AND Product = 'AMD';