/* ******************************************* */
/* Update Reports Table - Add LC Type to Application */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
			BEGIN 
                Update Reports set ReportDescription = 
				Case when GroupLevelEntKey = 'IMP' then 'Import'
				when GroupLevelEntKey = 'STB' then
				case when ReportDescription like '%Advised%'
					then 'Standby'
					else 'Standby Advised'
					end
				when GroupLevelEntKey = 'STB' then 'Standby'
				when GroupLevelEntKey = 'EXP' then 'Export'
				when GroupLevelEntKey = 'CEX' then
					case when ReportDescription like '%Collection%'
					then 'Export'
					else 'Export Collection'
					end
				when GroupLevelEntKey = 'DIR' then 
				case when ReportDescription like '%Collection%'
					then 'Direct'
					else 'Direct Collection'
					end
				when GroupLevelEntKey = 'CIM' then
					case when ReportDescription like '%Collection%'
					then 'Incoming'
					else 'Incoming Collection'
					end
				else GroupLevelEntKey
				end 
				+ ' ' + ReportDescription
				where
				Not ReportDescription like '%Export%'
				AND Not ReportDescription like '%Import%'
				AND Not ReportDescription like '%Standby%'
				AND Not ReportDescription like '%Steamship%'
				AND Not ReportDescription like '%Acceptance%'
				AND Not ReportDescription like '%Incoming%'
			END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH