DECLARE @Code varchar(4)
DECLARE @Description varchar(25)
DECLARE @Active varchar(1)
DECLARE @OrderBy int

SET @Active = 'Y'
SET @OrderBy = 0

SET @Description = 'Moody''s'
SET @Code = 'MDY'
SET @OrderBy = @OrderBy + 1
IF NOT EXISTS (SELECT PKeyIdentity FROM xxxRatingAgency WHERE Code = @Code AND Description = @Description) BEGIN
	INSERT xxxRatingAgency (Code,Description,Active,OrderBy) VALUES(@Code, @Description, @Active, @OrderBy)
	PRINT 'Added ' + @Code + ':' + @Description
END
ELSE BEGIN
	print @Code + ':' + @Description + ' already in xxxRatingAgency'
END

SET @Description = 'Standard and Poor''s'
SET @Code = 'S&P'
SET @OrderBy = @OrderBy + 1
IF NOT EXISTS (SELECT PKeyIdentity FROM xxxRatingAgency WHERE Code = @Code AND Description = @Description) BEGIN
	INSERT xxxRatingAgency (Code,Description,Active,OrderBy) VALUES(@Code, @Description, @Active, @OrderBy)
	PRINT 'Added ' + @Code + ':' + @Description
END
ELSE BEGIN
	print @Code + ':' + @Description + ' already in xxxRatingAgency'
END

SET @Description = 'Fitch'
SET @Code = 'FIT'
SET @OrderBy = @OrderBy + 1
IF NOT EXISTS (SELECT PKeyIdentity FROM xxxRatingAgency WHERE Code = @Code AND Description = @Description) BEGIN
	INSERT xxxRatingAgency (Code,Description,Active,OrderBy) VALUES(@Code, @Description, @Active, @OrderBy)
	PRINT 'Added ' + @Code + ':' + @Description
END
ELSE BEGIN
	print @Code + ':' + @Description + ' already in xxxRatingAgency'
END

