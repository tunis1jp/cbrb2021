BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='ReportSchedulerAvailableFormulas') 
			BEGIN 
				CREATE TABLE ReportSchedulerAvailableFormulas(
						PKey INT Constraint PK_ReportSchedulerAvailableFormulas_PKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
						Category varchar(50) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableFormulas_Category DEFAULT (''),
						GtsService varchar(4) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableFormulas_GtsService DEFAULT (''),
						FieldName varchar(100) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableFormulas_Prompt DEFAULT (''),
  					Description varchar(50) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableFormulas_Description DEFAULT (''),
						Formula varchar(max) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableFormulas_Formula DEFAULT ('')
          );
          CREATE  INDEX IX_ReportSchedulerAvailableFormulas_Category_GtsService ON ReportSchedulerAvailableFormulas(Category, GtsService);
          CREATE  INDEX IX_ReportSchedulerAvailableFormulas_FieldName ON ReportSchedulerAvailableFormulas(FieldName);
          print 'Created ReportSchedulerAvailableFormulas table'
			END
			ELSE BEGIN
                print 'ReportSchedulerAvailableFormulas table already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH
