/* *************************************************** */
/* Alter ColApplication Table Drop Unique Constraints  */
/* ************************************************** */
BEGIN TRY
	BEGIN TRAN
		IF  EXISTS (
            Select COLUMN_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE 
			where TABLE_NAME = 'ColApplication' and CONSTRAINT_NAME = 'IX_ColApplication'
            )
		BEGIN
			ALTER TABLE ColApplication DROP CONSTRAINT IX_ColApplication;
			print 'Unique Constraints dropped from ColApplication table'
		END
		ELSE BEGIN
			print 'Unique Constraints already dropped from ColApplication table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE() 
END CATCH
