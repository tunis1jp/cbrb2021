/* ******************************************* */

/* Affiliate Bank Table */

/* ******************************************* */
BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='AffiliateBanks') 
			BEGIN 
                CREATE TABLE AffiliateBanks(
                                AffiliatePkey int PRIMARY KEY IDENTITY(1,1) NOT NULL,
                                AffiliateName varchar(64) NOT NULL CONSTRAINT DF_AffiliateBanks_AffiliateName DEFAULT ('')
                );
                print 'Created AffiliateBanks table'
			END
			ELSE BEGIN
                print 'AffiliateBanks table already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH