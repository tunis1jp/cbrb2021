print 'Deleting POs from AppPageControls'
DELETE FROM AppPageControls 
WHERE PageDesc = 'POs';


DECLARE @AppType varchar(6)
DECLARE @PageNumber int
DECLARE @PageActive varchar(1)
DECLARE @PageDesc varchar(35)
DECLARE @BankId int
DECLARE @PageTabDesc varchar(15)

SET @PageDesc = 'File Upload'
SET @PageTabDesc = 'File Upload'
SET @PageActive = 'Y'
SET @BankId = (SELECT TOP 1 PKey FROM Banks ORDER BY PKey DESC)

SET @PageNumber = 5
SET @AppType = 'DIRENT'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 5
SET @AppType = 'DIRXMD'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 5
SET @AppType = 'CEXENT'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 5
SET @AppType = 'CEXXMD'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 5
SET @AppType = 'SARENT'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 7
SET @AppType = 'IMPENT'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 7
SET @AppType = 'STBENT'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 12
SET @AppType = 'IMPXMD'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 12
SET @AppType = 'STBXMD'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

SET @PageNumber = 2
SET @AppType = 'SCFENT'
IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageDesc = @PageDesc) BEGIN
	INSERT AppPageControls (AppType,PageNumber,PageActive,PageDesc,BankId,PageTabDesc) 
	VALUES (@AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Added ' + @AppType + ' ' + @PageDesc
END
ELSE BEGIN
	print @AppType + ' ' + @PageDesc + ' already in AppPageControls'
END	

