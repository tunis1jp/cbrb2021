/*
Run this script on:

        SQL2016SVR\R8.TdbIccNetDevR8    -  This database will be modified

to synchronize it with:

        SQL2016SVR\R8.ICCNet2020

You are recommended to back up your database before running this script

Script created by SQL Compare version 12.2.1.4077 from Red Gate Software Ltd at 2/10/2021 8:42:46 AM

*/
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL Serializable
GO
BEGIN TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ColApplication]'
GO
ALTER TABLE [dbo].[ColApplication] DROP CONSTRAINT [IX_ColApplication]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[LCApplication]'
GO
ALTER TABLE [dbo].[LCApplication] DROP CONSTRAINT [IX_LcApplication]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[LCApplication]'
GO
ALTER TABLE [dbo].[LCApplication] DROP CONSTRAINT [DF_LcApplication_SendVia]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [PK_ParmsICC]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_GeoPersist]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_TradeCalendar]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_WipFiltersOpen]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_CreateFromTemplate]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_EmailNotificationsUser]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_EmailNotificationsAdmin]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_LDAP]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_ADDomain]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_UsersCreateDrawers]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_SsoVersion]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_LoginURL]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_HTTPSiteHeader]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_SsoTickleURL]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_ReportWaterMark]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_BankUserRoleEntitlement]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_CollectionsShowREMT]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_ShowFxContract]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_IMPMultipleXmd]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_STBMultipleXmd]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_DIRMultipleXmd]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_CEXMultipleXmd]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_BankWatermark]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_FileUpload]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsICC_RTFtoPDF]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_Multilingual]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_UseDrwrReferenceForCIM]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_UseExpiredLcForSAR]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_Swift2018]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_PfxFile]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_PfxPw]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] DROP CONSTRAINT [DF_ParmsIcc_DirEntLogoFile]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[Party]'
GO
ALTER TABLE [dbo].[Party] DROP CONSTRAINT [IX_Party]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[Party]'
GO
ALTER TABLE [dbo].[Party] DROP CONSTRAINT [DF_Party_PartyId]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[xxxPurposeCodes]'
GO
ALTER TABLE [dbo].[xxxPurposeCodes] DROP CONSTRAINT [PK_xxxPurposeCodes]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[LCAmendment]'
GO
ALTER TABLE [dbo].[LCAmendment] DROP CONSTRAINT [DF_LCAmendment_SendVia]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[LCHistoryBalance]'
GO
ALTER TABLE [dbo].[LCHistoryBalance] DROP CONSTRAINT [DF_LCHistoryBalance_Charges]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[LCHistoryBalance]'
GO
ALTER TABLE [dbo].[LCHistoryBalance] DROP CONSTRAINT [DF_LCHistoryBalance_SendVia]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[Reports]'
GO
ALTER TABLE [dbo].[Reports] DROP CONSTRAINT [DF_REPORTS_REPORTDESCRIPTION]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[UserMenuApps]'
GO
ALTER TABLE [dbo].[UserMenuApps] DROP CONSTRAINT [DF_UserMenuApps_Description]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[UserMenuGroups]'
GO
ALTER TABLE [dbo].[UserMenuGroups] DROP CONSTRAINT [DF_UserMenuGroups_Description]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[UserMenuItems]'
GO
ALTER TABLE [dbo].[UserMenuItems] DROP CONSTRAINT [DF_UserMenuItems_MenuDescription]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[UserMenuItems]'
GO
ALTER TABLE [dbo].[UserMenuItems] DROP CONSTRAINT [DF_UserMenuItems_EntitlementDescription]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping constraints from [dbo].[Users]'
GO
ALTER TABLE [dbo].[Users] DROP CONSTRAINT [DF_Users_Entitlement]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping index [IX_PartyPartyId] from [dbo].[Party]'
GO
DROP INDEX [IX_PartyPartyId] ON [dbo].[Party]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping index [IX_Reports] from [dbo].[Reports]'
GO
DROP INDEX [IX_Reports] ON [dbo].[Reports]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping index [IX_UserMenuGroups] from [dbo].[UserMenuGroups]'
GO
DROP INDEX [IX_UserMenuGroups] ON [dbo].[UserMenuGroups]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Dropping index [IX_xxxPurposeCodes] from [dbo].[xxxPurposeCodes]'
GO
DROP INDEX [IX_xxxPurposeCodes] ON [dbo].[xxxPurposeCodes]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[BankUsers]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[BankUsers] ADD
[Salt] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Bankusers_Salt] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[Banks]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Banks] ADD
[CustomerPwRequirements] [int] NOT NULL CONSTRAINT [DF_Banks_CustomerPwRequirements] DEFAULT ((0)),
[BankPwRequirements] [int] NOT NULL CONSTRAINT [DF_Banks_BankPwRequirements] DEFAULT ((0))
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[LCAmendment]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCAmendment] ADD
[BondDeal] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_BondDeal] DEFAULT (''),
[CommunityInvestment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_CommunityInvestment] DEFAULT (''),
[Exceptions] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_Exceptions] DEFAULT (''),
[FluctuatingBalance] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_FluctuatingBalance] DEFAULT (''),
[LateFee] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_LateFee] DEFAULT (''),
[LcPurpose] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_LcPurpose] DEFAULT (''),
[MultipleDraw] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_MultipleDraw] DEFAULT (''),
[TaxExempt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_TaxExempt] DEFAULT (''),
[RatingAgency] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_RatingAgency] DEFAULT (''),
[BondPurpose] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_BondPurpose] DEFAULT (''),
[MemberLcNumber] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_MemberLcNumber] DEFAULT (''),
[MemberLcEffectiveDate] [datetime] NOT NULL CONSTRAINT [DF_LcAmendment_MemberLcEffectiveDate] DEFAULT (((1)/(1))/(1900)),
[MemberLcExpirationDate] [datetime] NOT NULL CONSTRAINT [DF_LcAmendment_MemberLcExpirationDate] DEFAULT (((1)/(1))/(1900)),
[AccountPartyCustomer] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_AccountPartyCustomer] DEFAULT (''),
[MemberLcAmount] [float] NOT NULL CONSTRAINT [DF_LcAmendment_MemberLcAmount] DEFAULT ((0)),
[BenePhone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcAmendment_BenePhone] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCAmendment] ALTER COLUMN [SendVia] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[LCHistoryBalance]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCHistoryBalance] ADD
[BondDeal] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_BondDeal] DEFAULT (''),
[CommunityInvestment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_CommunityInvestment] DEFAULT (''),
[Exceptions] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_Exceptions] DEFAULT (''),
[FluctuatingBalance] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_FluctuatingBalance] DEFAULT (''),
[LateFee] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_LateFee] DEFAULT (''),
[LcPurpose] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_LcPurpose] DEFAULT (''),
[MultipleDraw] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_MultipleDraw] DEFAULT (''),
[TaxExempt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_TaxExempt] DEFAULT (''),
[BenePhone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_BenePhone] DEFAULT (''),
[UtilizedAmount] [money] NOT NULL CONSTRAINT [DF_LcHistoryBalance_UtilizedAmount] DEFAULT ((0)),
[AverageDailyBalance] [money] NOT NULL CONSTRAINT [DF_LcHistoryBalance_AverageDailyBalance] DEFAULT ((0)),
[CollateralizationPercentage] [float] NOT NULL CONSTRAINT [DF_LcHistoryBalance_CollateralizationPercentage] DEFAULT ((0)),
[RatingAgency] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_RatingAgency] DEFAULT (''),
[BondPurpose] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_BondPurpose] DEFAULT (''),
[MemberLcNumber] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_MemberLcNumber] DEFAULT (''),
[MemberLcEffectiveDate] [datetime] NOT NULL CONSTRAINT [DF_LcHistoryBalance_MemberLcEffectiveDate] DEFAULT (((1)/(1))/(1900)),
[MemberLcExpirationDate] [datetime] NOT NULL CONSTRAINT [DF_LcHistoryBalance_MemberLcExpirationDate] DEFAULT (((1)/(1))/(1900)),
[AccountPartyCustomer] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_AccountPartyCustomer] DEFAULT (''),
[MemberLcAmount] [float] NOT NULL CONSTRAINT [DF_LcHistoryBalance_MemberLcAmount] DEFAULT ((0)),
[BeneEmailAddress] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_BeneEmailAddress] DEFAULT (''),
[OpnrAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_OpnrAttnLine1] DEFAULT (''),
[BeneAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_BeneAttnLine1] DEFAULT (''),
[AdvtAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_AdvtAttnLine1] DEFAULT (''),
[ApplAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_ApplAttnLine1] DEFAULT (''),
[OpnrPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_OpnrPhone] DEFAULT (''),
[AdvtPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_AdvtPhone] DEFAULT (''),
[ApplPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcHistoryBalance_ApplPhone] DEFAULT (''),
[OpnrEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LcHistoryBalance_OpnrEmailAddress] DEFAULT (''),
[AdvtEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LcHistoryBalance_AdvtEmailAddress] DEFAULT (''),
[ApplEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_LcHistoryBalance_ApplEmailAddress] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCHistoryBalance] ALTER COLUMN [Charges] [varchar] (223) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCHistoryBalance] ALTER COLUMN [SendVia] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[LCApplication]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCApplication] ADD
[BondDeal] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_BondDeal] DEFAULT (''),
[CommunityInvestment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_CommunityInvestment] DEFAULT (''),
[Exceptions] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_Exceptions] DEFAULT (''),
[FluctuatingBalance] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_FluctuatingBalance] DEFAULT (''),
[LateFee] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_LateFee] DEFAULT (''),
[LcPurpose] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_LcPurpose] DEFAULT (''),
[MultipleDraw] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_MultipleDraw] DEFAULT (''),
[TaxExempt] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_TaxExempt] DEFAULT (''),
[RatingAgency] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_RatingAgency] DEFAULT (''),
[BondPurpose] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_BondPurpose] DEFAULT (''),
[MemberLcNumber] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_MemberLcNumber] DEFAULT (''),
[MemberLcEffectiveDate] [datetime] NOT NULL CONSTRAINT [DF_LcApplication_MemberLcEffectiveDate] DEFAULT (((1)/(1))/(1900)),
[MemberLcExpirationDate] [datetime] NOT NULL CONSTRAINT [DF_LcApplication_MemberLcExpirationDate] DEFAULT (((1)/(1))/(1900)),
[AccountPartyCustomer] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_AccountPartyCustomer] DEFAULT (''),
[MemberLcAmount] [float] NOT NULL CONSTRAINT [DF_LcApplication_MemberLcAmount] DEFAULT ((0)),
[TermsAccepted] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LcApplication_TermsAccepted] DEFAULT ('N')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCApplication] ALTER COLUMN [SendVia] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[OldPasswords]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[OldPasswords] ADD
[OldSalt] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_OldPasswords_OldSalt] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[Party]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Party] ADD
[Phone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Party_Phone] DEFAULT (''),
[EmailAddress] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Party_EmailAddress] DEFAULT (''),
[AttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Party_Attention] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Party] ALTER COLUMN [PartyId] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[Party]'
GO
ALTER TABLE [dbo].[Party] ADD CONSTRAINT [IX_Party] UNIQUE NONCLUSTERED  ([CustomerId], [PartyId], [IsPtyFlag]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_PartyPartyId] on [dbo].[Party]'
GO
CREATE NONCLUSTERED INDEX [IX_PartyPartyId] ON [dbo].[Party] ([PartyId]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[RepParmCust]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[RepParmCust] ADD
[Category] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RepParmCust_Category] DEFAULT (''),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RepParmCust_GtsService] DEFAULT (''),
[Formula] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RepParmCust_Formula] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[RepParmSys]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[RepParmSys] ADD
[Category] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RepParmSys_Category] DEFAULT (''),
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RepParmSys_GtsService] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[Reports]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Reports] ALTER COLUMN [ReportDescription] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_Reports] on [dbo].[Reports]'
GO
CREATE NONCLUSTERED INDEX [IX_Reports] ON [dbo].[Reports] ([BranchId], [ItemLevelPKey], [ReportDescription]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[Users]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Users] ADD
[UserRolePKey] [int] NOT NULL CONSTRAINT [DF_Users_UserRolePKey] DEFAULT ((0)),
[Salt] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Users_Salt] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Users] ALTER COLUMN [Entitlement] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[ColHistoryBalance]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[ColHistoryBalance] ADD
[RemtAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_RemtAttnLine1] DEFAULT (''),
[DrwrAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_DrwrAttnLine1] DEFAULT (''),
[DrweAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_DrweAttnLine1] DEFAULT (''),
[ColfAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_ColfAttnLine1] DEFAULT (''),
[RemtPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_RemtPhone] DEFAULT (''),
[DrwrPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_DrwrPhone] DEFAULT (''),
[DrwePhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_DrwePhone] DEFAULT (''),
[ColfPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ColHistoryBalance_ColfPhone] DEFAULT (''),
[RemtEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ColHistoryBalance_RemtEmailAddress] DEFAULT (''),
[DrwrEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ColHistoryBalance_DrwrEmailAddress] DEFAULT (''),
[DrweEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ColHistoryBalance_DrweEmailAddress] DEFAULT (''),
[ColfEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_ColHistoryBalance_ColfEmailAddress] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[Branches]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[Branches] ADD
[AffiliateId] [int] NOT NULL CONSTRAINT [DF_Branches_AffililiateId] DEFAULT ((0))
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[xxxPurposeCodes]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[xxxPurposeCodes] ADD
[GtsService] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxPurposeCodes_GtsService] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_xxxPurposeCodes] on [dbo].[xxxPurposeCodes]'
GO
ALTER TABLE [dbo].[xxxPurposeCodes] ADD CONSTRAINT [PK_xxxPurposeCodes] PRIMARY KEY CLUSTERED  ([LegalEntity], [GtsService], [Code]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[xxxTenorPhrase]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[xxxTenorPhrase] ADD
[GtsService] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_xxxTenorPhrase_GtsService] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[SarHistoryBalance]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[SarHistoryBalance] ADD
[PresAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_PresAttnLine1] DEFAULT (''),
[FFAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_FFAttnLine1] DEFAULT (''),
[DrweAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_DrweAttnLine1] DEFAULT (''),
[CarrAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_CarrAttnLine1] DEFAULT (''),
[PresPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_PresPhone] DEFAULT (''),
[FFPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_FFPhone] DEFAULT (''),
[DrwePhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_DrwePhone] DEFAULT (''),
[CarrPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SarHistoryBalance_CarrPhone] DEFAULT (''),
[PresEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_SarHistoryBalance_PresEmailAddress] DEFAULT (''),
[FFEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_SarHistoryBalance_FFEmailAddress] DEFAULT (''),
[DrweEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_SarHistoryBalance_DrweEmailAddress] DEFAULT (''),
[CarrEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_SarHistoryBalance_CarrEmailAddress] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Rebuilding [dbo].[ParmsICC]'
GO
CREATE TABLE [dbo].[RG_Recovery_1_ParmsICC]
(
[PKey] [int] NOT NULL IDENTITY(1, 1),
[GeoPersist] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_GeoPersist] DEFAULT ('N'),
[TradeCalendar] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_TradeCalendar] DEFAULT ('Y'),
[WipFiltersOpen] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_WipFiltersOpen] DEFAULT ('N'),
[CreateFromTemplate] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_CreateFromTemplate] DEFAULT ('N'),
[EmailNotificationsUser] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_EmailNotificationsUser] DEFAULT ('Y'),
[EmailNotificationsAdmin] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_EmailNotificationsAdmin] DEFAULT ('N'),
[LDAP] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_LDAP] DEFAULT ('N'),
[ADDomain] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_ADDomain] DEFAULT (''),
[UsersCreateDrawers] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_UsersCreateDrawers] DEFAULT ('Y'),
[SsoVersion] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_SsoVersion] DEFAULT ('N'),
[LoginURL] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_LoginURL] DEFAULT (''),
[HTTPSiteHeader] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_HTTPSiteHeader] DEFAULT (''),
[SsoTickleURL] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_SsoTickleURL] DEFAULT (''),
[ReportWaterMark] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_ReportWaterMark] DEFAULT ('True'),
[BankUserRoleEntitlement] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_BankUserRoleEntitlement] DEFAULT ('N'),
[CollectionsShowREMT] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_CollectionsShowREMT] DEFAULT ('Y'),
[ShowFxContract] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_ShowFxContract] DEFAULT ('N'),
[IMPMultipleXmd] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_IMPMultipleXmd] DEFAULT ('N'),
[STBMultipleXmd] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_STBMultipleXmd] DEFAULT ('N'),
[DIRMultipleXmd] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_DIRMultipleXmd] DEFAULT ('N'),
[CEXMultipleXmd] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_CEXMultipleXmd] DEFAULT ('N'),
[BankWatermark] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_BankWatermark] DEFAULT ('N'),
[FileUpload] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_FileUpload] DEFAULT ('Y'),
[RTFtoPDF] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_RTFtoPDF] DEFAULT ('N'),
[Multilingual] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_Multilingual] DEFAULT ('N'),
[UseDrwrReferenceForCIM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_UseDrwrReferenceForCIM] DEFAULT ('N'),
[UseExpiredLcForSAR] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_UseExpiredLcForSAR] DEFAULT ('N'),
[Swift2018] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_Swift2018] DEFAULT ('N'),
[PfxFile] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_PfxFile] DEFAULT (''),
[PfxPw] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_PfxPw] DEFAULT (''),
[DirEntLogoFile] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsIcc_DirEntLogoFile] DEFAULT (''),
[LateFeeAmount] [money] NOT NULL CONSTRAINT [DF_ParmsICC_LateFeeAmount] DEFAULT ((0)),
[LateFeeTime] [datetime] NOT NULL CONSTRAINT [DF_ParmsICC_LateFeeTime] DEFAULT ('1/1/1900 00:00:00'),
[FluctuatingBalanceLimit] [float] NOT NULL CONSTRAINT [DF_ParmsICC_FluctuatingBalanceLimit] DEFAULT ((0)),
[RealTimeEditChecks] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_RealTimeEditChecks] DEFAULT ('Y'),
[MaxExpYearsInFuture] [int] NOT NULL CONSTRAINT [DF_ParmsICC_MaxExpYearsInFuture] DEFAULT ((0)),
[MaxIssDaysInFuture] [int] NOT NULL CONSTRAINT [DF_ParmsICC_MaxIssDaysInFuture] DEFAULT ((0)),
[DaystoSubmit] [int] NOT NULL CONSTRAINT [DF_ParmsICC_DaystoSubmit] DEFAULT ((0)),
[CharCounter] [bit] NOT NULL CONSTRAINT [DF_ParmsICC_CharCounter] DEFAULT ((0)),
[ShowSendVia] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_ShowSendVia] DEFAULT (''),
[ShowSendViaSTB] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_ShowSendViaSTB] DEFAULT (''),
[IccUrl] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_IccUrl] DEFAULT (''),
[BranchesGtsId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_BranchesGtsId] DEFAULT ('ClientId'),
[UsersSignonId] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_UsersSignonId] DEFAULT ('PlatformUserId'),
[Base64Encoded] [bit] NOT NULL CONSTRAINT [DF__ParmsICC__Base64__39AF212D] DEFAULT ((0)),
[EncryptedSaml] [bit] NOT NULL CONSTRAINT [DF__ParmsICC__Encryp__3AA34566] DEFAULT ((0)),
SendExceptionEmail BIT NOT NULL CONSTRAINT DF_ParmsICC_SendExceptionEmail DEFAULT (0),
[ExceptionEmailAddress] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ParmsICC_ExceptionEmailAddress] DEFAULT ((0)),
[ICCWebHashedPW] [bit] NOT NULL CONSTRAINT [DF_ParmsICC_ICCWebHashedPW] DEFAULT ((0)),
[BankWebHashedPW] [bit] NOT NULL CONSTRAINT [DF_ParmsICC_BankWebHashedPW] DEFAULT ((0)),
[BankUserFromAD] [bit] NOT NULL CONSTRAINT [DF_ParmsICC_BankUserFromAD] DEFAULT ((0))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
SET IDENTITY_INSERT [dbo].[RG_Recovery_1_ParmsICC] ON
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
INSERT INTO [dbo].[RG_Recovery_1_ParmsICC]([PKey], [GeoPersist], [TradeCalendar], [WipFiltersOpen], [CreateFromTemplate], [EmailNotificationsUser], [EmailNotificationsAdmin], [LDAP], [ADDomain], [UsersCreateDrawers], [SsoVersion], [LoginURL], [HTTPSiteHeader], [SsoTickleURL], [ReportWaterMark], [BankUserRoleEntitlement], [CollectionsShowREMT], [ShowFxContract], [IMPMultipleXmd], [STBMultipleXmd], [DIRMultipleXmd], [CEXMultipleXmd], [BankWatermark], [FileUpload], [RTFtoPDF], [Multilingual], [UseDrwrReferenceForCIM], [UseExpiredLcForSAR], [Swift2018], [PfxFile], [PfxPw], [DirEntLogoFile]) SELECT [PKey], [GeoPersist], [TradeCalendar], [WipFiltersOpen], [CreateFromTemplate], [EmailNotificationsUser], [EmailNotificationsAdmin], [LDAP], [ADDomain], [UsersCreateDrawers], [SsoVersion], [LoginURL], [HTTPSiteHeader], [SsoTickleURL], [ReportWaterMark], [BankUserRoleEntitlement], [CollectionsShowREMT], [ShowFxContract], [IMPMultipleXmd], [STBMultipleXmd], [DIRMultipleXmd], [CEXMultipleXmd], [BankWatermark], [FileUpload], [RTFtoPDF], [Multilingual], [UseDrwrReferenceForCIM], [UseExpiredLcForSAR], [Swift2018], [PfxFile], [PfxPw], [DirEntLogoFile] FROM [dbo].[ParmsICC]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
SET IDENTITY_INSERT [dbo].[RG_Recovery_1_ParmsICC] OFF
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
DECLARE @idVal BIGINT
SELECT @idVal = IDENT_CURRENT(N'[dbo].[ParmsICC]')
IF @idVal IS NOT NULL
    DBCC CHECKIDENT(N'[dbo].[RG_Recovery_1_ParmsICC]', RESEED, @idVal)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
DROP TABLE [dbo].[ParmsICC]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
EXEC sp_rename N'[dbo].[RG_Recovery_1_ParmsICC]', N'ParmsICC', N'OBJECT'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ParmsICC] on [dbo].[ParmsICC]'
GO
ALTER TABLE [dbo].[ParmsICC] ADD CONSTRAINT [PK_ParmsICC] PRIMARY KEY CLUSTERED  ([PKey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[BaDrafts]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[BaDrafts] ADD
[ObligorAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_ObligorAttnLine1] DEFAULT (''),
[ObligorEmailAddress] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_ObligorEmailAddress] DEFAULT (''),
[ObligorPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_ObligorPhone] DEFAULT (''),
[PayToAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_PayToAttnLine1] DEFAULT (''),
[PayToEmailAddress] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_PayToEmailAddress] DEFAULT (''),
[PayToPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_PayToPhone] DEFAULT (''),
[ReimbOnAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_ReimbOnAttnLine1] DEFAULT (''),
[ReimbOnEmailAddress] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_ReimbOnEmailAddress] DEFAULT (''),
[ReimbOnPhone] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BaDrafts_ReimbOnPhone] DEFAULT ('')
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[UserMenuGroups]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[UserMenuGroups] ALTER COLUMN [Description] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating index [IX_UserMenuGroups] on [dbo].[UserMenuGroups]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_UserMenuGroups] ON [dbo].[UserMenuGroups] ([BankId], [CustomerId], [BranchId], [Description]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[UserMenuItems]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[UserMenuItems] ALTER COLUMN [MenuDescription] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[UserMenuItems] ALTER COLUMN [EntitlementDescription] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Altering [dbo].[UserMenuApps]'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[UserMenuApps] ALTER COLUMN [Description] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[LCAmendment]'
GO
ALTER TABLE [dbo].[LCAmendment] ADD CONSTRAINT [DF_LCAmendment_SendVia] DEFAULT ('') FOR [SendVia]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[LCApplication]'
GO
ALTER TABLE [dbo].[LCApplication] ADD CONSTRAINT [DF_LcApplication_SendVia] DEFAULT ('') FOR [SendVia]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[LCHistoryBalance]'
GO
ALTER TABLE [dbo].[LCHistoryBalance] ADD CONSTRAINT [DF_LCHistoryBalance_Charges] DEFAULT ('') FOR [Charges]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[LCHistoryBalance] ADD CONSTRAINT [DF_LCHistoryBalance_SendVia] DEFAULT ('') FOR [SendVia]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[Party]'
GO
ALTER TABLE [dbo].[Party] ADD CONSTRAINT [DF_Party_PartyId] DEFAULT ('') FOR [PartyId]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[Reports]'
GO
ALTER TABLE [dbo].[Reports] ADD CONSTRAINT [DF_REPORTS_REPORTDESCRIPTION] DEFAULT ('') FOR [ReportDescription]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[UserMenuApps]'
GO
ALTER TABLE [dbo].[UserMenuApps] ADD CONSTRAINT [DF_UserMenuApps_Description] DEFAULT ('') FOR [Description]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[UserMenuGroups]'
GO
ALTER TABLE [dbo].[UserMenuGroups] ADD CONSTRAINT [DF_UserMenuGroups_Description] DEFAULT ('') FOR [Description]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[UserMenuItems]'
GO
ALTER TABLE [dbo].[UserMenuItems] ADD CONSTRAINT [DF_UserMenuItems_MenuDescription] DEFAULT ('') FOR [MenuDescription]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
ALTER TABLE [dbo].[UserMenuItems] ADD CONSTRAINT [DF_UserMenuItems_EntitlementDescription] DEFAULT ('') FOR [EntitlementDescription]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[Users]'
GO
ALTER TABLE [dbo].[Users] ADD CONSTRAINT [DF_Users_Entitlement] DEFAULT ('0') FOR [Entitlement]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
COMMIT TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
DECLARE @Success AS BIT
SET @Success = 1
SET NOEXEC OFF
IF (@Success = 1) PRINT 'The database update succeeded'
ELSE BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
	PRINT 'The database update failed'
END
GO
