Declare @LE1 Varchar(2)
Set @LE1 = 'TD'


IF NOT EXISTS(select
		*
	from MemLetterForm
	where gtsService = 'STB' AND gtsProduct = 'ISS' and LegalEntity = @LE1 AND Code = 'DRAFTFREETXT')
BEGIN
	INSERT [dbo].[MemLetterForm] (
		[LegalEntity],
		[DocGenService],
		[DocGenProduct],
		[Code],
		[ListName],
		[Description],
		[LetterType],
		[gtsService],
		[gtsProduct],
		[Swift],
		[eMail],
		[TypeDocument],
		[Active],
		[OrderBy],
		[PreFinal],
		[PlainPrinter],
		[LetterPrinter],
		[CopyPrinter],
		[PlainCopies],
		[LetterCopies],
		[CopyCopies],
		[IccType],
		[AddressTo],
		[Who],
		[Via],
		[EmailSubject]
	)
	VALUES (
		@LE1,
		N'STB',
		N'ISS',
		N'DRAFTFREETXT',
		N'Standby DRAFT Email',
		N'Standby DRAFT Email',
		N'ALL',
		N'STB',
		N'ISS',
		1,
		N'N',
		N'R',
		1,
		0,
		N'F',
		N'PLAIN1',
		N'LETTER1',
		N'COPY1',
		0,
		0,
		0,
		N'',
		N'N',
		N'OPN',
		N'MAL',
		N''
	)
	PRINT 'ADDED Standby DRAFT Email TO MEMLETTERFORM'
end
ELSE
begin
	PRINT 'Standby DRAFT Email ALREADY EXISTS IN MEMLETTERFORM'
END

IF NOT EXISTS(select
		*
	from MemLetterForm
	where gtsService = 'STB' AND gtsProduct = 'AMD' and LegalEntity = @LE1 AND Code = 'EXPIRYNOTICE')
BEGIN
	INSERT [dbo].[MemLetterForm] (
		[LegalEntity],
		[DocGenService],
		[DocGenProduct],
		[Code],
		[ListName],
		[Description],
		[LetterType],
		[gtsService],
		[gtsProduct],
		[Swift],
		[eMail],
		[TypeDocument],
		[Active],
		[OrderBy],
		[PreFinal],
		[PlainPrinter],
		[LetterPrinter],
		[CopyPrinter],
		[PlainCopies],
		[LetterCopies],
		[CopyCopies],
		[IccType],
		[AddressTo],
		[Who],
		[Via],
		[EmailSubject]
	)
	VALUES (
		@LE1,
		N'STB',
		N'AMD',
		N'EXPIRYNOTICE',
		N'Advice of Expiry',
		N'Advice of Expiry',
		N'ALL',
		N'STB',
		N'AMD',
		1,
		N'N',
		N'R',
		1,
		0,
		N'F',
		N'PLAIN1',
		N'LETTER1',
		N'COPY1',
		0,
		0,
		0,
		N'',
		N'N',
		N'BEN',
		N'MAL',
		N''
	)
	PRINT 'ADDED Expiry Notice Email TO MEMLETTERFORM'
end
ELSE
begin
	PRINT 'Expiry Notice ALREADY EXISTS IN MEMLETTERFORM'
END