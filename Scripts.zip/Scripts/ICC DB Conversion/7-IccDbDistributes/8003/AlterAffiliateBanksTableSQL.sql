/* ******************************************* */
/* Alter Branches Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE TABLE_NAME='Branches' and Column_Name = 'AffiliateId') 
			BEGIN 
                Alter TABLE Branches Add AffiliateId INTEGER NOT NULL DEFAULT(0);
                print 'Altered Branches Table'
			END
			ELSE BEGIN
                print 'AffiliateId column already exists'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH