/* First we want to bump the size of LcApplication.SendVia */
DECLARE @ColumnSize int

SET @ColumnSize = (SELECT character_maximum_length    
  FROM information_schema.columns  
 WHERE table_name = 'LcApplication' AND COLUMN_NAME = 'SendVia')
IF @ColumnSize = 4 BEGIN
	ALTER TABLE LcApplication ALTER COLUMN SendVia varchar(10);
	print 'LcApplication.SendVia changed to varchar(10)'
END
ELSE BEGIN
	print 'LcApplication.SendVia already varchar(10)'
END

/* First we want to bump the size of LCAmendment.SendVia */

SET @ColumnSize = (SELECT character_maximum_length    
  FROM information_schema.columns  
 WHERE table_name = 'LCAmendment' AND COLUMN_NAME = 'SendVia')
IF @ColumnSize = 4 BEGIN
	ALTER TABLE LCAmendment ALTER COLUMN SendVia varchar(10);
	print 'LCAmendment.SendVia changed to varchar(10)'
END
ELSE BEGIN
	print 'LCAmendment.SendVia already varchar(10)'
END

SET @ColumnSize = (SELECT character_maximum_length    
  FROM information_schema.columns  
 WHERE table_name = 'LCHistoryBalance' AND COLUMN_NAME = 'SendVia')
IF @ColumnSize = 4 BEGIN
	ALTER TABLE LCHistoryBalance ALTER COLUMN SendVia varchar(10);
	print 'LCHistoryBalance.SendVia changed to varchar(10)'
END
ELSE BEGIN
	print 'LCHistoryBalance.SendVia already varchar(10)'
END

