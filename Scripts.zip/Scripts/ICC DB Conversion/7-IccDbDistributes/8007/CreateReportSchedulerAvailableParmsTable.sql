
BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='ReportSchedulerAvailableParms') 
		BEGIN 
			CREATE TABLE ReportSchedulerAvailableParms(
					PKey INT Constraint PK_ReportSchedulerAvailableParms_PKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
					Category varchar(50) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableParms_Category DEFAULT (''),
					GtsService varchar(4) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableParms_GtsService DEFAULT (''),
					FieldName varchar(100) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableParms_Prompt DEFAULT (''),
					FieldType varchar(1) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableParms_FieldType DEFAULT (''),
					FieldLength int NOT NULL Constraint DF_ReportSchedulerAvailableParms_FieldLength DEFAULT (0),
					Description varchar(50) NOT NULL CONSTRAINT DF_ReportSchedulerAvailableParms_Description DEFAULT ('')
        );
        CREATE  INDEX IX_ReportSchedulerAvailableParms_Category_GtsService ON ReportSchedulerAvailableParms(Category, GtsService);
        print 'Created ReportSchedulerAvailableParms table'
		END
		ELSE BEGIN
              print 'ReportSchedulerAvailableParms table already exists in this DB'
		END
		COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH
