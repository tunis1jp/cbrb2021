DECLARE @GroupLevelEntKey varchar(4)
DECLARE @GroupLevelPKey int
DECLARE @ADMGroupLevelPKey int
DECLARE @OrderBy int

DECLARE @AppLevelPKey int
DECLARE @ADMAppLevelPKey int
DECLARE @AppLevelEntKey as varchar(4)

DECLARE @ItemLevelPKey int
DECLARE @ItemLevelEntKey as varchar(3)

DECLARE @MenuDescription as varchar(25)
DECLARE @EntitlementDescription as varchar(25)
DECLARE @UserType varchar(1)
SET @UserType = 'A'
DECLARE @Href varchar(128)

SET @Href = 'Admin/ReportScheduler.aspx?Reset=Y'
/* ----------------------------------------------- */
/* Report Scheduler */
/* ----------------------------------------------- */
SET @GroupLevelEntKey = 'CAM'
SET @GroupLevelPKey = (SELECT GroupLevelPKey FROM UserMenuGroups WHERE GroupLevelEntKey = @GroupLevelEntKey)
IF @GroupLevelPKey > 0 BEGIN
		/* ------------------------------------------------- */
		/* */
		/* ------------------------------------------------- */
	SET @AppLevelEntKey = 'SEC'
	SET @AppLevelPKey = (SELECT AppLevelPKey FROM UserMenuApps WHERE GroupLevelPKey = @GroupLevelPKey AND AppLevelEntKey = @AppLevelEntKey)
	IF @AppLevelPKey > 0 BEGIN
		SET @ItemLevelPKey = (Select Max(ItemLevelPkey) From UserMenuItems)
		SET @ItemLevelPKey = @ItemLevelPKey + 1
		SET @ItemLevelEntKey = 'RTS'
		SET @OrderBy = 1
		IF NOT EXISTS (SELECT ItemLevelPKey FROM UserMenuItems WHERE GroupLevelPKey = @GroupLevelPKey AND AppLevelPKey = @AppLevelPKey AND ItemLevelEntKey = @ItemLevelEntKey) BEGIN
			SET @MenuDescription = 'Report Scheduler'
			SET @EntitlementDescription = 'Report Scheduler'
			
			INSERT INTO UserMenuItems
				(ItemLevelPKey
				,GroupLevelPKey
				,AppLevelPKey
				,AppLevelEntKey
				,MenuDescription
				,EntitlementDescription
				,ItemLevelEntKey
				,EntitlementIndex
				,OrderBy
				,HRef
				,UserType)
			VALUES 
				(@ItemLevelPKey, @GroupLevelPKey, @AppLevelPKey, @AppLevelEntKey
				,@MenuDescription, @EntitlementDescription, @ItemLevelEntKey
				,@ItemLevelPKey,@OrderBy
				,@Href, @UserType);
				
			Print N'Added UserMenuItem, ItemLevelPKey: '
					+ RTRIM(CAST(@ItemLevelPKey AS nvarchar(30))) + ', '
					+ RTRIM(@EntitlementDescription) + '-' + RTRIM(@MenuDescription) + '-' + RTRIM(@ItemLevelEntKey)
					
		END
		ELSE BEGIN
			print @GroupLevelEntKey + '-' + @AppLevelEntKey + '-' + @ItemLevelEntKey + ' UserMenuItems record already exists.'
		END
	END
	ELSE BEGIN
		print 'Failed to find UserMenuApps record for ' + @GroupLevelEntKey + '-' + @AppLevelEntKey
	END
END