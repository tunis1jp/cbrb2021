DECLARE @DbVersion int
DECLARE @Description varchar(MAX)
DECLARE @DateApplied datetime

SET @DbVersion = 8005
SET @Description = 'Added ShowSendVia, ShowSendViaSTB to ParmsIcc'

SET @DateApplied = GETDATE()

IF NOT EXISTS (SELECT PKey FROM aaaDbUpdateApplied WHERE DbVersion = @DbVersion) BEGIN
	INSERT INTO aaaDbUpdateApplied (DateApplied, DbVersion, Description)
		VALUES (@DateApplied, @DbVersion, @Description)
	print 'Added aaaDbUpdateApplied record for DbVersion: ' + RTRIM(CAST(@DbVersion AS nvarchar(5)))
END
ELSE BEGIN
	print 'aaaDbUpdateApplied record for DbVersion: ' + RTRIM(CAST(@DbVersion AS nvarchar(5))) + ' already exists'
END
