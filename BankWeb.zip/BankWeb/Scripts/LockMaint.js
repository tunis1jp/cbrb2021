// **********************************************************************
//
// **********************************************************************
//function CustomerChanged() {
//	var sId
//	var iIndex
//	
//	sId = ""
//	iIndex = -1
//	
//	// this list box does not have an empty option
//	// so we always use the selectedIndex
//	iIndex = document.LockMaint.lstCustomers.selectedIndex
//	
//	sId = document.LockMaint.lstCustomers[iIndex].value
//	document.location = "RecordLockMaint.aspx?Reset=Y" + "&CustId=" + sId
//}

// function to validate a field on a form
function Validate(form, button) {
	var iIndex = 0
	var iCnt = 0
	var iIdx = 0
			
	// customer id
	iIndex = form.lstCustomers.selectedIndex
	if (iIndex < 0) {
		alert ("Customer selection is required")
		form.lstCustomers.focus();
		return (false);
	}

	return(true);
}

function LockMaint_Submit(form, button){
	var bOk
	
	switch(button)	{
		case 0:  // BTNBACK															
			// cancel button pressed, now handled in submit routine
			//document.location = "../bank.asp?WCI=Main";		
			// so that session variables can be cleared
			//return (false);
			break;
			
		case 3:  // BTNDELETE
			if(!Validate(form, button)) {
				return (false);
			}
			bOk = confirm("Do you really want to delete these record locks ?")
			if (bOk == false) {
				return (false)
			}
			break;
		
		default:
			alert ("Button " + button + " not implemented.")
			return (false);
			break;
	}
	form.txtAction.value = button
	form.submit();
}

