DECLARE @Category varchar(50) 
DECLARE @GtsService varchar(4)
DECLARE @FieldName varchar(100) 
DECLARE @Description varchar(50) 
DECLARE @Formula varchar(max) 

SET @Category = 'LcBalance'
SET @GtsService = ''
SET @FieldName = 'FlagExpired'
SET @Description = 'Exclude Expired LCs'
SET @Formula = '(LcHistoryBalance.FlagExpired <> ''Y'')'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableFormulas WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName AND Description = @Description) BEGIN
	INSERT ReportSchedulerAvailableFormulas (Category, GtsService, FieldName, Description, Formula) 
											VALUES (@Category, @GtsService, @FieldName, @Description, @Formula)
	print 'Added ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @Category = 'LcBalance'
SET @GtsService = ''
SET @FieldName = 'FlagExpired'
SET @Description = 'Show Expired LCs'
SET @Formula = '(LcHistoryBalance.FlagExpired = ''Y'')'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableFormulas WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName AND Description = @Description) BEGIN
	INSERT ReportSchedulerAvailableFormulas (Category, GtsService, FieldName, Description, Formula) 
											VALUES (@Category, @GtsService, @FieldName, @Description, @Formula)
	print 'Added ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @Category = 'ColBalance'
SET @GtsService = ''
SET @FieldName = 'MaturityDate'
SET @Description = 'Collections with Maturity Date'
SET @Formula = '(ColHistoryBalance.MaturityDate > ''1/1/1900'')'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableFormulas WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName AND Description = @Description) BEGIN
	INSERT ReportSchedulerAvailableFormulas (Category, GtsService, FieldName, Description, Formula) 
											VALUES (@Category, @GtsService, @FieldName, @Description, @Formula)
	print 'Added ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @Category = 'ColBalance'
SET @GtsService = ''
SET @FieldName = 'MaturityDate'
SET @Description = 'Collections Past Maturity Date'
SET @Formula = '(DateDiff (d, ColHistoryBalance.MaturityDate, GetDate()) > 0 
AND ColHistoryBalance.MaturityDate > ''1/1/1900'')'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableFormulas WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName AND Description = @Description) BEGIN
	INSERT ReportSchedulerAvailableFormulas (Category, GtsService, FieldName, Description, Formula) 
											VALUES (@Category, @GtsService, @FieldName, @Description, @Formula)
	print 'Added ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableFormulas record: ' + @Category + ': ' + @FieldName + ' <' + @Description + '>' +
	 ' for GtsService <' + @GtsService + '> already exists'
END

