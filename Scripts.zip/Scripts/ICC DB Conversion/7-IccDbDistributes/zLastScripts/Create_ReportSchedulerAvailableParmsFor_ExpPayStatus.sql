DECLARE @Category varchar(50)
DECLARE @GtsService varchar(4)
DECLARE @FieldName varchar(100)
DECLARE @FieldType varchar(1)
DECLARE @FieldLength int
DECLARE @Description varchar(50)

/* ---------------------------------------------------------------- */
/* The following are all for the ExpPayStatus category */
/* ---------------------------------------------------------------- */
SET @Category = 'ExpPayStatus'
SET @GtsService = ''
SET @FieldName = 'PresentorsRefNum'
SET @FieldType = 'S'
SET @FieldLength = 16
SET @Description = 'Presentors Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'StatusDate'
SET @FieldType = 'D'
SET @FieldLength = 10
SET @Description = 'Status Date'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END
