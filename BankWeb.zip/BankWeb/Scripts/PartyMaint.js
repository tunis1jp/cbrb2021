﻿// ***************************************
// Script to manage Party Maintnenace
// ***************************************
function PosCursor(here) {
    here.focus();
}

function SetFocusTo(ControlName) {
    var ThisControl = $find(ControlName);
    
    if (ThisControl != null) {
        ThisControl.focus();
    }
    else {
        alert ("Could not find " + ControlName);
    }
}

function CheckDisabled(chk) {
    chk.checked = true
}

function CheckAll(master) {
    var iCnt;
    var checked = master.checked;
    
    chkPartyType = document.getElementsByName("chkPartyType");
	iCnt = chkPartyType.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        chkPartyType[iIdx].checked = checked;
    }
}
