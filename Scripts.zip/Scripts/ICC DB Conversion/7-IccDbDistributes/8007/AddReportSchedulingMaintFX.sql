DECLARE @PKey int
DECLARE @Description varchar(35)
DECLARE @URL varchar(128)
DECLARE @URLParameters varchar(128)
DECLARE @OrderBy int
DECLARE @SuperUserFunction varchar(1)
DECLARE @SessionPrefix varchar(5)
DECLARE @BankId int

/* These are to find the next available PKey */
DECLARE @FoundOne as bit
DECLARE @LastMenuItemPKey int
SET @LastMenuItemPKey = 999

SET @BankId = 1

/* ********************************************************************************************* */
/* ********************************************************************************************* */
SET @SessionPrefix = N'RSP_'
SET @Description = N'Report Scheduling Parameters'
SET @URL = N'BankSetup/RptSchedMaint.Aspx'
SET @URLParameters = ''
SET @OrderBy = 195
SET @SuperUserFunction = 'Y'
IF NOT EXISTS (SELECT PKey FROM BankMenuItems WHERE BankId = @BankId AND SessionPrefix = @SessionPrefix) BEGIN
	/* Find the next available PKey */
	SET @PKey = 1
	SET @FoundOne = 0
	WHILE @PKey <= @LastMenuItemPKey AND @FoundOne = 0
	BEGIN
		IF NOT EXISTS (SELECT PKey FROM BankMenuItems WHERE PKey = @PKey) BEGIN
			SET @FoundOne = 1
		END
		ELSE BEGIN
			SET @PKey = @PKey + 1
		END
	END
	
	INSERT BankMenuItems (PKey, Description, URL, URLParameters, OrderBy, SuperUserFunction, SessionPrefix, BankId, EntitlementIndex)
 		VALUES (@PKey, @Description, @URL, @URLParameters, @OrderBy, @SuperUserFunction, @SessionPrefix, @BankId, @PKey)
	print 'Added BankMenuItems record: ' + @SessionPrefix + '-' + @Description + ', PKey: ' + RTRIM(CAST(@PKey AS nvarchar(5))) 
END
ELSE BEGIN
	print 'Session prefix ' + @SessionPrefix + ' already exists in BankMenuItems'
END

