function replaceChecks(master, sClass) {
    //get all the input fields on the inside of the form
    inputs = document.getElementsByTagName('input');
    var chkValue = false;

    //cycle trough the input fields
    for (var i = 0; i < inputs.length; i++) {
        //Checks All Functions
        if (sClass == 'chkAll') {
            if (inputs[i].className == 'chkAll') {
                if (inputs[i].checked == true) {
                    chkValue = true;
                } else { chkValue = false;  }
                replaceCheck(inputs, chkValue)
            }
        }
    }
}
function replaceCheck(sInput, sValue) {
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].className == 'chkEnt') {
            if (sValue == false) {
                inputs[i].checked = false;
            } else 
            {
                inputs[i].checked = true;
            }
        }
    }
}


function BankUserData_Submit(form, button){
	var bOk
	
	switch(button)	{
		case 0:  // BTNBACK												
			// cancel button pressed, now handled in submit routine
			//document.location = "../bank.asp";	
			// so that session variables can be cleared
			//return (false);
			break;

		case 1:  // BTNADDNEW
			if(!Validate(form, button)) {
				return (false);
			}
			break;
			
		case 2:  // BTNUPDATE
			if(!Validate(form, button)) {
				return (false);
			}
			break;
			
		case 3:  // BTNDELETE
			if(!Validate(form, button)) {			// for user selection requirement
				return (false);
			}
			bOk = confirm("Do you really want to delete this Bank User ?")
			if (bOk == false) {
				return (false)
			}
			break;
	}
	form.txtAction.value = button
	form.submit();
	
}