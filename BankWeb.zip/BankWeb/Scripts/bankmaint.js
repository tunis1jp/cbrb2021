// var BTNBACK = 0
// var BTNADDNEW = 1
// var BTNUPDATE = 2
// var BTNDELETE = 3

function ChangedAuthenticationType (form) {
	var lIndex;
	
	lIndex = form.lstAuthenticationType.selectedIndex;
	switch (lIndex) {
		case 0:
		case 1:
			form.chkChallengeQuestions.checked = false
			form.chkPictureVerification.checked = false
			break;
			
		case 2:		// challenge authentication
			form.chkChallengeQuestions.checked = true
			form.chkPictureVerification.checked = true
			break;
			
		default:
	}
	return (true);
}

////////////////////////////////////////////////////////////////
// function to validate a field on a form for bank maint
function Validate(form, button){
	var lIndex;
			
	if(!CheckRequired(document.BankMaint.txtProductName))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtName))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtBankCode))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtAddress1))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtHomePage))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtStyleSheet))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtImageDir))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtBankHomePage))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtBankStyleSheet))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtBankImageDir))		
     	return(false);

	if(!CheckRequired(document.BankMaint.txtPasswordLength))		
     	return(false);

	if (!IsNumeric(document.BankMaint.txtPasswordLength))
		return(false);

	if(!CheckRequired(document.BankMaint.txtPasswordInterval))		
     	return(false);

	if (!IsNumeric(document.BankMaint.txtPasswordInterval))
		return(false);

	if(!CheckRequired(document.BankMaint.txtPasswordsToSave))		
     	return(false);

	if (!IsNumeric(document.BankMaint.txtPasswordsToSave))
		return(false);

	if(!CheckRequired(document.BankMaint.txtLogonTries))		
     	return(false);

	if (!IsNumeric(document.BankMaint.txtLogonTries))
		return(false);
		
	lIndex = document.BankMaint.lstAuthenticationType.selectedIndex;
	switch (lIndex) {
		case 0:
		case 1:
			if ((form.chkChallengeQuestions.checked == true) || (form.chkPictureVerification.checked == true)) {
				alert("Challenge Questions and Picture Verification are not allowed for the authentication type you have selected.");
				return (false);
			}
			break;
			
		case 2:		// challenge authentication
			if ((form.chkChallengeQuestions.checked == false) && (form.chkPictureVerification.checked == false)) {
				alert("One of Challenge Questions and/ or Picture Verification is required for the Challenge authentication type.");
				return (false);
			}
			break;
			
		default:
	}

	return(true);
}

function BankMaint_Submit(form, button){
	var bOk
	
	switch(button)	{
		case 0:  // BTNBACK													
			// cancel button pressed, now handled in submit routine
			//document.location = "../icc.asp?WCI=Main";		
			// so that session variables can be cleared
			//return (false);
			break;
			
		case 1:  // BTNADDNEW
			if(!Validate(form, button)) {
				return (false);
			}
			break;
			
		case 2:  // BTNUPDATE
			if(!Validate(form, button)) {
				return (false);
			}
			break;
			
		case 3:  // BTNDELETE
			bOk = confirm("Do you really want to delete this Bank ?")
			if (bOk == false) {
				return (false)
			}
			break;
		
		default:
			alert ("Button " + button + " not implemented.")
			return (false);
			break;
	}
	form.txtAction.value = button
	form.submit();
}

function BankChanged() {
	var sBankPKey
	var iIndex
	
	sBankPKey = "-1"		// -1 is Add New for Bank maint.
	iIndex = -1
	
	// this list box does not have an empty option
	// so we always use the selectedIndex
	iIndex = document.BankMaint.lstBanks.selectedIndex
	
	sBankPKey = document.BankMaint.lstBanks[iIndex].value
	
	document.location = "BankMaint.asp?WCI=BankMaint" + "&PKey=" + sBankPKey + "&clr=Y"
}
