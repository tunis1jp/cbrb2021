if not exists (select column_name  from INFORMATION_SCHEMA.columns
               where table_name = 'RepParmCust' and column_name = 'Formula') BEGIN
	Alter Table RepParmCust
	Add Formula varchar(MAX) Not Null
	Constraint DF_RepParmCust_Formula Default ''

	print 'Added Formula Column to RepParmCust'
END
ELSE BEGIN
	print 'Formula Column already exists in RepParmCust'
END

