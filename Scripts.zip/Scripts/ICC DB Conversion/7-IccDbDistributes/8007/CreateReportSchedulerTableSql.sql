/* ******************************************* */

/* Report Scheduler Table */

/* ******************************************* */
BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='ReportScheduler') 
			BEGIN 
                CREATE TABLE ReportScheduler(
                                SchedulerPkey int PRIMARY KEY IDENTITY(1,1) NOT NULL,
                                ReportFkey int NOT NULL CONSTRAINT DF_ReportScheduler_ReportFkey DEFAULT (0),
                                BankID int NOT NULL CONSTRAINT DF_ReportScheduler_BankID Default(0),
                                CustomerID int NOT NULL CONSTRAINT DF_ReportScheduler_CustomerID Default(0),
                                BranchID int NOT NULL CONSTRAINT DF_ReportScheduler_BranchID Default(0),
                                HowDelivered VARCHAR(64) NOT NULL CONSTRAINT DF_ReportScheduler_HowDelivered Default(''),
                                ReportFormat VARCHAR(4) NOT NULL CONSTRAINT DF_ReportScheduler_ReportFormat Default(''),
                                Runtime DATETIME2 NOT NULL CONSTRAINT DF_ReportScheduler_Runtime Default('1-1-1900'),
                                TimeZone varchar(3) NOT NULL CONSTRAINT DF_ReportScheduler_TimeZone Default(''),
                                Monday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Monday Default(0),
                                Tuesday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Tuesday Default(0),
                                Wednesday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Wednesday Default(0),
                                Thursday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Thursday Default(0),
								Friday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Friday Default(0),
                                Saturday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Saturday Default(0),
                                Sunday BIT NOT NULL CONSTRAINT DF_ReportScheduler_Sunday Default(0),
                                QTR_First BIT NOT NULL CONSTRAINT DF_ReportScheduler_QTR_First Default(0),
                                QTR_Last BIT NOT NULL CONSTRAINT DF_ReportScheduler_QTR_Last Default(0),
                                MNTH_First BIT NOT NULL CONSTRAINT DF_ReportScheduler_MNTH_First Default(0),
                                MNTH_Last BIT NOT NULL CONSTRAINT DF_ReportScheduler_MNTH_Last Default(0),
                                                                Email_NoData BIT NOT NULL CONSTRAINT DF_ReportScheduler_Email_NoData Default(0),
                                ArchiveDays int NOT NULL CONSTRAINT DF_ReportScheduler_ArchiveDays Default(0),
                                RptLastRun DATETIME2 NOT NULL CONSTRAINT DF_ReportScheduler_RptLastRun Default('1-1-1900'),
                );
                CREATE  INDEX IX_ReportScheduler_SchedulerPkey ON ReportScheduler(SchedulerPkey);
                print 'Created SchedulerPkey table'
			END
			ELSE BEGIN
                print 'SchedulerPkey table already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH