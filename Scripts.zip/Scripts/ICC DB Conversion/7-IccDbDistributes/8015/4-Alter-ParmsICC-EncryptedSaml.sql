/* ******************************************* */
/* Alter ParmsICC Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE TABLE_NAME='ParmsICC' and Column_Name = 'EncryptedSaml') 
			BEGIN 
                Alter TABLE ParmsICC Add EncryptedSaml bit NOT NULL CONSTRAINT DF_ParmsICC_EncryptedSaml DEFAULT(0);
                print 'Altered ParmsICC Table. Added EncryptedSaml column.'
			END
			ELSE BEGIN
                print 'EncryptedSaml column already exists'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH