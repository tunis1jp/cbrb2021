
BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='aaaDbUpdateApplied') 
		BEGIN 
			CREATE TABLE aaaDbUpdateApplied(
					PKey INT Constraint PK_aaaDbUpdateApplied_PKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
					DbVersion int NOT NULL Constraint DF_aaaDbUpdateApplied_DbVersion DEFAULT (0),
					Description varchar(MAX) NOT NULL CONSTRAINT DF_aaaDbUpdateApplied_Description DEFAULT (''),
          DateApplied DATETIME NOT NULL CONSTRAINT DF_aaaDbUpdateApplied_DataGenerated Default ('1-1-1900')
        );
        print 'Created aaaDbUpdateApplied table'
		END
		ELSE BEGIN
              print 'aaaDbUpdateApplied table already exists in this DB'
		END
		COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH
