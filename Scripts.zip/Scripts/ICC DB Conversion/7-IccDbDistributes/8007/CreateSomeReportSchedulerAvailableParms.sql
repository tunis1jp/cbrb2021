DECLARE @Category varchar(50)
DECLARE @GtsService varchar(4)
DECLARE @FieldName varchar(100)
DECLARE @FieldType varchar(1)
DECLARE @FieldLength int
DECLARE @Description varchar(50)

/* ---------------------------------------------------------------- */
/* The following are all for the LcBalance category */
/* ---------------------------------------------------------------- */
SET @Category = 'LcBalance'
SET @GtsService = ''
SET @FieldName = 'ExpirationDate'
SET @FieldType = 'D'
SET @FieldLength = 10
SET @Description = 'Expiration Date'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'BankReference'
SET @FieldType = 'S'
SET @FieldLength = 8
SET @Description = 'Bank Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'BeneName'
SET @FieldType = 'S'
SET @FieldLength = 35
SET @Description = 'Beneficiary'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'CurrencyCode'
SET @FieldType = 'S'
SET @FieldLength = 3
SET @Description = 'Currency Code'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = 'EXP'
SET @FieldName = 'OpnrCountry.Name'
SET @FieldType = 'S'
SET @FieldLength = 50
SET @Description = 'Issuing Country'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = 'EXP'
SET @FieldName = 'OpnrName'
SET @FieldType = 'S'
SET @FieldLength = 35
SET @Description = 'Issuing Bank'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = 'EXP'
SET @FieldName = 'OurReference'
SET @FieldType = 'S'
SET @FieldLength = 25
SET @Description = 'Issuing Bank Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = 'IMP'
SET @FieldName = 'OurReference'
SET @FieldType = 'S'
SET @FieldLength = 25
SET @Description = 'Your Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = 'STB'
SET @FieldName = 'OurReference'
SET @FieldType = 'S'
SET @FieldLength = 25
SET @Description = 'Your Reference'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

SET @GtsService = ''
SET @FieldName = 'FlagExpired'
SET @FieldType = 'F'
SET @FieldLength = 1
SET @Description = 'Expired LCs'

IF NOT EXISTS (SELECT PKey FROM ReportSchedulerAvailableParms WHERE Category = @Category 
											AND GtsService = @GtsService AND FieldName = @FieldName) BEGIN
	INSERT ReportSchedulerAvailableParms (Category, GtsService, FieldName, FieldType, FieldLength, Description) 
											VALUES (@Category, @GtsService, @FieldName, @FieldType, @FieldLength, @Description)
	print 'Added ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	' for GtsService <' + @GtsService + '>'
END
ELSE BEGIN
	print 'ReportSchedulerAvailableParms record: ' + @Category + ': ' + @FieldName +
	 ' for GtsService <' + @GtsService + '> already exists'
END

