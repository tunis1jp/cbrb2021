BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='ReportSchedulerParms') 
			BEGIN 
				CREATE TABLE ReportSchedulerParms(
						ParmsPKey INT Constraint PK_ReportSchedulerParms_ParmsPKeyPKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
						ReportSchedulerFKey int NOT NULL Constraint DF_ReportSchedulerParms_ReportSchedulerFKey DEFAULT (0),
						FieldName varchar(100) NOT NULL CONSTRAINT DF_ReportSchedulerParms_FieldName DEFAULT (''),
						Operator varchar(25) NOT NULL Constraint DF_ReportSchedulerParms_Operator DEFAULT (''),
						ValueForComparison varchar(max) NOT NULL CONSTRAINT DF_ReportSchedulerParms_ValueForComparison DEFAULT (''),
						Formula varchar(max) NOT NULL CONSTRAINT DF_ReportSchedulerParms_Formula DEFAULT ('')
          );
          CREATE  INDEX IX_ReportSchedulerParms_ReportSchedulerFKey ON ReportSchedulerParms(ReportSchedulerFKey);
          print 'Created ReportSchedulerParms table'
			END
			ELSE BEGIN
                print 'ReportSchedulerParms table already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH
