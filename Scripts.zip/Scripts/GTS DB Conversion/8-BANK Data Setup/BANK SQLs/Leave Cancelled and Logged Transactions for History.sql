----This will leave records in the database on cancelled items from Wip
update parmsgts
set DeleteCancelledTrans = 'N'


Update ServiceProduct
set InqOptions = '20'
where product = 'log'