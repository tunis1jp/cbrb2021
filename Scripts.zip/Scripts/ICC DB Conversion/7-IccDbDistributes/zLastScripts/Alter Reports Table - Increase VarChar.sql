/* ******************************************* */
/* Alter Reports Table - Increase VarChar Size */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
			BEGIN 
               Alter Table Reports
			   Alter Column ReportDescription varchar(100)
			END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH