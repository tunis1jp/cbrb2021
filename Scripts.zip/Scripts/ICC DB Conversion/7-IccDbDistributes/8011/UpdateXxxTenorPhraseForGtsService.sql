UPDATE xxxTenorPhrase SET GtsService = 'IMP,STB,DIR,CEX' WHERE GtsService = ''
