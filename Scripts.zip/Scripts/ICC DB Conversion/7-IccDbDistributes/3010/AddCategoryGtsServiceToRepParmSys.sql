if not exists (select column_name  from INFORMATION_SCHEMA.columns
               where table_name = 'RepParmSys' and column_name = 'Category') BEGIN
	Alter Table RepParmSys
	Add Category varchar(50) Not Null
	Constraint DF_RepParmSys_Category Default ''

	print 'Added Category Column to RepParmSys'
END
ELSE BEGIN
	print 'Category Column already exists in RepParmSys'
END

if not exists (select column_name  from INFORMATION_SCHEMA.columns
               where table_name = 'RepParmSys' and column_name = 'GtsService') BEGIN
	Alter Table RepParmSys
	Add GtsService varchar(4) Not Null
	Constraint DF_RepParmSys_GtsService Default ''

	print 'Added GtsService Column to RepParmSys'
END
ELSE BEGIN
	print 'GtsService Column already exists in RepParmSys'
END
