/* ******************************************* */
/* Alter Bankusers Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF  NOT EXISTS (SELECT * FROM sys.columns  WHERE NAME = N'Salt' and Object_ID = Object_ID(N'Users'))
		BEGIN
			ALTER TABLE Users ADD
				Salt VARCHAR(256) NOT NULL CONSTRAINT DF_Users_Salt DEFAULT '';
			print 'Salt added to Users table'
		END
		ELSE BEGIN
			print 'Salt already in Users table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

