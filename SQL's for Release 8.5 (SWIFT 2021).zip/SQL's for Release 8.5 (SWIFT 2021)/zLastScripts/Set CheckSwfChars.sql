Update parmsgts
set CheckSwfChars = 'Y'