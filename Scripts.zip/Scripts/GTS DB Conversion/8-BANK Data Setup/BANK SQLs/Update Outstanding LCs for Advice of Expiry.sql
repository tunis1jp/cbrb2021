 Update BalLocPrimary set AdviceOfExpirySent = 'No', AdviceOfExpiryNotifyBene = '40'
 where ( Autoexttermsmonth = 0 and AutoextNotifDay = 0)
 and IRDB = 0  and expired = 0 and lettertype = 'STB'