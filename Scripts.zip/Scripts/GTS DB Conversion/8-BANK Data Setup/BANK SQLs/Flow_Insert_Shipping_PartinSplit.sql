-- insert shipping parties
if not exists (select * from flow where chk_box_tag = 'SHIPPINGPARTIES') insert into [Flow]  values ('XX', 'DD', 'ALL', 'Shipping Parties', 'SHIPPINGPARTIES', 8, 0, 'Shipping Parties', 0, 1, 'SHIPPARTY', 0, '1900-01-01 00:00:00.000', '1900-01-01 00:00:00.000', 'N', 'N')
-- insert PartInFeeSplit
if not exists (select * from flow where chk_box_tag = 'PARTINFEESPLIT') insert into [Flow]  values ('XX', 'DD', 'ALL', 'Part In Fee Maintenance', 'PARTINFEESPLIT', 8, 0, 'Part In Fee', 0, 1, 'PARTINFEE', 0, '1900-01-01 00:00:00.000', '1900-01-01 00:00:00.000', 'N', 'N')