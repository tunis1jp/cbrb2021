/* ******************************************* */
/* Update UserMenuItems Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF (Select ItemLevelEntKey from UserMenuItems where AppLevelEntKey = 'OUT' and MenuDescription='Drafts') = 'WIP'
		BEGIN
	Update UserMenuItems set ITemLevelEntKey = 'MOD' where AppLevelEntKey = 'OUT' and MenuDescription='Drafts'
	print 'UserMenuItem OUT Modified from WIP to MOD in the UserMenuItems Table'
END
		ELSE BEGIN
	print 'UserMenuItem OUT in the UserMenuItems Table already updated'
END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

