
/* ******************************************* */
/* Update Reports Table - Add LC Type to Application */
/* ******************************************* */

BEGIN TRY
    BEGIN TRAN;
    BEGIN

/* ******************************************* */
/* Update Reports Table - Add LC Type to Application */
/* ******************************************* */

BEGIN TRY
    BEGIN TRAN;
    BEGIN
		UPDATE Reports  SET  ReportDescription = 'Acceptance Payments by Bank Reference' where ReportName = 'AccPayByBankRef.Rpt' and GroupLevelEntKey = 'ACC' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Acceptances by Applicant Reference' where ReportName = 'AccByAppRef.Rpt' and GroupLevelEntKey = 'ACC' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Acceptances by Bank Reference' where ReportName = 'AccByBankRef.Rpt' and GroupLevelEntKey = 'ACC' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Acceptances by Maturity Date and Pay To' where ReportName = 'AccByMtOp.Rpt' and GroupLevelEntKey = 'ACC' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Acceptances by Tenor Date and Pay To' where ReportName = 'AccByAcOp.Rpt' and GroupLevelEntKey = 'ACC' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'ADM Party by Country' where ReportName = 'PartyByCountry.rpt' and GroupLevelEntKey = 'ADM' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'ADM Party By Name' where ReportName = 'PartyByName.rpt' and GroupLevelEntKey = 'ADM' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'ADM Party' where ReportName = 'Party.rpt' and GroupLevelEntKey = 'ADM' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'ADM Balance By Icc Product' where ReportName = 'rptOutStandingLcBal.rpt' and GroupLevelEntKey = 'ADM' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'ADM Clauses' where ReportName = 'ClauseReport.rpt' and GroupLevelEntKey = 'ADM' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'CAM Wip Status Report' where ReportName = 'WipStatus.rpt' and GroupLevelEntKey = 'CAM' and AppLevelEntKey = 'SEC'
		UPDATE Reports  SET  ReportDescription = 'CAM Users' where ReportName = 'WebUsers.rpt' and GroupLevelEntKey = 'CAM' and AppLevelEntKey = 'SEC'
		UPDATE Reports  SET  ReportDescription = 'CAM L/C Audit Report' where ReportName = 'LCAuditReport.rpt' and GroupLevelEntKey = 'CAM' and AppLevelEntKey = 'SEC'
		UPDATE Reports  SET  ReportDescription = 'CAM Collection Audit Report' where ReportName = 'COLAuditReport.rpt' and GroupLevelEntKey = 'CAM' and AppLevelEntKey = 'SEC'
		UPDATE Reports  SET  ReportDescription = 'Direct Export Collection' where ReportName = 'CexAppEnt.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'Export Collection Letter Amendment Status' where ReportName = 'ColAppXmdStatus.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collections by Bank Reference' where ReportName = 'ColBalByBankRef.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collections by Drawee' where ReportName = 'ColBalByDrawee.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collections by Drawee''s Country' where ReportName = 'ColBalByDrweCntry.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collections by Drawer''s Reference Number' where ReportName = 'ColBalByDrwrRef.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collections by Maturity Date' where ReportName = 'ColBalOutByMat.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collections Outstanding Past Maturity Date' where ReportName = 'ColBalPastMat.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collection Payment by Date' where ReportName = 'ColHstPayByDate.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Tracer Request/Status Update on Export Collections' where ReportName = 'ColTracerRequest.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Collection Template' where ReportName = 'CexAppEnt.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'TMP'
		UPDATE Reports  SET  ReportDescription = 'Export Collection Amendment Application' where ReportName = 'ColXmd.rpt' and GroupLevelEntKey = 'CEX' and AppLevelEntKey = 'XMD'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collections by Maturity Date' where ReportName = 'ColBalOutByMat.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collections Outstanding Past Maturity' where ReportName = 'ColBalPastMat.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collection Payment by Date' where ReportName = 'ColHstPayByDate.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collections by Bank Reference' where ReportName = 'ColBalByBankRef.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collections by Drawee' where ReportName = 'ColBalByDrawee.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collections by Drawee Country' where ReportName = 'ColBalByDrweCntry.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Incoming Collection Payment' where ReportName = 'LcAdminMsgs.rpt' and GroupLevelEntKey = 'CIM' and AppLevelEntKey = 'PAY'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Letter Application' where ReportName = 'ColEnt.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Application Status' where ReportName = 'ColAppEntStatus.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Amendment Application Status' where ReportName = 'ColAppXmdStatus.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Balance by Bank Reference' where ReportName = 'ColBalByBankRef.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Balance by Drawee' where ReportName = 'ColBalByDrawee.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Balance by Drawee Country' where ReportName = 'ColBalByDrweCntry.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Balance by Drawer Reference' where ReportName = 'ColBalByDrwrRef.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Balance Outstanding By Maturity' where ReportName = 'ColBalOutByMat.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Balance Past Maturity' where ReportName = 'ColBalPastMat.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Payment History by Date' where ReportName = 'ColHstPayByDate.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Tracer Request' where ReportName = 'ColTracerRequest.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Clauses' where ReportName = 'ClauseReport.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Letter Template' where ReportName = 'ColEnt.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'TMP'
		UPDATE Reports  SET  ReportDescription = 'Direct Collection Amendment Application' where ReportName = 'ColXmd.rpt' and GroupLevelEntKey = 'DIR' and AppLevelEntKey = 'XMD'
		UPDATE Reports  SET  ReportDescription = 'Export LC Acceptance Payments by Bank Reference' where ReportName = 'AccPayByBankRef.Rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Export LC Acceptances by Applicant Reference' where ReportName = 'AccByAppRef.Rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Export LC Acceptances by Bank Reference' where ReportName = 'AccByBankRef.Rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Export LC Acceptances by Maturity Date and Drawer' where ReportName = 'AccByMtOp.Rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Export LC Acceptances by Tenor Date and Drawer' where ReportName = 'AccByAcOp.Rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Export L/C Discrepancies' where ReportName = 'LcAdminMsgs.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'DIS'
		UPDATE Reports  SET  ReportDescription = 'Export CSV Balance History Field Report' where ReportName = 'CSVBalHistFieldRpt.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Balance by Issuing Bank' where ReportName = 'ExpLcBalByBeneIssue.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Balance by Country and Expiry Date' where ReportName = 'ExpLcBalByCntryExp.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Balance by Issuing Bank Reference' where ReportName = 'ExpLcBalByIssueRef.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Balance by Bank Reference' where ReportName = 'ExpLcBalByBankRef.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Payments by Payment Date' where ReportName = 'LcPayByPayDate.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export L/C Acceptances by Bank Reference' where ReportName = 'LcAccDraftByBankRef.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Liability by Beneficiary' where ReportName = 'ExpBalByBene.Rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Presentation Detail Status Report' where ReportName = 'ExpPresDetail.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Pending Payment Status Report' where ReportName = 'ExpPendingPayments.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Export Payment Summary Report' where ReportName = 'ExpPaymentSummary.rpt' and GroupLevelEntKey = 'EXP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import LC Acceptance Payments by Bank Reference' where ReportName = 'AccPayByBankRef.Rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Import LC Acceptances by Applicant Reference' where ReportName = 'AccByAppRef.Rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Import LC Acceptances by Bank Reference' where ReportName = 'AccByBankRef.Rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Import LC Acceptances by Maturity Date and Drawer' where ReportName = 'AccByMtOp.Rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Import LC Acceptances by Tenor Date and Drawer' where ReportName = 'AccByAcOp.Rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'ACC'
		UPDATE Reports  SET  ReportDescription = 'Import L/C Discrepancies' where ReportName = 'LcAdminMsgs.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'DIS'
		UPDATE Reports  SET  ReportDescription = 'Import L/C Application' where ReportName = 'LcImpEnt.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'Import Application Status' where ReportName = 'LcAppEntStatus.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Amendment Application Status' where ReportName = 'LcAppXmdStatus.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Balance by Beneficiary and Expiry Date' where ReportName = 'LcBalByBeneExp.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Balance by Customer Reference' where ReportName = 'LcBalByCustRef.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Payments by Payment Date' where ReportName = 'LcPayByPayDate.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import CSV Balance History Field Report' where ReportName = 'CSVBalHistFieldRpt.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Clauses' where ReportName = 'ClauseReport.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import By Bank Ref. and Amount' where ReportName = 'LcBalByBankRef.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Outstanding Discrepant Documents' where ReportName = 'DiscrpMsgs.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import L/C Acceptances by Bank Reference' where ReportName = 'LcAccDraftByBankRef.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Letters of Credit Issued by Issue Date' where ReportName = 'LcIssByIssDate.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Letter of Credit Liability by Customer Reference' where ReportName = 'LcBalByCustRefCAP1.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Charges by Charge Date' where ReportName = 'LcChgByChargeDate.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Letters of Credit Amended by Transaction Date' where ReportName = 'LcXmdByTranDate.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import Balance by Opener' where ReportName = 'LcBalByOpnrCustRef.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Import L/C Template' where ReportName = 'LcImpEnt.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'TMP'
		UPDATE Reports  SET  ReportDescription = 'Import Amendment Application' where ReportName = 'LcImpXmd.rpt' and GroupLevelEntKey = 'IMP' and AppLevelEntKey = 'XMD'
		UPDATE Reports  SET  ReportDescription = 'Steamship Application' where ReportName = 'SarEnt.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'Steamship Application Status' where ReportName = 'SarAppEntStatus.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Steamship Report by Steamship Reference' where ReportName = 'SarBalByCustRef.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Steamship Report by Applicant and Steamship Ref.' where ReportName = 'SarBalByOpnrCustRef.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Outstanding Steamship/ Air Release by Reference' where ReportName = 'SarBalByCustRefUncanceled.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Paid Steamship/ Air Release by Reference' where ReportName = 'SarBalByCustRefCanceled.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'SAR CSV Balance History Field Report' where ReportName = 'CSVBalHistFieldRpt.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Steamship Template' where ReportName = 'SarEnt.rpt' and GroupLevelEntKey = 'SAR' and AppLevelEntKey = 'TMP'
		UPDATE Reports  SET  ReportDescription = 'Supply Chain Finance Application' where ReportName = 'ScfEnt.rpt' and GroupLevelEntKey = 'SCF' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'Supply Chain Finance Template' where ReportName = 'ScfEnt.rpt' and GroupLevelEntKey = 'SCF' and AppLevelEntKey = 'TMP'
		UPDATE Reports  SET  ReportDescription = 'Standby L/C Application' where ReportName = 'LcStbEnt.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'ENT'
		UPDATE Reports  SET  ReportDescription = 'Standby Balance by Bank Reference' where ReportName = 'LcBalByBankRef.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Balance by Beneficiary and Expiry Date' where ReportName = 'LcBalByBeneExp.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Balance by Customer Reference' where ReportName = 'LcBalByCustRef.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Amendment Application Status' where ReportName = 'LcAppXmdStatus.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Application Status' where ReportName = 'LcAppEntStatus.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Payments by Payment Date' where ReportName = 'LcPayByPayDate.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Clauses' where ReportName = 'ClauseReport.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby CSV Balance History Field Report' where ReportName = 'CSVBalHistFieldRpt.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby L/C Template' where ReportName = 'LcStbEnt.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'TMP'
		UPDATE Reports  SET  ReportDescription = 'Standby Amendment Application' where ReportName = 'LcStbXmd.rpt' and GroupLevelEntKey = 'STB' and AppLevelEntKey = 'XMD'
		UPDATE Reports  SET  ReportDescription = 'Standby Advised Balance by Bank Reference' where ReportName = 'StbaLcBalByBankRef.rpt' and GroupLevelEntKey = 'STBA' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Advised Balance by Issuing Bank' where ReportName = 'StbaLcBalByBeneIssue.rpt' and GroupLevelEntKey = 'STBA' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Advised Balance by Country and Expiry Date' where ReportName = 'StbaLcBalByCntryExp.rpt' and GroupLevelEntKey = 'STBA' and AppLevelEntKey = 'INQ'
		UPDATE Reports  SET  ReportDescription = 'Standby Advised Payments by Payment Date' where ReportName = 'StbaPayByPayDate.rpt' and GroupLevelEntKey = 'STBA' and AppLevelEntKey = 'INQ'
      End                               ;
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    PRINT 'Error modifying table. See the following message: ' + ERROR_MESSAGE();
END CATCH;

      End                               ;
    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    PRINT 'Error modifying table. See the following message: ' + ERROR_MESSAGE();
END CATCH;