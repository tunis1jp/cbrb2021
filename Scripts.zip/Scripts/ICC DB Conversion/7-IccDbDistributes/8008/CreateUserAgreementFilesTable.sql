IF NOT EXISTS (SELECT *
           FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_TYPE='BASE TABLE' 
           AND TABLE_NAME='UserAgreementFiles') BEGIN

	CREATE TABLE UserAgreementFiles(
		PKey INT Constraint PK_UserAgreementFiles_PKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
		GtsService varchar(4) NOT NULL CONSTRAINT DF_UserAgreementFiles_GtsService DEFAULT (''),
		DisplayName varchar(75) NOT NULL CONSTRAINT DF_UserAgreementFiles_DisplayName  DEFAULT (''),
		FileName varchar(255) NOT NULL CONSTRAINT DF_UserAgreementFiles_FileName  DEFAULT (''),
		FileData varchar(max) NOT NULL CONSTRAINT DF_UserAgreementFiles_FileData  DEFAULT (''),
		AddedOnDate datetime NOT NULL CONSTRAINT DF_UserAgreementFiles_AddedOnDate  DEFAULT (1/1/1900),
		AddedBy varchar(50) NOT NULL CONSTRAINT DF_UserAgreementFiles_AddedBy  DEFAULT (''),
		Active varchar(1) NOT NULL CONSTRAINT UserAgreementFiles_Active DEFAULT ('Y'),
		OrderBy int NOT NULL CONSTRAINT UserAgreementFiles_OrderBy DEFAULT (0)
	);
		
CREATE  INDEX IX_UserAgreementFiles_GtsService ON UserAgreementFiles(GtsService);
	
	print 'Created UserAgreementFiles table'
END
ELSE BEGIN
	print 'UserAgreementFiles table already exists in this DB'
END
