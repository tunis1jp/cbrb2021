
/* ******************************************* */
/* Alter ParmsICC Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		if EXISTS (select column_name
from INFORMATION_SCHEMA.columns
where table_name = 'ParmsICC' and column_name = 'BankUserFromAD')
BEGIN
    Alter Table ParmsICC
    DROP CONSTRAINT DF_ParmsICC_BankUserFromAD 
	print 'Dropped constraint for BankUserFromAD Column'

	Alter Table ParmsICC
    DROP Column BankUserFromAD
	print 'Dropped original column for BankUserFromAD '

	Alter Table ParmsICC
	Add BankUserFromAD BIT NOT NULL CONSTRAINT DF_ParmsICC_BankUserFromAD DEFAULT (0);
    print 'Altered BankUserFromAD Column'
END
ELSE BEGIN
    print 'BankUserFromAD Column already exists in ParmsICC'
END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

