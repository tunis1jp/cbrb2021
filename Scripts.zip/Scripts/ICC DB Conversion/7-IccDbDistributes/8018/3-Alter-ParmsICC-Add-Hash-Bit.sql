/* ******************************************* */
/* Alter ParmsICC Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF  NOT EXISTS (SELECT * FROM sys.columns  WHERE NAME = N'ICCWebHashedPW' and Object_ID = Object_ID(N'ParmsICC'))
		BEGIN
			ALTER TABLE ParmsICC ADD
				ICCWebHashedPW BIT NOT NULL CONSTRAINT DF_ParmsICC_ICCWebHashedPW DEFAULT (0);
			print 'ICCWebHashedPW added to ParmsICC table'
		END
		ELSE BEGIN
			print 'ICCWebHashedPW already in ParmsICC table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

