/* ******************************************* */
/* xxxFinanceType */
/* ******************************************* */
IF NOT EXISTS (SELECT *
           FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_TYPE='BASE TABLE' 
           AND TABLE_NAME='xxxFinanceType') BEGIN
	CREATE TABLE xxxFinanceType(
		LegalEntity varchar(2) NOT NULL CONSTRAINT DF_xxxFinanceType_LegalEntity DEFAULT (''),
		BankId int NOT NULL CONSTRAINT DF_xxxFinanceType_BankId DEFAULT (1),
		Code varchar(3) NOT NULL CONSTRAINT DF_xxxFinanceType_Code DEFAULT (''),
		Description varchar(25) NOT NULL CONSTRAINT DF_xxxFinanceType_Description DEFAULT (''),
		Active varchar(1) NOT NULL CONSTRAINT DF_xxxFinanceType_Active DEFAULT (''),
		OrderBy int NOT NULL CONSTRAINT DF_xxxFinanceType_OrderBy DEFAULT (0),
	);
	
	ALTER TABLE xxxFinanceType ADD 
		CONSTRAINT PK_xxxFinanceType PRIMARY KEY  CLUSTERED 
		(
			LegalEntity ASC,
			Code ASC
		);
	
	CREATE  INDEX IX_xxxFinanceType_Description ON xxxFinanceType(Description);
	
	print 'Created xxxFinanceType table'
END
ELSE BEGIN
	print 'xxxFinanceType table already exists in this DB'
END

