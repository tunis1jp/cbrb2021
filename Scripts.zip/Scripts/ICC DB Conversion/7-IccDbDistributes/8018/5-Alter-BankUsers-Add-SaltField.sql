/* ******************************************* */
/* Alter Bankusers Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF  NOT EXISTS (SELECT * FROM sys.columns  WHERE NAME = N'Salt' and Object_ID = Object_ID(N'Bankusers'))
		BEGIN
			ALTER TABLE Bankusers ADD
				Salt VARCHAR(256) NOT NULL CONSTRAINT DF_Bankusers_Salt DEFAULT '';
			print 'Salt added to Bankusers table'
		END
		ELSE BEGIN
			print 'Salt already in Bankusers table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

