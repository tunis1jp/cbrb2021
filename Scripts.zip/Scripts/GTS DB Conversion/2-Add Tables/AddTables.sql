/*
Run this script on:

        SQL2016SVR\R8.TDBGtsNetDevR8    -  This database will be modified

to synchronize it with:

        SQL2016SVR\R8.GTSNetDevR8

You are recommended to back up your database before running this script

Script created by SQL Compare version 12.2.1.4077 from Red Gate Software Ltd at 2/8/2021 3:24:18 PM

*/
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL Serializable
GO
BEGIN TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocCertOfUtil]'
GO
CREATE TABLE [dbo].[BalLocCertOfUtil]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_Pkey] DEFAULT ((0)),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_LocPrimaryPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_ReplacePkey] DEFAULT ((0)),
[GtsAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_GtsAction] DEFAULT ('ADD'),
[UtilizedAmount] [money] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_UtilizedAmount] DEFAULT ((0)),
[AverageDailyBalance] [money] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_AverageDailyBalance] DEFAULT ((0)),
[CollateralizationPercentage] [float] NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_CollateralizationPercentage] DEFAULT ((0)),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocCertOfUtil_UPDATABASE] DEFAULT ('Y')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_BalLocCertOfUtil] on [dbo].[BalLocCertOfUtil]'
GO
ALTER TABLE [dbo].[BalLocCertOfUtil] ADD CONSTRAINT [PK_BalLocCertOfUtil] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FeePlan]'
GO
CREATE TABLE [dbo].[FeePlan]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_FeePlan_TransPkey] DEFAULT ((0)),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_FeePlan_LocPrimaryPkey] DEFAULT ((0)),
[LoanSystem] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_LoanSystem] DEFAULT (''),
[DateApproved] [datetime] NOT NULL CONSTRAINT [DF_FeePlan_DateApproved] DEFAULT ('1/1/1900'),
[DatePassed] [datetime] NOT NULL CONSTRAINT [DF_FeePlan_DatePassed] DEFAULT ('1/1/1900'),
[FeeID] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_FeeID] DEFAULT (''),
[FeeCategory] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_FeeCategory] DEFAULT (''),
[FeeAmount] [money] NOT NULL CONSTRAINT [DF_FeePlan_FeeAmount] DEFAULT ((0)),
[FeeStartDate] [datetime] NOT NULL CONSTRAINT [DF_FeePlan_FeeStartDate] DEFAULT ('1/1/1900'),
[FeeEndDate] [datetime] NOT NULL CONSTRAINT [DF_FeePlan_FeeEndDate] DEFAULT ('1/1/1900'),
[EarningsTermMonths] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_EarningsTermMonths] DEFAULT (''),
[LCFeeChg] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_LCFeeChg] DEFAULT ('N'),
[LCFeePay] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_LCFeePay] DEFAULT ('N'),
[ExternalParticipantShare] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeePlan_ExternalParticipantShare] DEFAULT ('N')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_FeePlan] on [dbo].[FeePlan]'
GO
ALTER TABLE [dbo].[FeePlan] ADD CONSTRAINT [PK_FeePlan] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfPrimary]'
GO
CREATE TABLE [dbo].[ModelScfPrimary]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_Pkey] DEFAULT ((0)),
[ScfPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_ScfPrimaryPkey] DEFAULT ((0)),
[EventPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_EventPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_ReplacePkey] DEFAULT ((0)),
[ScfPrimaryStatus] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_ScfPrimaryStatus] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_ModelScfPrimary_Active] DEFAULT ((0)),
[GTSAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_GTSAction] DEFAULT (''),
[OurRefLegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_OurRefLegalEntity] DEFAULT (''),
[OurRefDivisionNum] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_OurRefDivisionNum] DEFAULT (''),
[OurRefDepartmentNum] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_OurRefDepartmentNum] DEFAULT (''),
[OurReferenceNum] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_OurReferenceNum] DEFAULT (''),
[LetterType] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_LetterType] DEFAULT (''),
[SellerPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_SellerPkey] DEFAULT ((0)),
[SellerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_SellerReference] DEFAULT (''),
[SellerHow] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_SellerHow] DEFAULT (''),
[SellerDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_SellerDDA] DEFAULT (''),
[OriginalAmountBase] [money] NOT NULL CONSTRAINT [DF_ModelScfPrimary_OriginalAmountBase] DEFAULT ((0)),
[OriginalAmount] [money] NOT NULL CONSTRAINT [DF_ModelScfPrimary_OriginalAmount] DEFAULT ((0)),
[AmountOutstandingBase] [money] NOT NULL CONSTRAINT [DF_ModelScfPrimary_AmountOutstandingBase] DEFAULT ((0)),
[AmountOutstanding] [money] NOT NULL CONSTRAINT [DF_ModelScfPrimary_AmountOutstanding] DEFAULT ((0)),
[CurrencyCode] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_CurrencyCode] DEFAULT (''),
[FXRate] [float] NOT NULL CONSTRAINT [DF_ModelScfPrimary_FXRate] DEFAULT ((0)),
[FXContract] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_FXContract] DEFAULT (''),
[EntryDate] [datetime] NOT NULL CONSTRAINT [DF_ModelScfPrimary_EntryDate] DEFAULT (((1)/(1))/(1900)),
[DocumentDate] [datetime] NOT NULL CONSTRAINT [DF_ModelScfPrimary_DocumentDate] DEFAULT (((1)/(1))/(1900)),
[DateAccepted] [datetime] NOT NULL CONSTRAINT [DF_ModelScfPrimary_DateAccepted] DEFAULT (((1)/(1))/(1900)),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_ModelScfPrimary_MaturityDate] DEFAULT (((1)/(1))/(1900)),
[TenorDays] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_TenorDays] DEFAULT ((0)),
[TenorPhrase] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_TenorPhrase] DEFAULT (''),
[LastTracerVia] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_LastTracerVia] DEFAULT (''),
[LastTracerDate] [datetime] NOT NULL CONSTRAINT [DF_ModelScfPrimary_LastTracerDate] DEFAULT (((1)/(1))/(1900)),
[NumberOfTracers] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_NumberOfTracers] DEFAULT ((0)),
[TraceToday] [bit] NOT NULL CONSTRAINT [DF_ModelScfPrimary_TraceToday] DEFAULT ((0)),
[BuyerPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_BuyerPkey] DEFAULT ((0)),
[BuyerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_BuyerReference] DEFAULT (''),
[BuyerHow] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_BuyerHow] DEFAULT (''),
[BuyerDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_BuyerDDA] DEFAULT (''),
[CreatingProgram] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_CreatingProgram] DEFAULT (''),
[CollectionType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_CollectionType] DEFAULT (''),
[BankingGroup] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_BankingGroup] DEFAULT (''),
[ExpenseCode] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_ExpenseCode] DEFAULT (''),
[PaidDirect] [bit] NOT NULL CONSTRAINT [DF_ModelScfPrimary_PaidDirect] DEFAULT ((0)),
[CloseThisCollection] [bit] NOT NULL CONSTRAINT [DF_ModelScfPrimary_CloseThisCollection] DEFAULT ((0)),
[Chk1Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk1Value] DEFAULT (''),
[Chk2Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk2Value] DEFAULT (''),
[Chk3Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk3Value] DEFAULT (''),
[Chk4Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk4Value] DEFAULT (''),
[Chk5Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk5Value] DEFAULT (''),
[Chk6Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk6Value] DEFAULT (''),
[Chk7Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk7Value] DEFAULT (''),
[Chk8Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk8Value] DEFAULT (''),
[Chk9Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk9Value] DEFAULT (''),
[WaitingClarification] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_WaitingClarification] DEFAULT (''),
[WaitingAuthentication] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_WaitingAuthentication] DEFAULT (''),
[AmendTraceDays] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_AmendTraceDays] DEFAULT ((0)),
[AlternateAOPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_AlternateAOPkey] DEFAULT ((0)),
[AccountOfficerPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfPrimary_AccountOfficerPkey] DEFAULT ((0)),
[BLNumber] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_BLNumber] DEFAULT (''),
[ReferencePerfix] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_ReferencePerfix] DEFAULT (''),
[ConvertedRefNo] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_ConvertedRefNo] DEFAULT (''),
[InvoicePONo] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_InvoicePONo] DEFAULT (''),
[ConvertedSystem] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_ConvertedSystem] DEFAULT (''),
[Chk10Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk10Value] DEFAULT ('N'),
[Chk11Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk11Value] DEFAULT ('N'),
[Chk12Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk12Value] DEFAULT ('N'),
[Chk13Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk13Value] DEFAULT ('N'),
[Chk14Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk14Value] DEFAULT ('N'),
[Chk15Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk15Value] DEFAULT ('N'),
[Chk16Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk16Value] DEFAULT ('N'),
[Chk17Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk17Value] DEFAULT ('N'),
[Chk18Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk18Value] DEFAULT ('N'),
[Chk19Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk19Value] DEFAULT ('N'),
[Chk20Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_Chk20Value] DEFAULT ('N'),
[AuthForDebit] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_AuthForDebit] DEFAULT (''),
[DoNotPurge] [bit] NOT NULL CONSTRAINT [DF_ModelScfPrimary_DoNotPurge] DEFAULT ((0)),
[ClosedDate] [datetime] NOT NULL CONSTRAINT [DF_ModelScfPrimary_ClosedDate] DEFAULT (((1)/(1))/(1900)),
[CommitmentNum] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_CommitmentNum] DEFAULT (''),
[PurposeCode] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_PurposeCode] DEFAULT (''),
[LoanSystem] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_LoanSystem] DEFAULT (''),
[FinanceType] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_FinanceType] DEFAULT (''),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfPrimary_UPDATABASE] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ModelScfPrimary] on [dbo].[ModelScfPrimary]'
GO
ALTER TABLE [dbo].[ModelScfPrimary] ADD CONSTRAINT [PK_ModelScfPrimary] PRIMARY KEY NONCLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[ModelScfPrimary]'
GO
ALTER TABLE [dbo].[ModelScfPrimary] ADD CONSTRAINT [IX_ModelScfPrimary] UNIQUE NONCLUSTERED  ([OurRefLegalEntity], [OurReferenceNum]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalScfPrimary]'
GO
CREATE TABLE [dbo].[BalScfPrimary]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_Pkey] DEFAULT ((0)),
[ScfPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_ScfPrimaryPkey] DEFAULT ((0)),
[EventPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_EventPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_ReplacePkey] DEFAULT ((0)),
[ScfPrimaryStatus] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_ScfPrimaryStatus] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_BalScfPrimary_Active] DEFAULT ((0)),
[GTSAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_GTSAction] DEFAULT (''),
[OurRefLegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_OurRefLegalEntity] DEFAULT (''),
[OurRefDivisionNum] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_OurRefDivisionNum] DEFAULT (''),
[OurRefDepartmentNum] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_OurRefDepartmentNum] DEFAULT (''),
[OurReferenceNum] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_OurReferenceNum] DEFAULT (''),
[LetterType] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_LetterType] DEFAULT (''),
[SellerPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_SellerPkey] DEFAULT ((0)),
[SellerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_SellerReference] DEFAULT (''),
[SellerHow] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_SellerHow] DEFAULT (''),
[SellerDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_SellerDDA] DEFAULT (''),
[OriginalAmountBase] [money] NOT NULL CONSTRAINT [DF_BalScfPrimary_OriginalAmountBase] DEFAULT ((0)),
[OriginalAmount] [money] NOT NULL CONSTRAINT [DF_BalScfPrimary_OriginalAmount] DEFAULT ((0)),
[AmountOutstandingBase] [money] NOT NULL CONSTRAINT [DF_BalScfPrimary_AmountOutstandingBase] DEFAULT ((0)),
[AmountOutstanding] [money] NOT NULL CONSTRAINT [DF_BalScfPrimary_AmountOutstanding] DEFAULT ((0)),
[CurrencyCode] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_CurrencyCode] DEFAULT (''),
[FXRate] [float] NOT NULL CONSTRAINT [DF_BalScfPrimary_FXRate] DEFAULT ((0)),
[FXContract] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_FXContract] DEFAULT (''),
[EntryDate] [datetime] NOT NULL CONSTRAINT [DF_BalScfPrimary_EntryDate] DEFAULT (((1)/(1))/(1900)),
[DocumentDate] [datetime] NOT NULL CONSTRAINT [DF_BalScfPrimary_DocumentDate] DEFAULT (((1)/(1))/(1900)),
[DateAccepted] [datetime] NOT NULL CONSTRAINT [DF_BalScfPrimary_DateAccepted] DEFAULT (((1)/(1))/(1900)),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_BalScfPrimary_MaturityDate] DEFAULT (((1)/(1))/(1900)),
[TenorDays] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_TenorDays] DEFAULT ((0)),
[TenorPhrase] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_TenorPhrase] DEFAULT (''),
[LastTracerVia] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_LastTracerVia] DEFAULT (''),
[LastTracerDate] [datetime] NOT NULL CONSTRAINT [DF_BalScfPrimary_LastTracerDate] DEFAULT (((1)/(1))/(1900)),
[NumberOfTracers] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_NumberOfTracers] DEFAULT ((0)),
[TraceToday] [bit] NOT NULL CONSTRAINT [DF_BalScfPrimary_TraceToday] DEFAULT ((0)),
[BuyerPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_BuyerPkey] DEFAULT ((0)),
[BuyerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_BuyerReference] DEFAULT (''),
[BuyerHow] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_BuyerHow] DEFAULT (''),
[BuyerDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_BuyerDDA] DEFAULT (''),
[CreatingProgram] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_CreatingProgram] DEFAULT (''),
[CollectionType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_CollectionType] DEFAULT (''),
[BankingGroup] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_BankingGroup] DEFAULT (''),
[ExpenseCode] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_ExpenseCode] DEFAULT (''),
[PaidDirect] [bit] NOT NULL CONSTRAINT [DF_BalScfPrimary_PaidDirect] DEFAULT ((0)),
[CloseThisCollection] [bit] NOT NULL CONSTRAINT [DF_BalScfPrimary_CloseThisCollection] DEFAULT ((0)),
[Chk1Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk1Value] DEFAULT (''),
[Chk2Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk2Value] DEFAULT (''),
[Chk3Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk3Value] DEFAULT (''),
[Chk4Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk4Value] DEFAULT (''),
[Chk5Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk5Value] DEFAULT (''),
[Chk6Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk6Value] DEFAULT (''),
[Chk7Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk7Value] DEFAULT (''),
[Chk8Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk8Value] DEFAULT (''),
[Chk9Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk9Value] DEFAULT (''),
[WaitingClarification] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_WaitingClarification] DEFAULT (''),
[WaitingAuthentication] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_WaitingAuthentication] DEFAULT (''),
[AmendTraceDays] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_AmendTraceDays] DEFAULT ((0)),
[AlternateAOPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_AlternateAOPkey] DEFAULT ((0)),
[AccountOfficerPkey] [int] NOT NULL CONSTRAINT [DF_BalScfPrimary_AccountOfficerPkey] DEFAULT ((0)),
[BLNumber] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_BLNumber] DEFAULT (''),
[ReferencePerfix] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_ReferencePerfix] DEFAULT (''),
[ConvertedRefNo] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_ConvertedRefNo] DEFAULT (''),
[InvoicePONo] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_InvoicePONo] DEFAULT (''),
[ConvertedSystem] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_ConvertedSystem] DEFAULT (''),
[Chk10Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk10Value] DEFAULT ('N'),
[Chk11Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk11Value] DEFAULT ('N'),
[Chk12Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk12Value] DEFAULT ('N'),
[Chk13Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk13Value] DEFAULT ('N'),
[Chk14Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk14Value] DEFAULT ('N'),
[Chk15Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk15Value] DEFAULT ('N'),
[Chk16Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk16Value] DEFAULT ('N'),
[Chk17Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk17Value] DEFAULT ('N'),
[Chk18Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk18Value] DEFAULT ('N'),
[Chk19Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk19Value] DEFAULT ('N'),
[Chk20Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_Chk20Value] DEFAULT ('N'),
[AuthForDebit] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_AuthForDebit] DEFAULT (''),
[DoNotPurge] [bit] NOT NULL CONSTRAINT [DF_BalScfPrimary_DoNotPurge] DEFAULT ((0)),
[ClosedDate] [datetime] NOT NULL CONSTRAINT [DF_BalScfPrimary_ClosedDate] DEFAULT (((1)/(1))/(1900)),
[CommitmentNum] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_CommitmentNum] DEFAULT (''),
[PurposeCode] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_PurposeCode] DEFAULT (''),
[LoanSystem] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_LoanSystem] DEFAULT (''),
[FinanceType] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_FinanceType] DEFAULT (''),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalScfPrimary_UPDATABASE] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_BalScfPrimary] on [dbo].[BalScfPrimary]'
GO
ALTER TABLE [dbo].[BalScfPrimary] ADD CONSTRAINT [PK_BalScfPrimary] PRIMARY KEY NONCLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[BalScfPrimary]'
GO
ALTER TABLE [dbo].[BalScfPrimary] ADD CONSTRAINT [IX_BalScfPrimary] UNIQUE NONCLUSTERED  ([OurRefLegalEntity], [OurReferenceNum]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimary]'
GO
CREATE TABLE [dbo].[ScfPrimary]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_Pkey] DEFAULT ((0)),
[ScfPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_ScfPrimaryPkey] DEFAULT ((0)),
[EventPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_EventPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_ReplacePkey] DEFAULT ((0)),
[ScfPrimaryStatus] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_ScfPrimaryStatus] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_ScfPrimary_Active] DEFAULT ((0)),
[GTSAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_GTSAction] DEFAULT (''),
[OurRefLegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_OurRefLegalEntity] DEFAULT (''),
[OurRefDivisionNum] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_OurRefDivisionNum] DEFAULT (''),
[OurRefDepartmentNum] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_OurRefDepartmentNum] DEFAULT (''),
[OurReferenceNum] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_OurReferenceNum] DEFAULT (''),
[LetterType] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_LetterType] DEFAULT (''),
[SellerPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_SellerPkey] DEFAULT ((0)),
[SellerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_SellerReference] DEFAULT (''),
[SellerHow] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_SellerHow] DEFAULT (''),
[SellerDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_SellerDDA] DEFAULT (''),
[OriginalAmountBase] [money] NOT NULL CONSTRAINT [DF_ScfPrimary_OriginalAmountBase] DEFAULT ((0)),
[OriginalAmount] [money] NOT NULL CONSTRAINT [DF_ScfPrimary_OriginalAmount] DEFAULT ((0)),
[AmountOutstandingBase] [money] NOT NULL CONSTRAINT [DF_ScfPrimary_AmountOutstandingBase] DEFAULT ((0)),
[AmountOutstanding] [money] NOT NULL CONSTRAINT [DF_ScfPrimary_AmountOutstanding] DEFAULT ((0)),
[CurrencyCode] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_CurrencyCode] DEFAULT (''),
[FXRate] [float] NOT NULL CONSTRAINT [DF_ScfPrimary_FXRate] DEFAULT ((0)),
[FXContract] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_FXContract] DEFAULT (''),
[EntryDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPrimary_EntryDate] DEFAULT (((1)/(1))/(1900)),
[DocumentDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPrimary_DocumentDate] DEFAULT (((1)/(1))/(1900)),
[DateAccepted] [datetime] NOT NULL CONSTRAINT [DF_ScfPrimary_DateAccepted] DEFAULT (((1)/(1))/(1900)),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPrimary_MaturityDate] DEFAULT (((1)/(1))/(1900)),
[TenorDays] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_TenorDays] DEFAULT ((0)),
[TenorPhrase] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_TenorPhrase] DEFAULT (''),
[LastTracerVia] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_LastTracerVia] DEFAULT (''),
[LastTracerDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPrimary_LastTracerDate] DEFAULT (((1)/(1))/(1900)),
[NumberOfTracers] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_NumberOfTracers] DEFAULT ((0)),
[TraceToday] [bit] NOT NULL CONSTRAINT [DF_ScfPrimary_TraceToday] DEFAULT ((0)),
[BuyerPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_BuyerPkey] DEFAULT ((0)),
[BuyerReference] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_BuyerReference] DEFAULT (''),
[BuyerHow] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_BuyerHow] DEFAULT (''),
[BuyerDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_BuyerDDA] DEFAULT (''),
[CreatingProgram] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_CreatingProgram] DEFAULT (''),
[CollectionType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_CollectionType] DEFAULT (''),
[BankingGroup] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_BankingGroup] DEFAULT (''),
[ExpenseCode] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_ExpenseCode] DEFAULT (''),
[PaidDirect] [bit] NOT NULL CONSTRAINT [DF_ScfPrimary_PaidDirect] DEFAULT ((0)),
[CloseThisCollection] [bit] NOT NULL CONSTRAINT [DF_ScfPrimary_CloseThisCollection] DEFAULT ((0)),
[Chk1Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk1Value] DEFAULT (''),
[Chk2Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk2Value] DEFAULT (''),
[Chk3Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk3Value] DEFAULT (''),
[Chk4Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk4Value] DEFAULT (''),
[Chk5Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk5Value] DEFAULT (''),
[Chk6Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk6Value] DEFAULT (''),
[Chk7Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk7Value] DEFAULT (''),
[Chk8Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk8Value] DEFAULT (''),
[Chk9Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk9Value] DEFAULT (''),
[WaitingClarification] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_WaitingClarification] DEFAULT (''),
[WaitingAuthentication] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_WaitingAuthentication] DEFAULT (''),
[AmendTraceDays] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_AmendTraceDays] DEFAULT ((0)),
[AlternateAOPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_AlternateAOPkey] DEFAULT ((0)),
[AccountOfficerPkey] [int] NOT NULL CONSTRAINT [DF_ScfPrimary_AccountOfficerPkey] DEFAULT ((0)),
[BLNumber] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_BLNumber] DEFAULT (''),
[ReferencePerfix] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_ReferencePerfix] DEFAULT (''),
[ConvertedRefNo] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_ConvertedRefNo] DEFAULT (''),
[InvoicePONo] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_InvoicePONo] DEFAULT (''),
[ConvertedSystem] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_ConvertedSystem] DEFAULT (''),
[Chk10Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk10Value] DEFAULT ('N'),
[Chk11Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk11Value] DEFAULT ('N'),
[Chk12Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk12Value] DEFAULT ('N'),
[Chk13Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk13Value] DEFAULT ('N'),
[Chk14Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk14Value] DEFAULT ('N'),
[Chk15Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk15Value] DEFAULT ('N'),
[Chk16Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk16Value] DEFAULT ('N'),
[Chk17Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk17Value] DEFAULT ('N'),
[Chk18Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk18Value] DEFAULT ('N'),
[Chk19Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk19Value] DEFAULT ('N'),
[Chk20Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_Chk20Value] DEFAULT ('N'),
[AuthForDebit] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_AuthForDebit] DEFAULT (''),
[DoNotPurge] [bit] NOT NULL CONSTRAINT [DF_ScfPrimary_DoNotPurge] DEFAULT ((0)),
[ClosedDate] [datetime] NOT NULL CONSTRAINT [DF_ScfPrimary_ClosedDate] DEFAULT (((1)/(1))/(1900)),
[CommitmentNum] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_CommitmentNum] DEFAULT (''),
[PurposeCode] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_PurposeCode] DEFAULT (''),
[LoanSystem] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_LoanSystem] DEFAULT (''),
[FinanceType] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_FinanceType] DEFAULT (''),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfPrimary_UPDATABASE] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ScfPrimary] on [dbo].[ScfPrimary]'
GO
ALTER TABLE [dbo].[ScfPrimary] ADD CONSTRAINT [PK_ScfPrimary] PRIMARY KEY NONCLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[ScfPrimary]'
GO
ALTER TABLE [dbo].[ScfPrimary] ADD CONSTRAINT [IX_ScfPrimary] UNIQUE NONCLUSTERED  ([OurRefLegalEntity], [OurReferenceNum]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[RealTimeDDA]'
GO
CREATE TABLE [dbo].[RealTimeDDA]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[Transpkey] [int] NOT NULL CONSTRAINT [DF_RealTimeDDA_Transpkey] DEFAULT ((0)),
[DDANumber] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_DDANumber] DEFAULT (''),
[ReferenceNum] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_ReferenceNum] DEFAULT (''),
[RecType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_RecType] DEFAULT (''),
[Transtatus] [int] NOT NULL CONSTRAINT [DF_RealTimeDDA_Transtatus] DEFAULT ((0)),
[PartyID] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_PartyID] DEFAULT (''),
[Amount] [money] NOT NULL CONSTRAINT [DF_RealTimeDDA_Amount] DEFAULT ((0)),
[IncDec] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_IncDec_1] DEFAULT (''),
[ValueDate] [datetime] NOT NULL CONSTRAINT [DF_RealTimeDDA_ValueDate] DEFAULT (((1)/(1))/(1900)),
[FXrate] [float] NOT NULL CONSTRAINT [DF_RealTimeDDA_FXrate] DEFAULT ((1.0)),
[AuthorizeAmount] [money] NOT NULL CONSTRAINT [DF_RealTimeDDA_AuthorizeAmount] DEFAULT ((0)),
[OverRide] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Rejectreason] [varchar] (132) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_Rejectreason] DEFAULT (''),
[Currency] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_Currency] DEFAULT ('USD'),
[ProcessDate] [datetime] NOT NULL CONSTRAINT [DF_RealTimeDDA_ProcessDate] DEFAULT (((1)/(1))/(1900)),
[RequestId] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_RequestId] DEFAULT (''),
[ErrorCode] [int] NOT NULL CONSTRAINT [DF_RealTimeDDA_ErrorCode] DEFAULT ((0)),
[ErrorReasonCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_ErrorReasonCode] DEFAULT (''),
[ErrorMsgNum] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_ErrorMsgNum] DEFAULT (''),
[ErrorMsgText] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_ErrorMsgText] DEFAULT (''),
[ErrorMsgField] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_ErrorMsgField] DEFAULT (''),
[OutgoingMsgText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_OutgoingMsgText] DEFAULT (''),
[ResponseMsgText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_RealTimeDDA_ResponseMsgText] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_RealTimeDDA] on [dbo].[RealTimeDDA]'
GO
ALTER TABLE [dbo].[RealTimeDDA] ADD CONSTRAINT [PK_RealTimeDDA] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledges]'
GO
CREATE TABLE [dbo].[LocPledges]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_LocPledges_Pkey] DEFAULT ((0)),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_LocPledges_LocPrimaryPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_LocPledges_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_LocPledges_ReplacePkey] DEFAULT ((0)),
[GtsAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_GtsAction] DEFAULT ('ADD'),
[PledgeID] [int] NOT NULL CONSTRAINT [DF_LocPledges_PledgeID] DEFAULT ((0)),
[DepositorsPkey] [int] NOT NULL CONSTRAINT [DF_LocPledges_DepositorsPkey] DEFAULT ((0)),
[DepositorsName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsName] DEFAULT (''),
[StartDate] [datetime] NOT NULL CONSTRAINT [DF_LocPledges_StartDate] DEFAULT ('1/1/1900'),
[EndDate] [datetime] NOT NULL CONSTRAINT [DF_LocPledges_EndDate] DEFAULT ('1/1/1900'),
[Amount] [money] NOT NULL CONSTRAINT [DF_LocPledges_Amount] DEFAULT ((0)),
[Adjustment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_Adjustment] DEFAULT ('N'),
[DepositorsAddress1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsAddress1] DEFAULT (''),
[DepositorsAddress2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsAddress2] DEFAULT (''),
[DepositorsAddress3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsAddress3] DEFAULT (''),
[DepositorsZip] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsZip] DEFAULT (''),
[DepositorsPhone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsPhone] DEFAULT (''),
[DepositorsEmail] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsEmail] DEFAULT (''),
[SafeKeepingTicketNum] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_SafeKeepingTicketNum] DEFAULT (''),
[IccDepositorsPkey] [int] NOT NULL CONSTRAINT [DF_LocPledges_IccDepositorsPkey] DEFAULT ((0)),
[DepositorsAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsAttnLine1] DEFAULT (''),
[DepositorsGtsPartyID] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_DepositorsGtsPartyID] DEFAULT (''),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocPledges_UPDATABASE] DEFAULT ('Y')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LocPledges] on [dbo].[LocPledges]'
GO
ALTER TABLE [dbo].[LocPledges] ADD CONSTRAINT [PK_LocPledges] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocPledges]'
GO
CREATE TABLE [dbo].[BalLocPledges]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_Pkey] DEFAULT ((0)),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_LocPrimaryPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_ReplacePkey] DEFAULT ((0)),
[GtsAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_GtsAction] DEFAULT ('ADD'),
[PledgeID] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_PledgeID] DEFAULT ((0)),
[DepositorsPkey] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsPkey] DEFAULT ((0)),
[DepositorsName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsName] DEFAULT (''),
[StartDate] [datetime] NOT NULL CONSTRAINT [DF_BalLocPledges_StartDate] DEFAULT ('1/1/1900'),
[EndDate] [datetime] NOT NULL CONSTRAINT [DF_BalLocPledges_EndDate] DEFAULT ('1/1/1900'),
[Amount] [money] NOT NULL CONSTRAINT [DF_BalLocPledges_Amount] DEFAULT ((0)),
[Adjustment] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_Adjustment] DEFAULT ('N'),
[DepositorsAddress1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsAddress1] DEFAULT (''),
[DepositorsAddress2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsAddress2] DEFAULT (''),
[DepositorsAddress3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsAddress3] DEFAULT (''),
[DepositorsZip] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsZip] DEFAULT (''),
[DepositorsPhone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsPhone] DEFAULT (''),
[DepositorsEmail] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsEmail] DEFAULT (''),
[SafeKeepingTicketNum] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_SafeKeepingTicketNum] DEFAULT (''),
[IccDepositorsPkey] [int] NOT NULL CONSTRAINT [DF_BalLocPledges_IccDepositorsPkey] DEFAULT ((0)),
[DepositorsAttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsAttnLine1] DEFAULT (''),
[DepositorsGTSPartyID] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_DepositorsGTSPartyID] DEFAULT (''),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BalLocPledges_UPDATABASE] DEFAULT ('Y')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_BalLocPledges] on [dbo].[BalLocPledges]'
GO
ALTER TABLE [dbo].[BalLocPledges] ADD CONSTRAINT [PK_BalLocPledges] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocShippingParties]'
GO
CREATE TABLE [dbo].[LocShippingParties]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_LocShippingParties_TransPkey] DEFAULT ((0)),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_LocShippingParties_LocPrimaryPkey] DEFAULT ((0)),
[PartyPkey] [int] NOT NULL CONSTRAINT [DF_LocShippingParties_PartyPkey] DEFAULT ((0)),
[Amount] [money] NOT NULL CONSTRAINT [DF_LocShippingParties_Amount] DEFAULT ((0)),
[AmountBase] [money] NOT NULL CONSTRAINT [DF_LocShippingParties_AmountBase] DEFAULT ((0)),
[CurrencyCode] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocShippingParties_CurrencyCode] DEFAULT (''),
[FxRate] [float] NOT NULL CONSTRAINT [DF_LocShippingParties_FxRate] DEFAULT ((0)),
[FreeForm] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocShippingParties_FreeForm] DEFAULT ('N')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LocShippingParties] on [dbo].[LocShippingParties]'
GO
ALTER TABLE [dbo].[LocShippingParties] ADD CONSTRAINT [PK_LocShippingParties] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfText]'
GO
CREATE TABLE [dbo].[ScfText]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[ScfPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_ScfText_ScfPrimaryPkey] DEFAULT ((0)),
[EventPkey] [int] NOT NULL CONSTRAINT [DF_ScfText_EventPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_ScfText_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_ScfText_ReplacePkey] DEFAULT ((0)),
[GTSAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfText_Action] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_ScfText_Active] DEFAULT ((0)),
[TextType] [int] NOT NULL CONSTRAINT [DF_ScfText_TextType] DEFAULT ((0)),
[NumberBytes] [int] NOT NULL CONSTRAINT [DF_ScfText_NumberBytes] DEFAULT ((0)),
[Description] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfText_Description] DEFAULT (''),
[Width] [int] NOT NULL CONSTRAINT [DF_ScfText_Width] DEFAULT ((65)),
[CheckSwfChars] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfText_CheckSwfChars] DEFAULT ('N'),
[updatabase] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ScfText_updatabase] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ScfText] on [dbo].[ScfText]'
GO
ALTER TABLE [dbo].[ScfText] ADD CONSTRAINT [PK_ScfText] PRIMARY KEY NONCLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfText]'
GO
CREATE TABLE [dbo].[ModelScfText]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[ScfPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfText_ScfPrimaryPkey] DEFAULT ((0)),
[EventPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfText_EventPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_ModelScfText_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_ModelScfText_ReplacePkey] DEFAULT ((0)),
[GTSAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfText_Action] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_ModelScfText_Active] DEFAULT ((0)),
[TextType] [int] NOT NULL CONSTRAINT [DF_ModelScfText_TextType] DEFAULT ((0)),
[NumberBytes] [int] NOT NULL CONSTRAINT [DF_ModelScfText_NumberBytes] DEFAULT ((0)),
[Description] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfText_Description] DEFAULT (''),
[Width] [int] NOT NULL CONSTRAINT [DF_ModelScfText_Width] DEFAULT ((65)),
[CheckSwfChars] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfText_CheckSwfChars] DEFAULT ('N'),
[updatabase] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ModelScfText_updatabase] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ModelScfText] on [dbo].[ModelScfText]'
GO
ALTER TABLE [dbo].[ModelScfText] ADD CONSTRAINT [PK_ModelScfText] PRIMARY KEY NONCLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteDDA]'
GO
CREATE TABLE [dbo].[MetavanteDDA]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[Transpkey] [int] NOT NULL CONSTRAINT [DF_MetavanteDDA_Transpkey] DEFAULT ((0)),
[RequestId] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_RequestId] DEFAULT (''),
[DDANumber] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_DDANumber] DEFAULT (''),
[ReferenceNum] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_ReferenceNum] DEFAULT (''),
[RecType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_RecType] DEFAULT (''),
[Transtatus] [int] NOT NULL CONSTRAINT [DF_MetavanteDDA_Transtatus] DEFAULT ((0)),
[PartyID] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_PartyID] DEFAULT (''),
[Amount] [money] NOT NULL CONSTRAINT [DF_MetavanteDDA_Amount] DEFAULT ((0)),
[IncDec] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_IncDec_1] DEFAULT (''),
[ValueDate] [datetime] NOT NULL CONSTRAINT [DF_MetavanteDDA_ValueDate] DEFAULT (((1)/(1))/(1900)),
[FXrate] [float] NOT NULL CONSTRAINT [DF_MetavanteDDA_FXrate] DEFAULT ((1.0)),
[AuthorizeAmount] [money] NOT NULL CONSTRAINT [DF_MetavanteDDA_AuthorizeAmount] DEFAULT ((0)),
[OverRide] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Rejectreason] [varchar] (132) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_Rejectreason] DEFAULT (''),
[Currency] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_Currency] DEFAULT ('USD'),
[ProcessDate] [datetime] NOT NULL CONSTRAINT [DF_MetavanteDDA_ProcessDate] DEFAULT (((1)/(1))/(1900)),
[ErrorCode] [int] NOT NULL CONSTRAINT [DF_MetavanteDDA_ErrorCode] DEFAULT ((0)),
[ErrorReasonCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_ErrorReasonCode] DEFAULT (''),
[ErrorMsgNum] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_ErrorMsgNum] DEFAULT (''),
[ErrorMsgText] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_ErrorMsgText] DEFAULT (''),
[ErrorMsgField] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_ErrorMsgField] DEFAULT (''),
[OutgoingMsgText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_OutgoingMsgText] DEFAULT (''),
[ResponseMsgText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteDDA_ResponseMsgText] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_MetavanteDDA] on [dbo].[MetavanteDDA]'
GO
ALTER TABLE [dbo].[MetavanteDDA] ADD CONSTRAINT [PK_MetavanteDDA] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[PartySHIP]'
GO
CREATE TABLE [dbo].[PartySHIP]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_Pkey] DEFAULT ((0)),
[PartyId] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_PartyId] DEFAULT (''),
[Name] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Name] DEFAULT (''),
[Address1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Address1] DEFAULT (''),
[Address2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Address2] DEFAULT (''),
[Address3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Address3] DEFAULT (''),
[AttnLine1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_AttnLine1] DEFAULT (''),
[BrowseLocation] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BrowseLocation] DEFAULT (''),
[NostroNum] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_NostroNum] DEFAULT (''),
[UserName] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UserName] DEFAULT (''),
[DDA_Num] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DDA_Num] DEFAULT (''),
[ExpenseCode] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ExpenseCode] DEFAULT (''),
[BrowseName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BrowseName] DEFAULT (''),
[PartyType] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_PartyType] DEFAULT (''),
[BankGroup] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BankGroup] DEFAULT (''),
[TelexId] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_TelexId] DEFAULT (''),
[SICS_Code] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_SICS_Code] DEFAULT (''),
[CreditParty] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_CreditParty] DEFAULT (''),
[CountryRisk] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_CountryRisk] DEFAULT (''),
[CountryDomicile] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_CountryDomicile] DEFAULT (''),
[ChipsId] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ChipsId] DEFAULT (''),
[FedId] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_FedId] DEFAULT (''),
[DateEst] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_DateEst] DEFAULT ('1/1/1900'),
[SwiftId] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_SwiftId] DEFAULT (''),
[ObligorNumber] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ObligorNumber] DEFAULT (''),
[IsptyFlag] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_IsptyFlag] DEFAULT (''),
[AttnLine2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_AttnLine2] DEFAULT (''),
[TaxID] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_TaxID] DEFAULT (''),
[RiskRating] [varchar] (7) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_RiskRating] DEFAULT (''),
[AccountAnalysis] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_AccountAnalysis] DEFAULT ((0)),
[ARInvoicing] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_ARInvoicing] DEFAULT ((0)),
[InvoiceCycleDay] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_InvoiceCycleDay] DEFAULT (''),
[DaysAfterToDebit] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DaysAfterToDebit] DEFAULT ((0)),
[BillingName] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingName] DEFAULT (''),
[BillingAddr1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingAddr1] DEFAULT (''),
[BillingAddr2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingAddr2] DEFAULT (''),
[BillingAddr3] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingAddr3] DEFAULT (''),
[DDA_Num2] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DDA_Num2] DEFAULT (''),
[DDA_Num3] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DDA_Num3] DEFAULT (''),
[DDA_Num4] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DDA_Num4] DEFAULT (''),
[WaiveUnutFee] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_WaiveUnutFee] DEFAULT ((0)),
[ChrgLateFee] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_ChrgLateFee] DEFAULT ((0)),
[ExportExcellence] [int] NOT NULL CONSTRAINT [DF_PartySHIP_ExportExcellence] DEFAULT ((0)),
[BillingZone] [int] NOT NULL CONSTRAINT [DF_PartySHIP_BillingZone] DEFAULT ((0)),
[CustomStatements] [int] NOT NULL CONSTRAINT [DF_PartySHIP_CustomStatements] DEFAULT ((0)),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_LegalEntity] DEFAULT (''),
[CustomerConnection] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_CustomerConnection] DEFAULT ((0)),
[Email] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Email] DEFAULT (''),
[Phone] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Phone] DEFAULT (''),
[Fax] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Fax] DEFAULT (''),
[CIFID] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_CIFID] DEFAULT (''),
[BrokerPkey1] [int] NOT NULL CONSTRAINT [DF_PartySHIP_BrokerPkey1] DEFAULT ((0)),
[ExpExcellencePkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_ExpExcellencePkey] DEFAULT ((0)),
[AltOfficer] [int] NOT NULL CONSTRAINT [DF_PartySHIP_AltOfficer] DEFAULT ((0)),
[AcctOfficer] [int] NOT NULL CONSTRAINT [DF_PartySHIP_AcctOfficer] DEFAULT ((0)),
[BrokerPkey2] [int] NOT NULL CONSTRAINT [DF_PartySHIP_BrokerPkey2] DEFAULT ((0)),
[BrokerPkey3] [int] NOT NULL CONSTRAINT [DF_PartySHIP_BrokerPkey3] DEFAULT ((0)),
[BrokerPkey4] [int] NOT NULL CONSTRAINT [DF_PartySHIP_BrokerPkey4] DEFAULT ((0)),
[BillingAttn1] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingAttn1] DEFAULT (''),
[BillingAttn2] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingAttn2] DEFAULT (''),
[DDAtoDebit] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DDAtoDebit] DEFAULT (''),
[BillingeMail] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillingeMail] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_Active] DEFAULT ((0)),
[City] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_City] DEFAULT (''),
[State] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_State] DEFAULT (''),
[Zip1] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Zip1] DEFAULT (''),
[Zip2] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Zip2] DEFAULT (''),
[ACHDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ACHDDA] DEFAULT (''),
[BankID] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BankID] DEFAULT (''),
[DaysAfterARToDebit] [int] NOT NULL CONSTRAINT [DF_PartySHIP_DaysAfterARToDebit] DEFAULT ((0)),
[BLToBank] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_BLToBank] DEFAULT ((0)),
[ARDDAToDebit] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ARDDAToDebit] DEFAULT (''),
[Chk1Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk1Value] DEFAULT (''),
[Chk2Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk2Value] DEFAULT (''),
[Chk3Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk3Value] DEFAULT (''),
[Chk4Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk4Value] DEFAULT (''),
[Chk5Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk5Value] DEFAULT (''),
[Chk6Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk6Value] DEFAULT (''),
[Chk7Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk7Value] DEFAULT (''),
[Chk8Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk8Value] DEFAULT (''),
[Chk9Value] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Chk9Value] DEFAULT (''),
[Affiliate] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Affiliate] DEFAULT (''),
[BlockDownloads] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BlockDownloads] DEFAULT (''),
[LoanAgreementNumber] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_LoanAgreementNumber] DEFAULT (''),
[TelexAuthenticated] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_TelexAuthenticated] DEFAULT (''),
[IccPkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_IccPkey] DEFAULT ((0)),
[NoARLateCharge] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_NoARLateCharge] DEFAULT (''),
[BillLastDayMonth] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_BillLastDayMonth] DEFAULT (''),
[FeeBillDay] [int] NOT NULL CONSTRAINT [DF_PartySHIP_FeeBillDay] DEFAULT ((0)),
[BLRLoanPercent] [float] NOT NULL CONSTRAINT [DF_PartySHIP_BLRLoanPercent] DEFAULT ((0)),
[DivisionCode] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DivisionCode] DEFAULT (''),
[RegionCode] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_RegionCode] DEFAULT (''),
[PartyNostro1] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_PartyNostro1] DEFAULT (''),
[PartyNostro2] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_PartyNostro2] DEFAULT (''),
[CoveringBankPkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_CoveringBankPkey] DEFAULT ((0)),
[SalesOfficePkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_SalesOfficePkey] DEFAULT ((0)),
[DDaSaving1] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_DDaSaving1] DEFAULT ((0)),
[DDASaving2] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_DDASaving2] DEFAULT ((0)),
[DDASaving3] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_DDASaving3] DEFAULT ((0)),
[DDASaving4] [bit] NOT NULL CONSTRAINT [DF_PartySHIP_DDASaving4] DEFAULT ((0)),
[LegalName] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_LegalName] DEFAULT (''),
[UseAsOpn] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UseAsOpn] DEFAULT (''),
[UseAsBen] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UseAsBen] DEFAULT (''),
[UseAsAdv] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UseAsAdv] DEFAULT (''),
[UseAsRem] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UseAsRem] DEFAULT (''),
[UseAsCfb] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UseAsCfb] DEFAULT (''),
[SwiftDDA] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_SwiftDDA] DEFAULT (''),
[LimitAmount] [money] NOT NULL CONSTRAINT [DF_PartySHIP_LimitAmount] DEFAULT ((0)),
[UsesMargin] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UsesMargin] DEFAULT ('N'),
[LCSubLimit] [money] NOT NULL CONSTRAINT [DF_PartySHIP_LCSubLimit] DEFAULT ((0)),
[NewLoans] [float] NOT NULL CONSTRAINT [DF_PartySHIP_NewLoans] DEFAULT ((0)),
[TotalRelation] [float] NOT NULL CONSTRAINT [DF_PartySHIP_TotalRelation] DEFAULT ((0)),
[ARMasterPkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_ARMasterPkey] DEFAULT ((0)),
[CleanPresentationDebitDays] [int] NOT NULL CONSTRAINT [DF_PartySHIP_CleanPresentationDebitDays] DEFAULT ((0)),
[DiscrPresentationDebitDays] [int] NOT NULL CONSTRAINT [DF_PartySHIP_DiscrPresentationDebitDays] DEFAULT ((0)),
[AutoTakeDefferedFees] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_AutoTakeDefferedFees] DEFAULT (''),
[ConversionID] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ConversionID] DEFAULT (''),
[RebateAmount] [money] NOT NULL CONSTRAINT [DF_PartySHIP_RebateAmount] DEFAULT ((0)),
[CashLetterOutstanding] [money] NOT NULL CONSTRAINT [DF_PartySHIP_CashLetterOutstanding] DEFAULT ((0)),
[ARInvoicePeriod] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ARInvoicePeriod] DEFAULT ('MON'),
[FinCenFirstName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_FinCenFirstName] DEFAULT (''),
[FinCenLastName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_FinCenLastName] DEFAULT (''),
[GSBPayFrequency] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_GSBPayFrequency] DEFAULT (''),
[GSBFeeDueDates] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_GSBFeeDueDates] DEFAULT (''),
[GSBEOPSOP] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_GSBEOPSOP] DEFAULT (''),
[GSBBilateral] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_GSBBilateral] DEFAULT (''),
[GSBLatestMark] [money] NOT NULL CONSTRAINT [DF_PartySHIP_GSBLatestMark] DEFAULT ((0)),
[GSBMarkDate] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_GSBMarkDate] DEFAULT (''),
[QuarterlyCycle] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_QuarterlyCycle] DEFAULT (''),
[SendToIcc] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_SendToIcc] DEFAULT ('N'),
[AggregateAmount] [money] NOT NULL CONSTRAINT [DF_PartySHIP_AggregateAmount] DEFAULT ((0)),
[UCRAExpiration] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_UCRAExpiration] DEFAULT ('1/1/1900'),
[FloatDays] [int] NOT NULL CONSTRAINT [DF_PartySHIP_FloatDays] DEFAULT ((0)),
[Exception] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_Exception] DEFAULT ('N'),
[POADate] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_POADate] DEFAULT ('1/1/1900'),
[DeferColChargesToMaturity] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_DeferColChargesToMaturity] DEFAULT ('N'),
[ParticipantTaxRate] [float] NOT NULL CONSTRAINT [DF_PartySHIP_ParticipantTaxRate] DEFAULT ((0)),
[TaxWithHoldingGLCode] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_TaxWithHoldingGLCode] DEFAULT (''),
[WaiveRenewalFee] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_WaiveRenewalFee] DEFAULT ('Y'),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_ReplacePkey] DEFAULT ((0)),
[ObligationPerf] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ObligationPerf] DEFAULT (''),
[ObligationFin] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ObligationFin] DEFAULT (''),
[ObligationDoc] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ObligationDoc] DEFAULT (''),
[BornOnDateIMP] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_BornOnDateImp] DEFAULT ('1/1/1900'),
[BornOnDateEXP] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_BornOnDateExp] DEFAULT ('1/1/1900'),
[BornOnDateSTB] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_BornOnDateSTB] DEFAULT ('1/1/1900'),
[BornOnDateSTA] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_BornOnDateSTA] DEFAULT ('1/1/1900'),
[BornOnDateCEX] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_BornOnDateCEX] DEFAULT ('1/1/1900'),
[BornOnDateCIM] [datetime] NOT NULL CONSTRAINT [DF_PartySHIP_BornOnDateCIM] DEFAULT ('1/1/1900'),
[ExcludeFromCRM] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_ExcludeFromCRM] DEFAULT ('N'),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_PartySHIP_LocPrimaryPkey] DEFAULT ((0)),
[AlternateID] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_AlternateID] DEFAULT (''),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartySHIP_UPDATABASE] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_PartySHIP] on [dbo].[PartySHIP]'
GO
ALTER TABLE [dbo].[PartySHIP] ADD CONSTRAINT [PK_PartySHIP] PRIMARY KEY NONCLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteLoans]'
GO
CREATE TABLE [dbo].[MetavanteLoans]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[Transpkey] [int] NOT NULL CONSTRAINT [DF_MetavanteLoans_Transpkey] DEFAULT ((0)),
[RequestId] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_RequestId] DEFAULT (''),
[Commitnumber] [varchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_Commitnumber] DEFAULT (''),
[ReferenceNum] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_ReferenceNum] DEFAULT (''),
[RecType] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_RecType] DEFAULT (''),
[Transtatus] [int] NOT NULL CONSTRAINT [DF_MetavanteLoans_Transtatus] DEFAULT ((0)),
[PartyID] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_PartyID] DEFAULT (''),
[Amount] [money] NOT NULL CONSTRAINT [DF_MetavanteLoans_Amount] DEFAULT ((0)),
[ValueDate] [datetime] NOT NULL CONSTRAINT [DF_MetavanteLoans_ValueDate] DEFAULT (((1)/(1))/(1900)),
[MaturityDate] [datetime] NOT NULL CONSTRAINT [DF_MetavanteLoans_MaturityDate] DEFAULT (((1)/(1))/(1900)),
[FXrate] [float] NOT NULL CONSTRAINT [DF_MetavanteLoans_FXrate] DEFAULT ((1.0)),
[OverRide] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Rejectreason] [varchar] (132) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_Rejectreason] DEFAULT (''),
[LoanState] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_LoanState] DEFAULT (''),
[Currency] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_Currency] DEFAULT ('USD'),
[IncDec] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_IncDec] DEFAULT (''),
[ProcessDate] [datetime] NOT NULL CONSTRAINT [DF_MetavanteLoans_ProcessDate] DEFAULT (((1)/(1))/(1900)),
[ErrorCode] [int] NOT NULL CONSTRAINT [DF_MetavanteLoans_ErrorCode] DEFAULT ((0)),
[ErrorReasonCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_ErrorReasonCode] DEFAULT (''),
[ErrorMsgNum] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_ErrorMsgNum] DEFAULT (''),
[ErrorMsgText] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_ErrorMsgText] DEFAULT (''),
[ErrorMsgField] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_ErrorMsgField] DEFAULT (''),
[OutgoingMsgText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_OutgoingMsgText] DEFAULT (''),
[ResponseMsgText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MetavanteLoans_ResponseMsgText] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_MetavanteLoans] on [dbo].[MetavanteLoans]'
GO
ALTER TABLE [dbo].[MetavanteLoans] ADD CONSTRAINT [PK_MetavanteLoans] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtil]'
GO
CREATE TABLE [dbo].[LocCertOfUtil]
(
[Pkey] [int] NOT NULL CONSTRAINT [DF_LocCertOfUtil_Pkey] DEFAULT ((0)),
[LocPrimaryPkey] [int] NOT NULL CONSTRAINT [DF_LocCertOfUtil_LocPrimaryPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_LocCertOfUtil_TransPkey] DEFAULT ((0)),
[ReplacePkey] [int] NOT NULL CONSTRAINT [DF_LocCertOfUtil_ReplacePkey] DEFAULT ((0)),
[GtsAction] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocCertOfUtil_GtsAction] DEFAULT ('ADD'),
[UtilizedAmount] [money] NOT NULL CONSTRAINT [DF_LocCertOfUtil_UtilizedAmount] DEFAULT ((0)),
[AverageDailyBalance] [money] NOT NULL CONSTRAINT [DF_LocCertOfUtil_AverageDailyBalance] DEFAULT ((0)),
[CollateralizationPercentage] [float] NOT NULL CONSTRAINT [DF_LocCertOfUtil_CollateralizationPercentage] DEFAULT ((0)),
[UPDATABASE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_LocCertOfUtil_UPDATABASE] DEFAULT ('Y')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_LocCertOfUtil] on [dbo].[LocCertOfUtil]'
GO
ALTER TABLE [dbo].[LocCertOfUtil] ADD CONSTRAINT [PK_LocCertOfUtil] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[PartyRegion]'
GO
CREATE TABLE [dbo].[PartyRegion]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[Code] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartyRegion_Code] DEFAULT (''),
[ListName] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartyRegion_ListName] DEFAULT (''),
[Description] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartyRegion_Description] DEFAULT (''),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_PartyRegion_LegalEntity] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_PartyRegion_Active] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_PartyRegion] on [dbo].[PartyRegion]'
GO
ALTER TABLE [dbo].[PartyRegion] ADD CONSTRAINT [PK_PartyRegion] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[TTMMessages]'
GO
CREATE TABLE [dbo].[TTMMessages]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_TTMMessages_TransPkey] DEFAULT ((0)),
[Status] [int] NOT NULL CONSTRAINT [DF_TTMMessages_Status] DEFAULT ((0)),
[TTMStatus] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_TTMStatus] DEFAULT (''),
[Service] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_Service] DEFAULT (''),
[Product] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_Product] DEFAULT (''),
[OurReference] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_OurReference] DEFAULT (''),
[TTMReference] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_TTMReference] DEFAULT (''),
[GTSAckMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Table_1_GTSInitMessage] DEFAULT (''),
[GTSProcessMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_GTSProcessMessage] DEFAULT (''),
[TTMInitMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_TTMInitMessage] DEFAULT (''),
[TTMAckMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_Table_1_TTMProcessMessage] DEFAULT (''),
[SwiftHdr] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_SwiftHdr] DEFAULT (''),
[SwiftText] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_TTMMessages_SwiftText] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_TTMMessages] on [dbo].[TTMMessages]'
GO
ALTER TABLE [dbo].[TTMMessages] ADD CONSTRAINT [PK_TTMMessages] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MemLanguage]'
GO
CREATE TABLE [dbo].[MemLanguage]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[Code] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MemLanguage_Code] DEFAULT (''),
[Description] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_MemLanguage_Description] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_MemLanguage] on [dbo].[MemLanguage]'
GO
ALTER TABLE [dbo].[MemLanguage] ADD CONSTRAINT [PK_MemLanguage] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BridgerStatus]'
GO
CREATE TABLE [dbo].[BridgerStatus]
(
[StatusName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BridgerStatus_StatusName] DEFAULT (''),
[Status] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BridgerStatus_Status] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ABARouting]'
GO
CREATE TABLE [dbo].[ABARouting]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ABARouting_LegalEntity] DEFAULT (''),
[Code] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ABARouting_Code] DEFAULT (''),
[RoutingNum] [varchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ABARouting_RoutingNum] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_ABARouting] on [dbo].[ABARouting]'
GO
ALTER TABLE [dbo].[ABARouting] ADD CONSTRAINT [PK_ABARouting] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BridgerResults]'
GO
CREATE TABLE [dbo].[BridgerResults]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[OutBoundToDoPkey] [int] NOT NULL CONSTRAINT [DF_BridgerResults_OutBoundToDoPkey] DEFAULT ((0)),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_BridgerResults_TransPkey] DEFAULT ((0)),
[ResultID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BridgerResults_ResultID] DEFAULT (''),
[Status] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BridgerResults_Status] DEFAULT (''),
[AlertState] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BridgerResults_AlertState] DEFAULT (''),
[DateTimeSent] [datetime] NOT NULL CONSTRAINT [DF_BridgerResults_DateTimeSent] DEFAULT ('1/1/1900'),
[DateTimeReceived] [datetime] NOT NULL CONSTRAINT [DF_BridgerResults_DateTimeReceived] DEFAULT ('1/1/1900'),
[ClientReference] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_BridgerResults_ClientReference] DEFAULT ('')
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_BridgerResults] on [dbo].[BridgerResults]'
GO
ALTER TABLE [dbo].[BridgerResults] ADD CONSTRAINT [PK_BridgerResults] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FHLEditChecks]'
GO
CREATE TABLE [dbo].[FHLEditChecks]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[TransPkey] [int] NOT NULL CONSTRAINT [DF_FHLEditChecks_TransPkey] DEFAULT ((0)),
[Status] [int] NOT NULL CONSTRAINT [DF_FHLEditChecks_Status] DEFAULT ((0)),
[OurReferenceNum] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLEditChecks_OurReferenceNum] DEFAULT (''),
[SentTSR] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLEditChecks_SentTSR] DEFAULT (''),
[SentDateTime] [datetime] NOT NULL CONSTRAINT [DF_FHLEditChecks_SentDateTime] DEFAULT ('1/1/1900'),
[ResponseMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLEditChecks_ResponseMessage] DEFAULT (''),
[OverrideText] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLEditChecks_OverrideText] DEFAULT (''),
[OverrideTSR] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLEditChecks_OverrideTSR] DEFAULT (''),
[OverrideDateTime] [datetime] NOT NULL CONSTRAINT [DF_FHLEditChecks_OverrideDateTime] DEFAULT ('1/1/1900'),
[AuthorizationCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FHLEditChecks_AuthorizationCode] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_FHLEditChecks] on [dbo].[FHLEditChecks]'
GO
ALTER TABLE [dbo].[FHLEditChecks] ADD CONSTRAINT [PK_FHLEditChecks] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FeeCategory]'
GO
CREATE TABLE [dbo].[FeeCategory]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[Code] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeeCategory_Code] DEFAULT (''),
[Description] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_FeeCategory_Description] DEFAULT (''),
[Active] [bit] NOT NULL CONSTRAINT [DF_FeeCategory_Active] DEFAULT ((0))
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_FeeCategory] on [dbo].[FeeCategory]'
GO
ALTER TABLE [dbo].[FeeCategory] ADD CONSTRAINT [PK_FeeCategory] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MemFHLBondPurpose]'
GO
CREATE TABLE [dbo].[MemFHLBondPurpose]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Code] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Active] [bit] NOT NULL,
[OrderBy] [int] NOT NULL
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_MemFHLBondPurpose] on [dbo].[MemFHLBondPurpose]'
GO
ALTER TABLE [dbo].[MemFHLBondPurpose] ADD CONSTRAINT [PK_MemFHLBondPurpose] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MemFHLLCPurpose]'
GO
CREATE TABLE [dbo].[MemFHLLCPurpose]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Service] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Code] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Active] [bit] NOT NULL,
[OrderBy] [int] NOT NULL
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_MemFHLLCPurpose] on [dbo].[MemFHLLCPurpose]'
GO
ALTER TABLE [dbo].[MemFHLLCPurpose] ADD CONSTRAINT [PK_MemFHLLCPurpose] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MemFHLRatingAgency]'
GO
CREATE TABLE [dbo].[MemFHLRatingAgency]
(
[Pkey] [int] NOT NULL IDENTITY(1, 1),
[LegalEntity] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Code] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Active] [bit] NOT NULL,
[OrderBy] [int] NOT NULL
) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating primary key [PK_MemFHLRatingAgency] on [dbo].[MemFHLRatingAgency]'
GO
ALTER TABLE [dbo].[MemFHLRatingAgency] ADD CONSTRAINT [PK_MemFHLRatingAgency] PRIMARY KEY CLUSTERED  ([Pkey]) ON [PRIMARY]
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[BalScfPrimary]'
GO
ALTER TABLE [dbo].[BalScfPrimary] WITH NOCHECK ADD CONSTRAINT [CK_BalScfPrimary] CHECK (([pkey]<>(0)))
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[ModelScfPrimary]'
GO
ALTER TABLE [dbo].[ModelScfPrimary] WITH NOCHECK ADD CONSTRAINT [CK_ModelScfPrimary] CHECK (([pkey]<>(0)))
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[PartySHIP]'
GO
ALTER TABLE [dbo].[PartySHIP] WITH NOCHECK ADD CONSTRAINT [CK_PartySHIP] CHECK (([pkey]<>(0)))
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Adding constraints to [dbo].[ScfPrimary]'
GO
ALTER TABLE [dbo].[ScfPrimary] WITH NOCHECK ADD CONSTRAINT [CK_ScfPrimary] CHECK (([pkey]<>(0)))
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating extended properties'
GO
EXEC sp_addextendedproperty N'MS_Description', N'', 'SCHEMA', N'dbo', 'TABLE', N'BalScfPrimary', 'COLUMN', N'Chk2Value'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
EXEC sp_addextendedproperty N'MS_Description', N'', 'SCHEMA', N'dbo', 'TABLE', N'ModelScfPrimary', 'COLUMN', N'Chk2Value'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
EXEC sp_addextendedproperty N'MS_Description', N'', 'SCHEMA', N'dbo', 'TABLE', N'ScfPrimary', 'COLUMN', N'Chk2Value'
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
COMMIT TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
DECLARE @Success AS BIT
SET @Success = 1
SET NOEXEC OFF
IF (@Success = 1) PRINT 'The database update succeeded'
ELSE BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
	PRINT 'The database update failed'
END
GO
