DECLARE @GtsService varchar(4)
DECLARE @Description varchar(50)
DECLARE @Enabled varchar(1)

/* *********************************************
   ALL
   ********************************************* */
SET @GtsService = 'ALL'
SET @Description = 'Overarching (master agreement)'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   IMP
   ********************************************* */
SET @GtsService = 'IMP'
SET @Description = 'Import Letters of Credit'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   STB
   ********************************************* */
SET @GtsService = 'STB'
SET @Description = 'Standby Letters of Credit'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   EXP
   ********************************************* */
SET @GtsService = 'EXP'
SET @Description = 'Export Letters of Credit'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   DIR
   ********************************************* */
SET @GtsService = 'DIR'
SET @Description = 'Direct Collections'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   CEX
   ********************************************* */
SET @GtsService = 'CEX'
SET @Description = 'Export Collections'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   COL
   ********************************************* */
SET @GtsService = 'COL'
SET @Description = 'Direct/ Export Collections'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   CIM
   ********************************************* */
SET @GtsService = 'CIM'
SET @Description = 'Import Collection Payment Authorization'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   SAR
   ********************************************* */
SET @GtsService = 'SAR'
SET @Description = 'Steamship/ Air Release Application'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

/* *********************************************
   SCF
   ********************************************* */
SET @GtsService = 'SCF'
SET @Description = 'Supply Chain Finance Application'
SET @Enabled = 'Y'

IF NOT EXISTS (SELECT PKey FROM UserAgreementControl WHERE (GtsService = @GtsService)) BEGIN
	INSERT UserAgreementControl (GtsService, Description, Enabled)
	VALUES (@GtsService, @Description, @Enabled);
	print 'Added ' + @GtsService + '(' + @Description + ') to UserAgreementControl table'
END
ELSE BEGIN
	print @GtsService + '(' + @Description + ') already in UserAgreementControl table'
END

