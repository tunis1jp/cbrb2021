delete from DBSchemaTablesDotNet
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Accounting')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'AmdDetail')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'AR')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BADrafts')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalAR')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalBADrafts')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalBAPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalCashLetter')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalColPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocAutoSchedule')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocBillofLading')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocCollateral')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocCreditFacility')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocDocuments')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocFee')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocFeeDetail')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BALLocLegalDocuments')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalLocPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalSteamShipGuarantee')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BalWirePrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'BAPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'CashLetter')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Clauses')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ColPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ColText')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'CommonData')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'CRM_MASTER')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'CustomData')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'CustomScreen')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'DDA')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Department')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'DGMDocument')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Division')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'DocsReceived')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'EvergreenRenewal')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'FED')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'FedWork')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Fees')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'flow')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'IccUsers')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LoanDefinition')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LoanType')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocAmend')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocAutoSchedule')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocBillOfLading')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocCollateral')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocCreditFacility')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocDiscrepancy')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocDocuments')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocEvent')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocFee')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocFeeDetail')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocLegalDocuments')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocLoan')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocLoanSchedule')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocOutputSelection')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocShippingParties')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocSpecialInstructions')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocTemplate')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'LocText')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memAvailableWith')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memBankGroups')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memCashLetter')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemCollateralTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemCollectionTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memCommodityCode')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemCourierName')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memCurrencyCodes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memDiscrepancyTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memDocumentTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memDraftsDrawnOn')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemEventType')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemExpenseCodes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeeCalBasis')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeeDayBasis')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeeFinalPeriods')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeeMethod')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeePeriods')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeePosting')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeeThreshhold')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memFeeWhenCharged')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memGEOCountryState')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemGlAccounts')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemGuaranteeCodes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemHow')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemImages')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemIncoTerms')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memLegalDocumentTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemLegalEntity')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemLetterForm')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemLetterTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemLiabilityPosting')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemPartyTypes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemPurposeCodes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemReasonCodes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memRiskRating')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memSICCodes')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memSwiftBankCharges')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'memTenorPhrase')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemTransactionChar')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemVia')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'MemWho')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Model')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelColPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelColText')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelLocBillOfLading')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelLocCollateral')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelLocDocuments')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelLocOutputSelection')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelLocPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelLocText')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelPayParties')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelPayPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelSteamshipGuarantee')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ModelWirePrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'NegWorksheet')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Ofac')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'OfacChildParties')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'OutBoundToDo')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ParmsGTS')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ParmsLE')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartCommitmentNum')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartDisbursement')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartDisbursementDetail')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartDisbursementDetailWork')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartFeeSharing')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartGroup')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartParties')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Party')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyContacts')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyContactsPending')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyFATCA')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyFedwire')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyFedwirePending')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyOfac')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartyPending')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartySHIP')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartySwift')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PartySwiftPending')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PayCharges')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PayParties')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'PayPrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ResearchItems')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'RevType')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ServiceProduct')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ShippingCountries')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'ShippingCountriesPay')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SNBCreditFacilities')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SNBCreditLine')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SteamshipGuarantee')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFFldRules')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFInControls')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFInFini')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFInHold')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFInReady')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFInRoute')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SWFMsgRules')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Swift')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'Swift759')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SwiftBicBke')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'SwiftWork')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'TextOutbound')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'TLXInFini')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'TLXInReady')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'USC_PortfolioTab')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'UserFunction')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'UserLE')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'UserMain')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'USERPROGRAM')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'WipItems')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'WirePrimary')
GO
INSERT [dbo].[DBSchemaTablesDotNet] ([TableName]) VALUES (N'WorkingSet')
GO
