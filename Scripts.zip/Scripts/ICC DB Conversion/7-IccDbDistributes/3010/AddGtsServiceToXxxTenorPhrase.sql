if not exists (select column_name  from INFORMATION_SCHEMA.columns
               where table_name = 'xxxTenorPhrase' and column_name = 'GtsService') BEGIN
	Alter Table xxxTenorPhrase
	Add GtsService varchar(30) Not Null
	Constraint DF_xxxTenorPhrase_GtsService Default ''

	print 'Added GtsService Column to xxxTenorPhrase'
END
ELSE BEGIN
	print 'GtsService Column already exists in xxxTenorPhrase'
END

