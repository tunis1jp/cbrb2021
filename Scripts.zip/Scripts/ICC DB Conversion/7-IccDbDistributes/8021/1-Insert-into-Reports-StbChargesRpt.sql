
/* ******************************************* */
/* Insert into Reports Table Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
    If not exists (Select ReportDescription from Reports where  ReportDescription like '%Standby Charges%')
    BEGIN
INSERT INTO [Reports]([PKey], [CustomerId], [BranchId], [ReportDescription], [ReportName], [ItemLevelPKey], [TableName], [ReportType], [BankId], [GroupLevelEntKey], [AppLevelEntKey], [ItemLevelEntKey], [Active], [OrderBy])
Select (Select Max(Pkey) + 1 from [Reports]), 0, 0, N'Standby Charges by Charge Date', N'LcChgByChargeDate.rpt', 43, N'LcHistoryBalance', N'ActiveReports', 1, N'STB', N'INQ', N'RPT', N'Y', 0
PRINT 'Inserted Standby Charged report into the Reports table!'
End
ELSE BEGIN
    print 'Standby Charges Report already exists in Reports'
END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

