/* ******************************************* */
/* Alter ParmsICC Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF  NOT EXISTS (SELECT * FROM sys.columns 
		            WHERE NAME = N'IccUrl' and Object_ID = Object_ID(N'ParmsICC'))
		BEGIN
			ALTER TABLE ParmsICC ADD
				IccUrl varchar(MAX) NOT NULL CONSTRAINT DF_ParmsICC_IccUrl DEFAULT ('');
			print 'IccUrl added to ParmsICC table'
		END
		ELSE BEGIN
			print 'IccUrl already in ParmsICC table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

