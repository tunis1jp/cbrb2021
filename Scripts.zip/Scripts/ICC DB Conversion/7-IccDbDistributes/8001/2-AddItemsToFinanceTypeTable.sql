DECLARE @LegalEntity varchar(2)
DECLARE @BankId int
DECLARE @Code varchar(3)
DECLARE @Description varchar(25)
DECLARE @Active varchar(1)
DECLARE @OrderBy int

SET @BankId = 1
SET @LegalEntity = (SELECT LegalEntity FROM Banks WHERE PKey = (SELECT TOP 1 PKey FROM Banks ORDER BY PKey DESC))
SET @Active = 'Y'
SET @OrderBy = 1

SET @Code = 'DP'
SET @Description = 'Draft Purchase'
IF NOT EXISTS (SELECT Code FROM xxxFinanceType WHERE LegalEntity = @LegalEntity AND Code = @Code) BEGIN
	INSERT xxxFinanceType (LegalEntity,Code,Description,Active,OrderBy,BankId)
	VALUES (@LegalEntity, @Code, @Description, @Active, @OrderBy, @BankId)
	print 'Added xxxFinanceType record for ' + @LegalEntity + '-' + @Code + ': ' + @Description
END
ELSE BEGIN
	UPDATE xxxFinanceType SET Code = @Code WHERE Description = @Description AND LegalEntity = @LegalEntity
	print 'Updated xxxFinanceType record for ' + @LegalEntity + '-' + @Code + ': ' + @Description
END
