// **********************************************************************
//
// **********************************************************************
function SaveListValue(lst,sReq) {
	var sId
	var iIndex
	
	sId = ""
	iIndex = -1
	
	iIndex = lst.selectedIndex
	sId = lst[iIndex].value
	return (sReq + sId)
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function TopLevelChanged(form) {
	var sMore

	sMore =  SaveListValue (form.lstTopLevel,"&T=")
	document.location = "DbMaint.asp?WCI=DbMaint" + sMore + "&M=1&B=1"
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function MidLevelChanged(form) {
	var sMore
	
	sMore = SaveListValue (form.lstTopLevel, "&T=") 
				+ SaveListValue (form.lstMidLevel,"&M=") 
					+ "&B=1"

	document.location = "DbMaint.asp?WCI=DbMaint" + sMore
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function BotLevelChanged(form) {
	var sMore
	
	sMore = SaveListValue (form.lstTopLevel, "&T=") 
				+ SaveListValue (form.lstMidLevel,"&M=") 
					+ SaveListValue (form.lstBotLevel, "&B=")

	document.location = "DbMaint.asp?WCI=DbMaint" + sMore
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function CustomerChanged(form) {
	var sId
	var iIndex
	var sMore
	
	sId = ""
	iIndex = -1
	
	//---------------------------------------------------------------
	// save the Top, Mid, and Bot settings
	// they will never be empty
	//---------------------------------------------------------------
	sMore = SaveListValue (form.lstTopLevel, "&T=") 
				+ SaveListValue (form.lstMidLevel,"&M=") 
					+ SaveListValue (form.lstBotLevel, "&B=")

	//---------------------------------------------------------------
	// pass the changed customer
	//---------------------------------------------------------------
	iIndex = form.lstCustomers.selectedIndex
	sId = form.lstCustomers[iIndex].value
	sMore = sMore + "&CId=" + sId + "&BId=0"

	document.location = "DbMaint.asp?WCI=DbMaint" + sMore
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function BranchChanged(form) {
	var sId
	var iIndex
	var sMore
	
	sId = ""
	iIndex = -1
	
	//---------------------------------------------------------------
	// save the Top, Mid, and Bot settings
	// they will never be empty
	//---------------------------------------------------------------
	sMore = SaveListValue (form.lstTopLevel, "&T=") 
				+ SaveListValue (form.lstMidLevel,"&M=") 
					+ SaveListValue (form.lstBotLevel, "&B=")

	//---------------------------------------------------------------
	// pass the customer
	//---------------------------------------------------------------
	iIndex = form.lstCustomers.selectedIndex
	sId = form.lstCustomers[iIndex].value
	sMore = sMore + "&CId=" + sId 

	iIndex = form.lstBranches.selectedIndex
	sId = form.lstBranches[iIndex].value
	sMore = sMore + "&BId=" + sId 

	document.location = "DbMaint.asp?WCI=DbMaint" + sMore
}

//-----------------------------------------------------------------------------
// function to validate a field on a form
//-----------------------------------------------------------------------------
function Validate(form, button) {
	var iIndex = 0
	var iCnt = 0
	var iIdx = 0
			
	// customer id
	iIndex = form.lstCustomers.selectedIndex
	if (iIndex < 0) {
		alert ("Customer selection is required")
		form.lstCustomers.focus();
		return (false);
	}

	return(true);
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function DbMaint_Submit(form, button){
	var bOk
	
	switch(button)	{
		case 0:  // BTNBACK															
			// cancel button pressed, now handled in submit routine
			//document.location = "../bank.asp?WCI=Main";		
			// so that session variables can be cleared
			//return (false);
			break;
			
		case 3:	// Go
			bOk = confirm("You have selected to delete records from the Icc database.  Do you want to continue?")
			if (bOk == false) {
				return (false)
			}
			break;
			
		case 4: //	Testing
			bOk = confirm("You have selected to test the selected function.  Do you want to continue?")
			if (bOk == false) {
				return (false)
			}
			break;

		default:
			alert ("Button " + button + " not implemented.")
			return (false);
			break;
	}
	form.txtAction.value = button
	form.submit();
}

