DECLARE @Category varchar(50)
DECLARE @BaseSql varchar(max)

/*---------------------------------------------------------------------------*/
SET @Category = 'LcImpEnt'
/*---------------------------------------------------------------------------*/
SET @BaseSql = N'SELECT LcApplication.*
    ,Opnr.Name AS OpnrName
    ,Opnr.Address1 AS OpnrAddress1
    ,Opnr.Address2 AS OpnrAddress2
    ,Opnr.Address3 AS OpnrAddress3
    ,Opnr.Address4 AS OpnrAddress4
    ,OpnrCountry.Name AS OpnrCountry
    ,Bene.Name AS BeneName
    ,Bene.Address1 AS BeneAddress1
    ,Bene.Address2 AS BeneAddress2
    ,Bene.Address3 AS BeneAddress3
    ,Bene.Address4 AS BeneAddress4
    ,BeneCountry.Name AS BeneCountry
    ,Advb.Name AS AdvbName
    ,Advb.GtsHostId AS AdvbGtsId
    ,Advb.PartyId AS AdvbBankId
    ,Advb.Address1 AS AdvbAddress1
    ,Advb.Address2 AS AdvbAddress2
    ,Advb.Address3 AS AdvbAddress3
    ,Advb.Address4 AS AdvbAddress4
    ,AdvbCountry.Name AS AdvbCountry
    ,memStatus.Description AS StatusDescription
    ,Currency.Description AS CurrencyName
    ,xxxUcpCodes.Paragraph AS UcpParagraph
    ,(SELECT CASE ISNULL(xxxPurposeCodes.Description,'''')
         WHEN '''' THEN ''''
         ELSE xxxPurposeCodes.Description END) AS PurposeCodeDescription
    FROM LcApplication 
    LEFT OUTER JOIN Party AS Opnr ON (LcApplication.OpenerPKey = Opnr.PKey)
    LEFT OUTER JOIN xxxCountries AS OpnrCountry ON (Opnr.Country = OpnrCountry.Code)
    LEFT OUTER JOIN Party AS Bene ON (LcApplication.BenePKey = Bene.PKey)
    LEFT OUTER JOIN xxxCountries AS BeneCountry ON (Bene.Country = BeneCountry.Code)
    LEFT OUTER JOIN Party AS Advb ON (LcApplication.AdviseThruPKey = Advb.PKey)
    LEFT OUTER JOIN xxxCountries AS AdvbCountry ON (Advb.Country = AdvbCountry.Code)
    LEFT OUTER JOIN memStatus ON (LcApplication.Status = memStatus.Status)
    LEFT OUTER JOIN memCurrencyCodes AS Currency ON (LcApplication.CurrencyCode = Currency.Code)
    LEFT OUTER JOIN xxxPurposeCodes ON (LCApplication.PurposeCode = xxxPurposeCodes.Code)
        AND (LcApplication.GtsService = xxxPurposeCodes.GtsService)
    LEFT OUTER JOIN xxxUcpCodes ON (LcApplication.UcpCode = xxxUcpCodes.Code)
        AND (LcApplication.GtsService = xxxUcpCodes.AppType)'
    
UPDATE ActiveReports SET BaseSql = @BaseSql WHERE Category = @Category AND BaseSql <> @BaseSql
print 'Updated BaseSql for ' + @Category
    
/*---------------------------------------------------------------------------*/
/* BaseSql is the same for LcStbEnt */
SET @Category = 'LcStbEnt'
/*---------------------------------------------------------------------------*/
UPDATE ActiveReports SET BaseSql = @BaseSql WHERE Category = @Category AND BaseSql <> @BaseSql
print 'Updated BaseSql for ' + @Category
    

/*---------------------------------------------------------------------------*/
SET @Category = 'LcImpXmd'
/*---------------------------------------------------------------------------*/
SET @BaseSql = N'SELECT LcAmendment.*
    ,LcHistoryBalance.DraftsDrawnOn AS BalDraftsDrawnOn
    ,LcHistoryBalance.DraftsDrawnOnContinued AS BalDraftsDrawnOnContinued
    ,LcHistoryBalance.ExpirationDate AS BalExpirationDate
    ,LcHistoryBalance.ExpirationPlace AS BalExpirationPlace
    ,LcHistoryBalance.FaceAmount AS BalFaceAmount
    ,LcHistoryBalance.ConfirmInstructions AS BalConfirmInstructions
    ,LcHistoryBalance.AutoExtTermsMonth AS BalAutoExtTermsMonth
    ,LcHistoryBalance.AutoExtNotifDay AS BalAutoExtNotifDay
    ,LcHistoryBalance.UcpCode AS BalUcpCode
    ,LcHistoryBalance.UcpOther AS BalUcpOther
    ,LcHistoryBalance.BenePKey AS BalBenePKey
    ,LCHistoryBalance.BeneName AS BalBeneName
    ,LcHistoryBalance.BeneAddress1 AS BalBeneAddress1
    ,LcHistoryBalance.BeneAddress2 AS BalBeneAddress2
    ,LcHistoryBalance.BeneAddress3 AS BalBeneAddress3
    ,LcHistoryBalance.BeneAddress4 AS BalBeneAddress4
    ,LcHistoryBalance.AdviseThruPKey AS BalAdviseThruPKey
    ,LcHistoryBalance.AdvtName AS BalAdvbName
    ,LcHistoryBalance.AdvtAddress1 AS BalAdvbAddress1
    ,LcHistoryBalance.AdvtAddress2 AS BalAdvbAddress2
    ,LcHistoryBalance.AdvtAddress3 AS BalAdvbAddress3
    ,LcHistoryBalance.AdvtAddress4 AS BalAdvbAddress4
    ,LcHistoryBalance.TolerancePlus AS BalTolerancePlus
    ,LcHistoryBalance.ToleranceMinus AS BalToleranceMinus
    ,LcHistoryBalance.DateOptions AS BalDateOptions
    ,LcHistoryBalance.EarliestShipDate AS BalEarliestShipDate
    ,LcHistoryBalance.LatestShipDate AS BalLatestShipDate
    ,LcHistoryBalance.PartialShip AS BalPartialShip
    ,LcHistoryBalance.PartialShipConditions AS BalPartialShipConditions
    ,LcHistoryBalance.TransShip AS BalTransShip
    ,LcHistoryBalance.TransShipConditions AS BalTransShipConditions
    ,LcHistoryBalance.TransferableConditions AS BalTransferableConditions
    ,LcHistoryBalance.DaysPresentDocument AS BalDaysPresentDocument
    ,LcHistoryBalance.TenorPercent AS BalTenorPercent
    ,LcHistoryBalance.TenorDays AS BalTenorDays
    ,LcHistoryBalance.TenorPhrase AS BalTenorPhrase
    ,LcHistoryBalance.TenorPhrase1 AS BalTenorPhrase1
    ,LcHistoryBalance.TenorDays1 AS BalTenorDays1
    ,LcHistoryBalance.TenorPercent1 AS BalTenorPercent1
    ,LcHistoryBalance.ShipFrom AS BalShipFrom
    ,LcHistoryBalance.ShipTo AS BalShipTo
    ,LcHistoryBalance.PortOfLoading AS BalPortOfLoading
    ,LcHistoryBalance.PortOfDischarge AS BalPortOfDischarge
    ,LcHistoryBalance.AvailableWith AS BalAvailableWith
    ,LcHistoryBalance.AvailableWithContinued AS BalAvailableWithContinued
    ,LcHistoryBalance.AvailableBy AS BalAvailableBy
    ,LcHistoryBalance.AvailableByDetail AS BalAvailableByDetail
    ,LcHistoryBalance.PlacePort AS BalPlacePort
    ,LcHistoryBalance.IncoTerms AS BalIncoTerms
    ,LcHistoryBalance.IncoTermsOther AS BalIncoTermsOther
    ,(SELECT CASE ISNULL(BAL.Description,'''')
         WHEN '''' THEN ''''
         ELSE BAL.Description END) AS BalPurposeCodeDescription
    ,(SELECT CASE ISNULL(xxxPurposeCodes.Description,'''')
         WHEN '''' THEN ''''
         ELSE xxxPurposeCodes.Description END) AS PurposeCodeDescription
    ,memStatus.Description AS StatusDescription
    ,Currency.Description AS CurrencyName
    ,xxxUcpCodes.Paragraph AS UcpParagraph   
FROM LcAmendment 
LEFT OUTER JOIN LcHistoryBalance ON (LcAmendment.BalancePKey = LcHistoryBalance.PKey)   
LEFT OUTER JOIN memStatus ON (LcAmendment.Status = memStatus.Status)   
LEFT OUTER JOIN memCurrencyCodes AS Currency ON (LcAmendment.CurrencyCode = Currency.Code)   
LEFT OUTER JOIN xxxPurposeCodes ON (LcAmendment.PurposeCode = xxxPurposeCodes.Code)
    AND (LCAmendment.GtsService = xxxPurposeCodes.GtsService)
LEFT OUTER JOIN xxxPurposeCodes AS BAL ON (LcHistoryBalance.PurposeCode = xxxPurposeCodes.Code)
    AND (LCHistoryBalance.GtsService = xxxPurposeCodes.GtsService)
LEFT OUTER JOIN xxxUcpCodes ON (LcAmendment.UcpCode = xxxUcpCodes.Code)
    AND (LcAmendment.GtsService = xxxUcpCodes.AppType)'

UPDATE ActiveReports SET BaseSql = @BaseSql WHERE Category = @Category AND BaseSql <> @BaseSql
print 'Updated BaseSql for ' + @Category
    
/*---------------------------------------------------------------------------*/
/* BaseSql is the same for LcStbXmd */
SET @Category = 'LcStbXmd'
/*---------------------------------------------------------------------------*/
UPDATE ActiveReports SET BaseSql = @BaseSql WHERE Category = @Category AND BaseSql <> @BaseSql
print 'Updated BaseSql for ' + @Category
    
