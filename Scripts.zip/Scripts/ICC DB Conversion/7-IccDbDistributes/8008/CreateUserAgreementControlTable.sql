/* ******************************************* */
/* UserAgreementControl table. This table will be populated with 1 record for each
   GtsService-GtsFunction combination that will require a user agreement 
   The table will be populated by SQL only but the Required and Enabled flags
   and the AgreementFile (PDF hopefully) will need a maintenance function */
/* ******************************************* */
IF NOT EXISTS (SELECT *
           FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_TYPE='BASE TABLE' 
           AND TABLE_NAME='UserAgreementControl') BEGIN
	CREATE TABLE UserAgreementControl(
		PKey INT Constraint PK_UserAgreementControl_PKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
		GtsService varchar(4) NOT NULL CONSTRAINT DF_UserAgreementControl_GtsService DEFAULT (''),
		Description varchar(50) NOT NULL CONSTRAINT DF_UserAgreementControl_Description DEFAULT (''),
		Enabled varchar(1) NOT NULL CONSTRAINT DF_UserAgreementControl_Enabled DEFAULT ('N')
	);
	
CREATE  INDEX IX_UserAgreementControl_GtsService ON UserAgreementControl(GtsService);
	
	print 'Created UserAgreementControl table'
END
ELSE BEGIN
	print 'UserAgreementControl table already exists in this DB'
END
