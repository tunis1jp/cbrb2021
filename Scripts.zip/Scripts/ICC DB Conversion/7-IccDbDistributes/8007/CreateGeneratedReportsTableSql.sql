/* ******************************************* */

/* Generated Reports Table */

/* ******************************************* */
BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='GeneratedReports') 
			BEGIN 
                CREATE TABLE GeneratedReports(
                                RptRecordPkey INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
                                SchedulerFkey INT NOT NULL Constraint DF_GeneratedReports_SchedulerFkey DEFAULT (0),
                                ReportName VARCHAR(64) NOT NULL CONSTRAINT DF_GeneratedReports_ReportName Default (''),
                                ReportTextBytes VARCHAR(MAX) NOT NULL CONSTRAINT DF_GeneratedReports_ReportTextBytes Default (''),
                                DateGenerated DATETIME NOT NULL CONSTRAINT DF_GeneratedReports_DataGenerated Default ('1-1-1900')
                )                             
                CREATE  INDEX IX_GeneratedReports_RptRecordPkey ON GeneratedReports(RptRecordPkey);
                print 'Created Generated Reports table'
			END
			ELSE BEGIN
                print 'Generated Reports table already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH