
/* ******************************************* */
/* Insert into Active Reports Table Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
    If not exists (Select Title from ActiveReports where  Title like '%Standby Charges%')
    BEGIN
INSERT INTO [dbo].[ActiveReports]( [ReportsPKey],[BaseSql], [Category], [Title])
SELECT (Select Max(Pkey) from [Reports]),N'SELECT LCHistoryBalance.OurReference           
	,LCHistoryBalance.BankReference           
	,LCHistoryBalance.GtsService           
	,LCHistoryBalance.CurrencyCode     
	,(SELECT CASE LcHistoryBalance.TranType
		WHEN ''I'' THEN ''Issuance''
		WHEN ''A'' THEN ''Amendment''
		WHEN ''P'' THEN ''Payment''
		ELSE LcHistoryBalance.TranType END) AS TranTypeDescription
	,LcHistoryBalance.TranDate      
	,Branches.Name AS BranchName           
	,Banks.Name           
	,LcHistoryBalance.OpnrName           
	,LcHistoryBalance.BeneName           
	,IccFee.CustomerDescription           
	,IccFee.Amount         
FROM IccFee            
	INNER JOIN LCHistoryBalance ON IccFee.TransPKey=LCHistoryBalance.GtsPKey           
	INNER JOIN Banks ON LCHistoryBalance.BankId=Banks.PKey           
	LEFT OUTER JOIN Branches ON LCHistoryBalance.BranchId=Branches.PKey', N'LcCharges', N'Standby Charges by Charge Date'
    PRINT 'Inserted Standby Charged report into the ActiveReports table!'
End
ELSE BEGIN
    print 'Standby Charges Report already exists in ActiveReports'
END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH

