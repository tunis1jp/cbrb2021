--Create TaskStatus
Declare @Name varchar (50)
Declare @ProgName varchar (50)
declare @ListName varchar(50)
Declare @Description varchar(50)


set @Name = 'EOD_LOC_ADVICEOFEXPIRY'
set @ProgName = 'LOC_AdviceofExpiry.exe'

if not exists (select * from TaskStatus where Executable = @ProgName)
begin
	INSERT [dbo].[TaskStatus] ([Task], [StartTime], [StopTime], [LastProcessDate], [RunTime], [Status], [OrderField], [FailedValue], [FailedLE], [Restart], [Export], [Report], [OrderFieldType], [ErrorDescription], [ReferenceNumber], [AllowedStepFails], [OnDemand], [Executable], [Param1], [Param2], [Param3], [UpdateStatus], [TimeStarted], [BatchProcess], [FormDisplay], [Program], [TaskCanBeSkipped], [ParentTask], [TaskRestarted], [RerunPeriod], [kdkd]) 
	VALUES (@Name, N'     ', N'', CAST(N'1900-01-01T00:00:00.000' AS DateTime), N'4', 0, N'PKEY', N'', N'', 1, 0, 0, N'N', N'Task Completed', N'', N'', N'N', @ProgName, N'', N'', N'', 0, CAST(N'1900-01-01T00:00:00.000' AS DateTime), 0, 0, 1, 1, 0, 0, 0, 0)
	Print 'Successfully added TaskStatus record for Executable: ' + @ProgName
end
else
begin
	print 'TaskStatus Record already exists for Executable: ' + @ProgName
end