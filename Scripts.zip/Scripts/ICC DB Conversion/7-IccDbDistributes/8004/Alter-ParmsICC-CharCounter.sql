/* ******************************************* */
/* Alter ParmsICC Table */
/* ******************************************* */
BEGIN TRY
	BEGIN TRAN
		IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE TABLE_NAME='ParmsICC' and Column_Name = 'CharCounter') 
			BEGIN 
                Alter TABLE ParmsICC Add CharCounter bit NOT NULL DEFAULT(0);
                print 'Altered ParmsICC Table. Added Character Counter column.'
			END
			ELSE BEGIN
                print 'Character Counter column already exists'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH