DECLARE @BankId int
DECLARE @CustomerId int
DECLARE @BranchId int

DECLARE @PageNumber int
DECLARE @PageActive varchar(1)
DECLARE @AppType varchar(6)
DECLARE @PageDesc varchar(35)
DECLARE @PageTabDesc varchar(15)

SET @BankId = 1
SET @CustomerId = 0
SET @BranchId = 0

/* ------------------------------------------------------------------------------------- */
/* Template */
/* ------------------------------------------------------------------------------------- */
SET @AppType = 'STBTMP'

/* ------------------------------------------------------------------------------------- */
/* 45C Document and Presentation Instructions 100x65z */
/* ------------------------------------------------------------------------------------- */
SET @PageDesc = N'Presentation Instructions'
SET @PageTabDesc = N'Instructions'
SET @PageNumber = 15
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/******************************************************/
/* 77U Undertaking Terms and Conditions 150x65z */
/******************************************************/
SET @PageDesc = N'Undertaking Terms and Conditions'
SET @PageTabDesc = N'U Terms & Cond.'
SET @PageNumber = 16
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/******************************************************/
/* 45L Underlying Transaction Details 50x65z */
/******************************************************/
SET @PageDesc = N'Underlying Transaction Details'
SET @PageTabDesc = N'Trans. Details'
SET @PageNumber = 17
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/* ------------------------------------------------------------------------------------- */
/* Issuance */
/* ------------------------------------------------------------------------------------- */
SET @AppType = 'STBENT'

/* ------------------------------------------------------------------------------------- */
/* 45C Document and Presentation Instructions 100x65z */
/* ------------------------------------------------------------------------------------- */
SET @PageDesc = N'Presentation Instructions'
SET @PageTabDesc = N'Instructions'
SET @PageNumber = 15
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/******************************************************/
/* 77U Undertaking Terms and Conditions 150x65z */
/******************************************************/
SET @PageDesc = N'Undertaking Terms and Conditions'
SET @PageTabDesc = N'U Terms & Cond.'
SET @PageNumber = 16
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/******************************************************/
/* 45L Underlying Transaction Details 50x65z */
/******************************************************/
SET @PageDesc = N'Underlying Transaction Details'
SET @PageTabDesc = N'Trans. Details'
SET @PageNumber = 17
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/* ------------------------------------------------------------------------------------- */
/* Amendment */
/* ------------------------------------------------------------------------------------- */
SET @AppType = 'STBXMD'

/* ------------------------------------------------------------------------------------- */
/* 45C Document and Presentation Instructions 100x65z */
/* ------------------------------------------------------------------------------------- */
SET @PageDesc = N'Presentation Instructions'
SET @PageTabDesc = N'Instructions'
SET @PageNumber = 15
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/******************************************************/
/* 77U Undertaking Terms and Conditions 150x65z */
/******************************************************/
SET @PageDesc = N'Undertaking Terms and Conditions'
SET @PageTabDesc = N'U Terms & Cond.'
SET @PageNumber = 16
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

/******************************************************/
/* 45L Underlying Transaction Details 50x65z */
/******************************************************/
SET @PageDesc = N'Underlying Transaction Details'
SET @PageTabDesc = N'Trans. Details'
SET @PageNumber = 17
SET @PageActive = 'N'

IF NOT EXISTS (SELECT PKeyIdentity FROM AppPageControls WHERE AppType = @AppType AND PageNumber = @PageNumber AND PageDesc = @PageDesc AND BranchId = @BranchId) BEGIN
	INSERT AppPageControls (CustomerId, BranchId, AppType, PageNumber, PageActive, PageDesc, BankId, PageTabDesc) 
		VALUES (@CustomerId, @BranchId, @AppType, @PageNumber, @PageActive, @PageDesc, @BankId, @PageTabDesc)
	print 'Inserted ' + @PageDesc + ' into AppPageControls for ' + @AppType
END
ELSE BEGIN
	print @PageDesc + ' already in AppPageControls for ' + @AppType
END

