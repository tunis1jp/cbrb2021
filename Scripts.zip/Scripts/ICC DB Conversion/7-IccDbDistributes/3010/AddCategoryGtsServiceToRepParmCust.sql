if not exists (select column_name  from INFORMATION_SCHEMA.columns
               where table_name = 'RepParmCust' and column_name = 'Category') BEGIN
	Alter Table RepParmCust
	Add Category varchar(50) Not Null
	Constraint DF_RepParmCust_Category Default ''

	print 'Added Category Column to RepParmCust'
END
ELSE BEGIN
	print 'Category Column already exists in RepParmCust'
END

if not exists (select column_name  from INFORMATION_SCHEMA.columns
               where table_name = 'RepParmCust' and column_name = 'GtsService') BEGIN
	Alter Table RepParmCust
	Add GtsService varchar(4) Not Null
	Constraint DF_RepParmCust_GtsService Default ''

	print 'Added GtsService Column to RepParmCust'
END
ELSE BEGIN
	print 'GtsService Column already exists in RepParmCust'
END
