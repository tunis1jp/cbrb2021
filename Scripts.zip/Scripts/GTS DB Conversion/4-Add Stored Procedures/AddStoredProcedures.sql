/*
Run this script on:

        SQL2016SVR\R8.TDBGtsNetDevR8    -  This database will be modified

to synchronize it with:

        SQL2016SVR\R8.GTSNetDevR8

You are recommended to back up your database before running this script

Script created by SQL Compare version 12.2.1.4077 from Red Gate Software Ltd at 2/8/2021 3:26:14 PM

*/
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL Serializable
GO
BEGIN TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocCertOfUtilupdate]'
GO

CREATE PROCEDURE [dbo].[BalLocCertOfUtilupdate]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = " " ,
    @UtilizedAmount                               money = 0 ,
    @AverageDailyBalance                          money = 0 ,
    @CollateralizationPercentage                  Float = 0 ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update BalLocCertOfUtil set
    LocPrimaryPkey = @LocPrimaryPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    GtsAction = @GtsAction,
    UtilizedAmount = @UtilizedAmount,
    AverageDailyBalance = @AverageDailyBalance,
    CollateralizationPercentage = @CollateralizationPercentage,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocCertOfUtilInsert]'
GO

CREATE PROCEDURE [dbo].[BalLocCertOfUtilInsert]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = "  " ,
    @UtilizedAmount                               money = 0 ,
    @AverageDailyBalance                          money = 0 ,
    @CollateralizationPercentage                  Float = 0 ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into BalLocCertOfUtil(
    Pkey ,
    LocPrimaryPkey ,
    TransPkey ,
    ReplacePkey ,
    GtsAction ,
    UtilizedAmount ,
    AverageDailyBalance ,
    CollateralizationPercentage ,
    UPDATABASE)
values (
    @Pkey ,
    @LocPrimaryPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @GtsAction ,
    @UtilizedAmount ,
    @AverageDailyBalance ,
    @CollateralizationPercentage ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainBalLocCertOfUtil]'
GO

CREATE PROCEDURE [dbo].[MainBalLocCertOfUtil]
            @Pkey                                         Int = 0 ,
            @LocPrimaryPkey                               Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @GtsAction                                    varchar(6) = "  " ,
            @UtilizedAmount                               money = 0 ,
            @AverageDailyBalance                          money = 0 ,
            @CollateralizationPercentage                  Float = 0 ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from BalLocCertOfUtil with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = BalLocCertOfUtilinsert
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @UtilizedAmount                                ,
        @AverageDailyBalance                           ,
        @CollateralizationPercentage                   ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = BalLocCertOfUtilupdate
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @UtilizedAmount                                ,
        @AverageDailyBalance                           ,
        @CollateralizationPercentage                   ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocCertOfUtilReadByPkey]'
GO

CREATE PROCEDURE [dbo].[BalLocCertOfUtilReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from BalLocCertOfUtil where pkey = @pkey
            select @rPkey = Pkey from BalLocCertOfUtil where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FeePlanDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[FeePlanDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from FeePlan where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FeePlanInsert]'
GO

CREATE PROCEDURE [dbo].[FeePlanInsert]
    @Pkey                                         Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @LoanSystem                                   varchar(20) = "  " ,
    @DateApproved                                 DateTime = 0 ,
    @DatePassed                                   DateTime = 0 ,
    @FeeID                                        varchar(6) = "  " ,
    @FeeCategory                                  varchar(5) = "  " ,
    @FeeAmount                                    money = 0 ,
    @FeeStartDate                                 DateTime = 0 ,
    @FeeEndDate                                   DateTime = 0 ,
    @EarningsTermMonths                           varchar(5) = "  " ,
    @LCFeeChg                                     varchar(1) = "  " ,
    @LCFeePay                                     varchar(1) = "  " ,
    @ExternalParticipantShare                     varchar(1) = "  " 
AS
Insert into FeePlan(
    TransPkey ,
    LocPrimaryPkey ,
    LoanSystem ,
    DateApproved ,
    DatePassed ,
    FeeID ,
    FeeCategory ,
    FeeAmount ,
    FeeStartDate ,
    FeeEndDate ,
    EarningsTermMonths ,
    LCFeeChg ,
    LCFeePay ,
    ExternalParticipantShare)
values (
    @TransPkey ,
    @LocPrimaryPkey ,
    @LoanSystem ,
    @DateApproved ,
    @DatePassed ,
    @FeeID ,
    @FeeCategory ,
    @FeeAmount ,
    @FeeStartDate ,
    @FeeEndDate ,
    @EarningsTermMonths ,
    @LCFeeChg ,
    @LCFeePay ,
    @ExternalParticipantShare)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FeePlanupdate]'
GO

CREATE PROCEDURE [dbo].[FeePlanupdate]
    @Pkey                                         Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @LoanSystem                                   varchar(20) = " " ,
    @DateApproved                                 DateTime = 0 ,
    @DatePassed                                   DateTime = 0 ,
    @FeeID                                        varchar(6) = " " ,
    @FeeCategory                                  varchar(5) = " " ,
    @FeeAmount                                    money = 0 ,
    @FeeStartDate                                 DateTime = 0 ,
    @FeeEndDate                                   DateTime = 0 ,
    @EarningsTermMonths                           varchar(5) = " " ,
    @LCFeeChg                                     varchar(1) = " " ,
    @LCFeePay                                     varchar(1) = " " ,
    @ExternalParticipantShare                     varchar(1) = " " 
AS
Update FeePlan set
    TransPkey = @TransPkey,
    LocPrimaryPkey = @LocPrimaryPkey,
    LoanSystem = @LoanSystem,
    DateApproved = @DateApproved,
    DatePassed = @DatePassed,
    FeeID = @FeeID,
    FeeCategory = @FeeCategory,
    FeeAmount = @FeeAmount,
    FeeStartDate = @FeeStartDate,
    FeeEndDate = @FeeEndDate,
    EarningsTermMonths = @EarningsTermMonths,
    LCFeeChg = @LCFeeChg,
    LCFeePay = @LCFeePay,
    ExternalParticipantShare = @ExternalParticipantShare
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainFeePlan]'
GO

CREATE PROCEDURE [dbo].[MainFeePlan]
            @Pkey                                         Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @LocPrimaryPkey                               Int = 0 ,
            @LoanSystem                                   varchar(20) = "  " ,
            @DateApproved                                 DateTime = 0 ,
            @DatePassed                                   DateTime = 0 ,
            @FeeID                                        varchar(6) = "  " ,
            @FeeCategory                                  varchar(5) = "  " ,
            @FeeAmount                                    money = 0 ,
            @FeeStartDate                                 DateTime = 0 ,
            @FeeEndDate                                   DateTime = 0 ,
            @EarningsTermMonths                           varchar(5) = "  " ,
            @LCFeeChg                                     varchar(1) = "  " ,
            @LCFeePay                                     varchar(1) = "  " ,
            @ExternalParticipantShare                     varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from FeePlan with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = FeePlaninsert
        @Pkey                                          ,
        @TransPkey                                     ,
        @LocPrimaryPkey                                ,
        @LoanSystem                                    ,
        @DateApproved                                  ,
        @DatePassed                                    ,
        @FeeID                                         ,
        @FeeCategory                                   ,
        @FeeAmount                                     ,
        @FeeStartDate                                  ,
        @FeeEndDate                                    ,
        @EarningsTermMonths                            ,
        @LCFeeChg                                      ,
        @LCFeePay                                      ,
        @ExternalParticipantShare                     

    End

    
    Else
    Begin
        Exec @lpkey = FeePlanupdate
        @Pkey                                          ,
        @TransPkey                                     ,
        @LocPrimaryPkey                                ,
        @LoanSystem                                    ,
        @DateApproved                                  ,
        @DatePassed                                    ,
        @FeeID                                         ,
        @FeeCategory                                   ,
        @FeeAmount                                     ,
        @FeeStartDate                                  ,
        @FeeEndDate                                    ,
        @EarningsTermMonths                            ,
        @LCFeeChg                                      ,
        @LCFeePay                                      ,
        @ExternalParticipantShare                     
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[FeePlanReadByPkey]'
GO

CREATE PROCEDURE [dbo].[FeePlanReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from FeePlan where pkey = @pkey
            select @rPkey = Pkey from FeePlan where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimaryDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[ScfPrimaryDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from ScfPrimary where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[RealTimeDDADeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[RealTimeDDADeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from RealTimeDDA where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimaryInsert]'
GO

CREATE PROCEDURE [dbo].[ScfPrimaryInsert]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @ScfPrimaryStatus                             varchar(6) = "  " ,
    @Active                                       Bit = 0 ,
    @GTSAction                                    varchar(6) = "  " ,
    @OurRefLegalEntity                            varchar(2) = "  " ,
    @OurRefDivisionNum                            varchar(2) = "  " ,
    @OurRefDepartmentNum                          varchar(2) = "  " ,
    @OurReferenceNum                              varchar(8) = "  " ,
    @LetterType                                   varchar(6) = "  " ,
    @SellerPkey                                   Int = 0 ,
    @SellerReference                              varchar(25) = "  " ,
    @SellerHow                                    varchar(3) = "  " ,
    @SellerDDA                                    varchar(20) = "  " ,
    @OriginalAmountBase                           money = 0 ,
    @OriginalAmount                               money = 0 ,
    @AmountOutstandingBase                        money = 0 ,
    @AmountOutstanding                            money = 0 ,
    @CurrencyCode                                 varchar(3) = "  " ,
    @FXRate                                       Float = 0 ,
    @FXContract                                   varchar(25) = "  " ,
    @EntryDate                                    DateTime = 0 ,
    @DocumentDate                                 DateTime = 0 ,
    @DateAccepted                                 DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @TenorDays                                    Int = 0 ,
    @TenorPhrase                                  varchar(50) = "  " ,
    @LastTracerVia                                varchar(3) = "  " ,
    @LastTracerDate                               DateTime = 0 ,
    @NumberOfTracers                              Int = 0 ,
    @TraceToday                                   Bit = 0 ,
    @BuyerPkey                                    Int = 0 ,
    @BuyerReference                               varchar(25) = "  " ,
    @BuyerHow                                     varchar(3) = "  " ,
    @BuyerDDA                                     varchar(20) = "  " ,
    @CreatingProgram                              varchar(10) = "  " ,
    @CollectionType                               varchar(3) = "  " ,
    @BankingGroup                                 varchar(10) = "  " ,
    @ExpenseCode                                  varchar(10) = "  " ,
    @PaidDirect                                   Bit = 0 ,
    @CloseThisCollection                          Bit = 0 ,
    @Chk1Value                                    varchar(1) = "  " ,
    @Chk2Value                                    varchar(1) = "  " ,
    @Chk3Value                                    varchar(1) = "  " ,
    @Chk4Value                                    varchar(1) = "  " ,
    @Chk5Value                                    varchar(1) = "  " ,
    @Chk6Value                                    varchar(1) = "  " ,
    @Chk7Value                                    varchar(1) = "  " ,
    @Chk8Value                                    varchar(1) = "  " ,
    @Chk9Value                                    varchar(1) = "  " ,
    @WaitingClarification                         varchar(1) = "  " ,
    @WaitingAuthentication                        varchar(1) = "  " ,
    @AmendTraceDays                               Int = 0 ,
    @AlternateAOPkey                              Int = 0 ,
    @AccountOfficerPkey                           Int = 0 ,
    @BLNumber                                     varchar(30) = "  " ,
    @ReferencePerfix                              varchar(25) = "  " ,
    @ConvertedRefNo                               varchar(25) = "  " ,
    @InvoicePONo                                  varchar(35) = "  " ,
    @ConvertedSystem                              varchar(10) = "  " ,
    @Chk10Value                                   varchar(1) = "  " ,
    @Chk11Value                                   varchar(1) = "  " ,
    @Chk12Value                                   varchar(1) = "  " ,
    @Chk13Value                                   varchar(1) = "  " ,
    @Chk14Value                                   varchar(1) = "  " ,
    @Chk15Value                                   varchar(1) = "  " ,
    @Chk16Value                                   varchar(1) = "  " ,
    @Chk17Value                                   varchar(1) = "  " ,
    @Chk18Value                                   varchar(1) = "  " ,
    @Chk19Value                                   varchar(1) = "  " ,
    @Chk20Value                                   varchar(1) = "  " ,
    @AuthForDebit                                 varchar(1) = "  " ,
    @DoNotPurge                                   Bit = 0 ,
    @ClosedDate                                   DateTime = 0 ,
    @CommitmentNum                                varchar(16) = "  " ,
    @PurposeCode                                  varchar(6) = "  " ,
    @LoanSystem                                   varchar(20) = "  " ,
    @FinanceType                                  varchar(20) = "  " ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into ScfPrimary(
    Pkey ,
    ScfPrimaryPkey ,
    EventPkey ,
    TransPkey ,
    ReplacePkey ,
    ScfPrimaryStatus ,
    Active ,
    GTSAction ,
    OurRefLegalEntity ,
    OurRefDivisionNum ,
    OurRefDepartmentNum ,
    OurReferenceNum ,
    LetterType ,
    SellerPkey ,
    SellerReference ,
    SellerHow ,
    SellerDDA ,
    OriginalAmountBase ,
    OriginalAmount ,
    AmountOutstandingBase ,
    AmountOutstanding ,
    CurrencyCode ,
    FXRate ,
    FXContract ,
    EntryDate ,
    DocumentDate ,
    DateAccepted ,
    MaturityDate ,
    TenorDays ,
    TenorPhrase ,
    LastTracerVia ,
    LastTracerDate ,
    NumberOfTracers ,
    TraceToday ,
    BuyerPkey ,
    BuyerReference ,
    BuyerHow ,
    BuyerDDA ,
    CreatingProgram ,
    CollectionType ,
    BankingGroup ,
    ExpenseCode ,
    PaidDirect ,
    CloseThisCollection ,
    Chk1Value ,
    Chk2Value ,
    Chk3Value ,
    Chk4Value ,
    Chk5Value ,
    Chk6Value ,
    Chk7Value ,
    Chk8Value ,
    Chk9Value ,
    WaitingClarification ,
    WaitingAuthentication ,
    AmendTraceDays ,
    AlternateAOPkey ,
    AccountOfficerPkey ,
    BLNumber ,
    ReferencePerfix ,
    ConvertedRefNo ,
    InvoicePONo ,
    ConvertedSystem ,
    Chk10Value ,
    Chk11Value ,
    Chk12Value ,
    Chk13Value ,
    Chk14Value ,
    Chk15Value ,
    Chk16Value ,
    Chk17Value ,
    Chk18Value ,
    Chk19Value ,
    Chk20Value ,
    AuthForDebit ,
    DoNotPurge ,
    ClosedDate ,
    CommitmentNum ,
    PurposeCode ,
    LoanSystem ,
    FinanceType ,
    UPDATABASE)
values (
    @Pkey ,
    @ScfPrimaryPkey ,
    @EventPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @ScfPrimaryStatus ,
    @Active ,
    @GTSAction ,
    @OurRefLegalEntity ,
    @OurRefDivisionNum ,
    @OurRefDepartmentNum ,
    @OurReferenceNum ,
    @LetterType ,
    @SellerPkey ,
    @SellerReference ,
    @SellerHow ,
    @SellerDDA ,
    @OriginalAmountBase ,
    @OriginalAmount ,
    @AmountOutstandingBase ,
    @AmountOutstanding ,
    @CurrencyCode ,
    @FXRate ,
    @FXContract ,
    @EntryDate ,
    @DocumentDate ,
    @DateAccepted ,
    @MaturityDate ,
    @TenorDays ,
    @TenorPhrase ,
    @LastTracerVia ,
    @LastTracerDate ,
    @NumberOfTracers ,
    @TraceToday ,
    @BuyerPkey ,
    @BuyerReference ,
    @BuyerHow ,
    @BuyerDDA ,
    @CreatingProgram ,
    @CollectionType ,
    @BankingGroup ,
    @ExpenseCode ,
    @PaidDirect ,
    @CloseThisCollection ,
    @Chk1Value ,
    @Chk2Value ,
    @Chk3Value ,
    @Chk4Value ,
    @Chk5Value ,
    @Chk6Value ,
    @Chk7Value ,
    @Chk8Value ,
    @Chk9Value ,
    @WaitingClarification ,
    @WaitingAuthentication ,
    @AmendTraceDays ,
    @AlternateAOPkey ,
    @AccountOfficerPkey ,
    @BLNumber ,
    @ReferencePerfix ,
    @ConvertedRefNo ,
    @InvoicePONo ,
    @ConvertedSystem ,
    @Chk10Value ,
    @Chk11Value ,
    @Chk12Value ,
    @Chk13Value ,
    @Chk14Value ,
    @Chk15Value ,
    @Chk16Value ,
    @Chk17Value ,
    @Chk18Value ,
    @Chk19Value ,
    @Chk20Value ,
    @AuthForDebit ,
    @DoNotPurge ,
    @ClosedDate ,
    @CommitmentNum ,
    @PurposeCode ,
    @LoanSystem ,
    @FinanceType ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[RealTimeDDAInsert]'
GO

CREATE PROCEDURE [dbo].[RealTimeDDAInsert]
    @Pkey                                         Int = 0 ,
    @Transpkey                                    Int = 0 ,
    @DDANumber                                    varchar(20) = "  " ,
    @ReferenceNum                                 varchar(10) = "  " ,
    @RecType                                      varchar(3) = "  " ,
    @Transtatus                                   Int = 0 ,
    @PartyID                                      varchar(18) = "  " ,
    @Amount                                       money = 0 ,
    @IncDec                                       varchar(1) = "  " ,
    @ValueDate                                    DateTime = 0 ,
    @FXrate                                       Float = 0 ,
    @AuthorizeAmount                              money = 0 ,
    @OverRide                                     varchar(50) = "  " ,
    @Rejectreason                                 varchar(132) = "  " ,
    @Currency                                     varchar(3) = "  " ,
    @ProcessDate                                  DateTime = 0 ,
    @RequestId                                    varchar(35) = "  " ,
    @ErrorCode                                    Int = 0 ,
    @ErrorReasonCode                              varchar(50) = "  " ,
    @ErrorMsgNum                                  varchar(100) = "  " ,
    @ErrorMsgText                                 varchar(500) = "  " ,
    @ErrorMsgField                                varchar(100) = "  " ,
    @OutgoingMsgText                              varchar(MAX) = " " ,
    @ResponseMsgText                              varchar(MAX) = " " 
AS
Insert into RealTimeDDA(
    Transpkey ,
    DDANumber ,
    ReferenceNum ,
    RecType ,
    Transtatus ,
    PartyID ,
    Amount ,
    IncDec ,
    ValueDate ,
    FXrate ,
    AuthorizeAmount ,
    OverRide ,
    Rejectreason ,
    Currency ,
    ProcessDate ,
    RequestId ,
    ErrorCode ,
    ErrorReasonCode ,
    ErrorMsgNum ,
    ErrorMsgText ,
    ErrorMsgField ,
    OutgoingMsgText ,
    ResponseMsgText)
values (
    @Transpkey ,
    @DDANumber ,
    @ReferenceNum ,
    @RecType ,
    @Transtatus ,
    @PartyID ,
    @Amount ,
    @IncDec ,
    @ValueDate ,
    @FXrate ,
    @AuthorizeAmount ,
    @OverRide ,
    @Rejectreason ,
    @Currency ,
    @ProcessDate ,
    @RequestId ,
    @ErrorCode ,
    @ErrorReasonCode ,
    @ErrorMsgNum ,
    @ErrorMsgText ,
    @ErrorMsgField ,
    @OutgoingMsgText ,
    @ResponseMsgText)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimaryupdate]'
GO

CREATE PROCEDURE [dbo].[ScfPrimaryupdate]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @ScfPrimaryStatus                             varchar(6) = " " ,
    @Active                                       Bit = 0 ,
    @GTSAction                                    varchar(6) = " " ,
    @OurRefLegalEntity                            varchar(2) = " " ,
    @OurRefDivisionNum                            varchar(2) = " " ,
    @OurRefDepartmentNum                          varchar(2) = " " ,
    @OurReferenceNum                              varchar(8) = " " ,
    @LetterType                                   varchar(6) = " " ,
    @SellerPkey                                   Int = 0 ,
    @SellerReference                              varchar(25) = " " ,
    @SellerHow                                    varchar(3) = " " ,
    @SellerDDA                                    varchar(20) = " " ,
    @OriginalAmountBase                           money = 0 ,
    @OriginalAmount                               money = 0 ,
    @AmountOutstandingBase                        money = 0 ,
    @AmountOutstanding                            money = 0 ,
    @CurrencyCode                                 varchar(3) = " " ,
    @FXRate                                       Float = 0 ,
    @FXContract                                   varchar(25) = " " ,
    @EntryDate                                    DateTime = 0 ,
    @DocumentDate                                 DateTime = 0 ,
    @DateAccepted                                 DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @TenorDays                                    Int = 0 ,
    @TenorPhrase                                  varchar(50) = " " ,
    @LastTracerVia                                varchar(3) = " " ,
    @LastTracerDate                               DateTime = 0 ,
    @NumberOfTracers                              Int = 0 ,
    @TraceToday                                   Bit = 0 ,
    @BuyerPkey                                    Int = 0 ,
    @BuyerReference                               varchar(25) = " " ,
    @BuyerHow                                     varchar(3) = " " ,
    @BuyerDDA                                     varchar(20) = " " ,
    @CreatingProgram                              varchar(10) = " " ,
    @CollectionType                               varchar(3) = " " ,
    @BankingGroup                                 varchar(10) = " " ,
    @ExpenseCode                                  varchar(10) = " " ,
    @PaidDirect                                   Bit = 0 ,
    @CloseThisCollection                          Bit = 0 ,
    @Chk1Value                                    varchar(1) = " " ,
    @Chk2Value                                    varchar(1) = " " ,
    @Chk3Value                                    varchar(1) = " " ,
    @Chk4Value                                    varchar(1) = " " ,
    @Chk5Value                                    varchar(1) = " " ,
    @Chk6Value                                    varchar(1) = " " ,
    @Chk7Value                                    varchar(1) = " " ,
    @Chk8Value                                    varchar(1) = " " ,
    @Chk9Value                                    varchar(1) = " " ,
    @WaitingClarification                         varchar(1) = " " ,
    @WaitingAuthentication                        varchar(1) = " " ,
    @AmendTraceDays                               Int = 0 ,
    @AlternateAOPkey                              Int = 0 ,
    @AccountOfficerPkey                           Int = 0 ,
    @BLNumber                                     varchar(30) = " " ,
    @ReferencePerfix                              varchar(25) = " " ,
    @ConvertedRefNo                               varchar(25) = " " ,
    @InvoicePONo                                  varchar(35) = " " ,
    @ConvertedSystem                              varchar(10) = " " ,
    @Chk10Value                                   varchar(1) = " " ,
    @Chk11Value                                   varchar(1) = " " ,
    @Chk12Value                                   varchar(1) = " " ,
    @Chk13Value                                   varchar(1) = " " ,
    @Chk14Value                                   varchar(1) = " " ,
    @Chk15Value                                   varchar(1) = " " ,
    @Chk16Value                                   varchar(1) = " " ,
    @Chk17Value                                   varchar(1) = " " ,
    @Chk18Value                                   varchar(1) = " " ,
    @Chk19Value                                   varchar(1) = " " ,
    @Chk20Value                                   varchar(1) = " " ,
    @AuthForDebit                                 varchar(1) = " " ,
    @DoNotPurge                                   Bit = 0 ,
    @ClosedDate                                   DateTime = 0 ,
    @CommitmentNum                                varchar(16) = " " ,
    @PurposeCode                                  varchar(6) = " " ,
    @LoanSystem                                   varchar(20) = " " ,
    @FinanceType                                  varchar(20) = " " ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update ScfPrimary set
    ScfPrimaryPkey = @ScfPrimaryPkey,
    EventPkey = @EventPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    ScfPrimaryStatus = @ScfPrimaryStatus,
    Active = @Active,
    GTSAction = @GTSAction,
    OurRefLegalEntity = @OurRefLegalEntity,
    OurRefDivisionNum = @OurRefDivisionNum,
    OurRefDepartmentNum = @OurRefDepartmentNum,
    OurReferenceNum = @OurReferenceNum,
    LetterType = @LetterType,
    SellerPkey = @SellerPkey,
    SellerReference = @SellerReference,
    SellerHow = @SellerHow,
    SellerDDA = @SellerDDA,
    OriginalAmountBase = @OriginalAmountBase,
    OriginalAmount = @OriginalAmount,
    AmountOutstandingBase = @AmountOutstandingBase,
    AmountOutstanding = @AmountOutstanding,
    CurrencyCode = @CurrencyCode,
    FXRate = @FXRate,
    FXContract = @FXContract,
    EntryDate = @EntryDate,
    DocumentDate = @DocumentDate,
    DateAccepted = @DateAccepted,
    MaturityDate = @MaturityDate,
    TenorDays = @TenorDays,
    TenorPhrase = @TenorPhrase,
    LastTracerVia = @LastTracerVia,
    LastTracerDate = @LastTracerDate,
    NumberOfTracers = @NumberOfTracers,
    TraceToday = @TraceToday,
    BuyerPkey = @BuyerPkey,
    BuyerReference = @BuyerReference,
    BuyerHow = @BuyerHow,
    BuyerDDA = @BuyerDDA,
    CreatingProgram = @CreatingProgram,
    CollectionType = @CollectionType,
    BankingGroup = @BankingGroup,
    ExpenseCode = @ExpenseCode,
    PaidDirect = @PaidDirect,
    CloseThisCollection = @CloseThisCollection,
    Chk1Value = @Chk1Value,
    Chk2Value = @Chk2Value,
    Chk3Value = @Chk3Value,
    Chk4Value = @Chk4Value,
    Chk5Value = @Chk5Value,
    Chk6Value = @Chk6Value,
    Chk7Value = @Chk7Value,
    Chk8Value = @Chk8Value,
    Chk9Value = @Chk9Value,
    WaitingClarification = @WaitingClarification,
    WaitingAuthentication = @WaitingAuthentication,
    AmendTraceDays = @AmendTraceDays,
    AlternateAOPkey = @AlternateAOPkey,
    AccountOfficerPkey = @AccountOfficerPkey,
    BLNumber = @BLNumber,
    ReferencePerfix = @ReferencePerfix,
    ConvertedRefNo = @ConvertedRefNo,
    InvoicePONo = @InvoicePONo,
    ConvertedSystem = @ConvertedSystem,
    Chk10Value = @Chk10Value,
    Chk11Value = @Chk11Value,
    Chk12Value = @Chk12Value,
    Chk13Value = @Chk13Value,
    Chk14Value = @Chk14Value,
    Chk15Value = @Chk15Value,
    Chk16Value = @Chk16Value,
    Chk17Value = @Chk17Value,
    Chk18Value = @Chk18Value,
    Chk19Value = @Chk19Value,
    Chk20Value = @Chk20Value,
    AuthForDebit = @AuthForDebit,
    DoNotPurge = @DoNotPurge,
    ClosedDate = @ClosedDate,
    CommitmentNum = @CommitmentNum,
    PurposeCode = @PurposeCode,
    LoanSystem = @LoanSystem,
    FinanceType = @FinanceType,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[RealTimeDDAupdate]'
GO

CREATE PROCEDURE [dbo].[RealTimeDDAupdate]
    @Pkey                                         Int = 0 ,
    @Transpkey                                    Int = 0 ,
    @DDANumber                                    varchar(20) = " " ,
    @ReferenceNum                                 varchar(10) = " " ,
    @RecType                                      varchar(3) = " " ,
    @Transtatus                                   Int = 0 ,
    @PartyID                                      varchar(18) = " " ,
    @Amount                                       money = 0 ,
    @IncDec                                       varchar(1) = " " ,
    @ValueDate                                    DateTime = 0 ,
    @FXrate                                       Float = 0 ,
    @AuthorizeAmount                              money = 0 ,
    @OverRide                                     varchar(50) = " " ,
    @Rejectreason                                 varchar(132) = " " ,
    @Currency                                     varchar(3) = " " ,
    @ProcessDate                                  DateTime = 0 ,
    @RequestId                                    varchar(35) = " " ,
    @ErrorCode                                    Int = 0 ,
    @ErrorReasonCode                              varchar(50) = " " ,
    @ErrorMsgNum                                  varchar(100) = " " ,
    @ErrorMsgText                                 varchar(500) = " " ,
    @ErrorMsgField                                varchar(100) = " " ,
    @OutgoingMsgText                              varchar(MAX) = " " ,
    @ResponseMsgText                              varchar(MAX) = " " 
AS
Update RealTimeDDA set
    Transpkey = @Transpkey,
    DDANumber = @DDANumber,
    ReferenceNum = @ReferenceNum,
    RecType = @RecType,
    Transtatus = @Transtatus,
    PartyID = @PartyID,
    Amount = @Amount,
    IncDec = @IncDec,
    ValueDate = @ValueDate,
    FXrate = @FXrate,
    AuthorizeAmount = @AuthorizeAmount,
    OverRide = @OverRide,
    Rejectreason = @Rejectreason,
    Currency = @Currency,
    ProcessDate = @ProcessDate,
    RequestId = @RequestId,
    ErrorCode = @ErrorCode,
    ErrorReasonCode = @ErrorReasonCode,
    ErrorMsgNum = @ErrorMsgNum,
    ErrorMsgText = @ErrorMsgText,
    ErrorMsgField = @ErrorMsgField,
    OutgoingMsgText = @OutgoingMsgText,
    ResponseMsgText = @ResponseMsgText
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainScfPrimary]'
GO

CREATE PROCEDURE [dbo].[MainScfPrimary]
            @Pkey                                         Int = 0 ,
            @ScfPrimaryPkey                               Int = 0 ,
            @EventPkey                                    Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @ScfPrimaryStatus                             varchar(6) = "  " ,
            @Active                                       Bit = 0 ,
            @GTSAction                                    varchar(6) = "  " ,
            @OurRefLegalEntity                            varchar(2) = "  " ,
            @OurRefDivisionNum                            varchar(2) = "  " ,
            @OurRefDepartmentNum                          varchar(2) = "  " ,
            @OurReferenceNum                              varchar(8) = "  " ,
            @LetterType                                   varchar(6) = "  " ,
            @SellerPkey                                   Int = 0 ,
            @SellerReference                              varchar(25) = "  " ,
            @SellerHow                                    varchar(3) = "  " ,
            @SellerDDA                                    varchar(20) = "  " ,
            @OriginalAmountBase                           money = 0 ,
            @OriginalAmount                               money = 0 ,
            @AmountOutstandingBase                        money = 0 ,
            @AmountOutstanding                            money = 0 ,
            @CurrencyCode                                 varchar(3) = "  " ,
            @FXRate                                       Float = 0 ,
            @FXContract                                   varchar(25) = "  " ,
            @EntryDate                                    DateTime = 0 ,
            @DocumentDate                                 DateTime = 0 ,
            @DateAccepted                                 DateTime = 0 ,
            @MaturityDate                                 DateTime = 0 ,
            @TenorDays                                    Int = 0 ,
            @TenorPhrase                                  varchar(50) = "  " ,
            @LastTracerVia                                varchar(3) = "  " ,
            @LastTracerDate                               DateTime = 0 ,
            @NumberOfTracers                              Int = 0 ,
            @TraceToday                                   Bit = 0 ,
            @BuyerPkey                                    Int = 0 ,
            @BuyerReference                               varchar(25) = "  " ,
            @BuyerHow                                     varchar(3) = "  " ,
            @BuyerDDA                                     varchar(20) = "  " ,
            @CreatingProgram                              varchar(10) = "  " ,
            @CollectionType                               varchar(3) = "  " ,
            @BankingGroup                                 varchar(10) = "  " ,
            @ExpenseCode                                  varchar(10) = "  " ,
            @PaidDirect                                   Bit = 0 ,
            @CloseThisCollection                          Bit = 0 ,
            @Chk1Value                                    varchar(1) = "  " ,
            @Chk2Value                                    varchar(1) = "  " ,
            @Chk3Value                                    varchar(1) = "  " ,
            @Chk4Value                                    varchar(1) = "  " ,
            @Chk5Value                                    varchar(1) = "  " ,
            @Chk6Value                                    varchar(1) = "  " ,
            @Chk7Value                                    varchar(1) = "  " ,
            @Chk8Value                                    varchar(1) = "  " ,
            @Chk9Value                                    varchar(1) = "  " ,
            @WaitingClarification                         varchar(1) = "  " ,
            @WaitingAuthentication                        varchar(1) = "  " ,
            @AmendTraceDays                               Int = 0 ,
            @AlternateAOPkey                              Int = 0 ,
            @AccountOfficerPkey                           Int = 0 ,
            @BLNumber                                     varchar(30) = "  " ,
            @ReferencePerfix                              varchar(25) = "  " ,
            @ConvertedRefNo                               varchar(25) = "  " ,
            @InvoicePONo                                  varchar(35) = "  " ,
            @ConvertedSystem                              varchar(10) = "  " ,
            @Chk10Value                                   varchar(1) = "  " ,
            @Chk11Value                                   varchar(1) = "  " ,
            @Chk12Value                                   varchar(1) = "  " ,
            @Chk13Value                                   varchar(1) = "  " ,
            @Chk14Value                                   varchar(1) = "  " ,
            @Chk15Value                                   varchar(1) = "  " ,
            @Chk16Value                                   varchar(1) = "  " ,
            @Chk17Value                                   varchar(1) = "  " ,
            @Chk18Value                                   varchar(1) = "  " ,
            @Chk19Value                                   varchar(1) = "  " ,
            @Chk20Value                                   varchar(1) = "  " ,
            @AuthForDebit                                 varchar(1) = "  " ,
            @DoNotPurge                                   Bit = 0 ,
            @ClosedDate                                   DateTime = 0 ,
            @CommitmentNum                                varchar(16) = "  " ,
            @PurposeCode                                  varchar(6) = "  " ,
            @LoanSystem                                   varchar(20) = "  " ,
            @FinanceType                                  varchar(20) = "  " ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from ScfPrimary with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = ScfPrimaryinsert
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @ScfPrimaryStatus                              ,
        @Active                                        ,
        @GTSAction                                     ,
        @OurRefLegalEntity                             ,
        @OurRefDivisionNum                             ,
        @OurRefDepartmentNum                           ,
        @OurReferenceNum                               ,
        @LetterType                                    ,
        @SellerPkey                                    ,
        @SellerReference                               ,
        @SellerHow                                     ,
        @SellerDDA                                     ,
        @OriginalAmountBase                            ,
        @OriginalAmount                                ,
        @AmountOutstandingBase                         ,
        @AmountOutstanding                             ,
        @CurrencyCode                                  ,
        @FXRate                                        ,
        @FXContract                                    ,
        @EntryDate                                     ,
        @DocumentDate                                  ,
        @DateAccepted                                  ,
        @MaturityDate                                  ,
        @TenorDays                                     ,
        @TenorPhrase                                   ,
        @LastTracerVia                                 ,
        @LastTracerDate                                ,
        @NumberOfTracers                               ,
        @TraceToday                                    ,
        @BuyerPkey                                     ,
        @BuyerReference                                ,
        @BuyerHow                                      ,
        @BuyerDDA                                      ,
        @CreatingProgram                               ,
        @CollectionType                                ,
        @BankingGroup                                  ,
        @ExpenseCode                                   ,
        @PaidDirect                                    ,
        @CloseThisCollection                           ,
        @Chk1Value                                     ,
        @Chk2Value                                     ,
        @Chk3Value                                     ,
        @Chk4Value                                     ,
        @Chk5Value                                     ,
        @Chk6Value                                     ,
        @Chk7Value                                     ,
        @Chk8Value                                     ,
        @Chk9Value                                     ,
        @WaitingClarification                          ,
        @WaitingAuthentication                         ,
        @AmendTraceDays                                ,
        @AlternateAOPkey                               ,
        @AccountOfficerPkey                            ,
        @BLNumber                                      ,
        @ReferencePerfix                               ,
        @ConvertedRefNo                                ,
        @InvoicePONo                                   ,
        @ConvertedSystem                               ,
        @Chk10Value                                    ,
        @Chk11Value                                    ,
        @Chk12Value                                    ,
        @Chk13Value                                    ,
        @Chk14Value                                    ,
        @Chk15Value                                    ,
        @Chk16Value                                    ,
        @Chk17Value                                    ,
        @Chk18Value                                    ,
        @Chk19Value                                    ,
        @Chk20Value                                    ,
        @AuthForDebit                                  ,
        @DoNotPurge                                    ,
        @ClosedDate                                    ,
        @CommitmentNum                                 ,
        @PurposeCode                                   ,
        @LoanSystem                                    ,
        @FinanceType                                   ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = ScfPrimaryupdate
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @ScfPrimaryStatus                              ,
        @Active                                        ,
        @GTSAction                                     ,
        @OurRefLegalEntity                             ,
        @OurRefDivisionNum                             ,
        @OurRefDepartmentNum                           ,
        @OurReferenceNum                               ,
        @LetterType                                    ,
        @SellerPkey                                    ,
        @SellerReference                               ,
        @SellerHow                                     ,
        @SellerDDA                                     ,
        @OriginalAmountBase                            ,
        @OriginalAmount                                ,
        @AmountOutstandingBase                         ,
        @AmountOutstanding                             ,
        @CurrencyCode                                  ,
        @FXRate                                        ,
        @FXContract                                    ,
        @EntryDate                                     ,
        @DocumentDate                                  ,
        @DateAccepted                                  ,
        @MaturityDate                                  ,
        @TenorDays                                     ,
        @TenorPhrase                                   ,
        @LastTracerVia                                 ,
        @LastTracerDate                                ,
        @NumberOfTracers                               ,
        @TraceToday                                    ,
        @BuyerPkey                                     ,
        @BuyerReference                                ,
        @BuyerHow                                      ,
        @BuyerDDA                                      ,
        @CreatingProgram                               ,
        @CollectionType                                ,
        @BankingGroup                                  ,
        @ExpenseCode                                   ,
        @PaidDirect                                    ,
        @CloseThisCollection                           ,
        @Chk1Value                                     ,
        @Chk2Value                                     ,
        @Chk3Value                                     ,
        @Chk4Value                                     ,
        @Chk5Value                                     ,
        @Chk6Value                                     ,
        @Chk7Value                                     ,
        @Chk8Value                                     ,
        @Chk9Value                                     ,
        @WaitingClarification                          ,
        @WaitingAuthentication                         ,
        @AmendTraceDays                                ,
        @AlternateAOPkey                               ,
        @AccountOfficerPkey                            ,
        @BLNumber                                      ,
        @ReferencePerfix                               ,
        @ConvertedRefNo                                ,
        @InvoicePONo                                   ,
        @ConvertedSystem                               ,
        @Chk10Value                                    ,
        @Chk11Value                                    ,
        @Chk12Value                                    ,
        @Chk13Value                                    ,
        @Chk14Value                                    ,
        @Chk15Value                                    ,
        @Chk16Value                                    ,
        @Chk17Value                                    ,
        @Chk18Value                                    ,
        @Chk19Value                                    ,
        @Chk20Value                                    ,
        @AuthForDebit                                  ,
        @DoNotPurge                                    ,
        @ClosedDate                                    ,
        @CommitmentNum                                 ,
        @PurposeCode                                   ,
        @LoanSystem                                    ,
        @FinanceType                                   ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainRealTimeDDA]'
GO

CREATE PROCEDURE [dbo].[MainRealTimeDDA]
            @Pkey                                         Int = 0 ,
            @Transpkey                                    Int = 0 ,
            @DDANumber                                    varchar(20) = "  " ,
            @ReferenceNum                                 varchar(10) = "  " ,
            @RecType                                      varchar(3) = "  " ,
            @Transtatus                                   Int = 0 ,
            @PartyID                                      varchar(18) = "  " ,
            @Amount                                       money = 0 ,
            @IncDec                                       varchar(1) = "  " ,
            @ValueDate                                    DateTime = 0 ,
            @FXrate                                       Float = 0 ,
            @AuthorizeAmount                              money = 0 ,
            @OverRide                                     varchar(50) = "  " ,
            @Rejectreason                                 varchar(132) = "  " ,
            @Currency                                     varchar(3) = "  " ,
            @ProcessDate                                  DateTime = 0 ,
            @RequestId                                    varchar(35) = "  " ,
            @ErrorCode                                    Int = 0 ,
            @ErrorReasonCode                              varchar(50) = "  " ,
            @ErrorMsgNum                                  varchar(100) = "  " ,
            @ErrorMsgText                                 varchar(500) = "  " ,
            @ErrorMsgField                                varchar(100) = "  " ,
            @OutgoingMsgText                              varchar(MAX) = " " ,
            @ResponseMsgText                              varchar(MAX) = " " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from RealTimeDDA with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = RealTimeDDAinsert
        @Pkey                                          ,
        @Transpkey                                     ,
        @DDANumber                                     ,
        @ReferenceNum                                  ,
        @RecType                                       ,
        @Transtatus                                    ,
        @PartyID                                       ,
        @Amount                                        ,
        @IncDec                                        ,
        @ValueDate                                     ,
        @FXrate                                        ,
        @AuthorizeAmount                               ,
        @OverRide                                      ,
        @Rejectreason                                  ,
        @Currency                                      ,
        @ProcessDate                                   ,
        @RequestId                                     ,
        @ErrorCode                                     ,
        @ErrorReasonCode                               ,
        @ErrorMsgNum                                   ,
        @ErrorMsgText                                  ,
        @ErrorMsgField                                 ,
        @OutgoingMsgText                               ,
        @ResponseMsgText                              

    End

    
    Else
    Begin
        Exec @lpkey = RealTimeDDAupdate
        @Pkey                                          ,
        @Transpkey                                     ,
        @DDANumber                                     ,
        @ReferenceNum                                  ,
        @RecType                                       ,
        @Transtatus                                    ,
        @PartyID                                       ,
        @Amount                                        ,
        @IncDec                                        ,
        @ValueDate                                     ,
        @FXrate                                        ,
        @AuthorizeAmount                               ,
        @OverRide                                      ,
        @Rejectreason                                  ,
        @Currency                                      ,
        @ProcessDate                                   ,
        @RequestId                                     ,
        @ErrorCode                                     ,
        @ErrorReasonCode                               ,
        @ErrorMsgNum                                   ,
        @ErrorMsgText                                  ,
        @ErrorMsgField                                 ,
        @OutgoingMsgText                               ,
        @ResponseMsgText                              
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimaryIssRel]'
GO

CREATE PROCEDURE [dbo].[ScfPrimaryIssRel]
    @OldPrimaryPkey    int

AS

            Insert into BalScfPrimary Select
            Pkey, 
            ScfPrimaryPkey, 
            EventPkey, 
            TransPkey, 
            ReplacePkey, 
            ScfPrimaryStatus, 
            Active, 
            GTSAction, 
            OurRefLegalEntity, 
            OurRefDivisionNum, 
            OurRefDepartmentNum, 
            OurReferenceNum, 
            LetterType, 
            SellerPkey, 
            SellerReference, 
            SellerHow, 
            SellerDDA, 
            OriginalAmountBase, 
            OriginalAmount, 
            AmountOutstandingBase, 
            AmountOutstanding, 
            CurrencyCode, 
            FXRate, 
            FXContract, 
            EntryDate, 
            DocumentDate, 
            DateAccepted, 
            MaturityDate, 
            TenorDays, 
            TenorPhrase, 
            LastTracerVia, 
            LastTracerDate, 
            NumberOfTracers, 
            TraceToday, 
            BuyerPkey, 
            BuyerReference, 
            BuyerHow, 
            BuyerDDA, 
            CreatingProgram, 
            CollectionType, 
            BankingGroup, 
            ExpenseCode, 
            PaidDirect, 
            CloseThisCollection, 
            Chk1Value, 
            Chk2Value, 
            Chk3Value, 
            Chk4Value, 
            Chk5Value, 
            Chk6Value, 
            Chk7Value, 
            Chk8Value, 
            Chk9Value, 
            WaitingClarification, 
            WaitingAuthentication, 
            AmendTraceDays, 
            AlternateAOPkey, 
            AccountOfficerPkey, 
            BLNumber, 
            ReferencePerfix, 
            ConvertedRefNo, 
            InvoicePONo, 
            ConvertedSystem, 
            Chk10Value, 
            Chk11Value, 
            Chk12Value, 
            Chk13Value, 
            Chk14Value, 
            Chk15Value, 
            Chk16Value, 
            Chk17Value, 
            Chk18Value, 
            Chk19Value, 
            Chk20Value, 
            AuthForDebit, 
            DoNotPurge, 
            ClosedDate, 
            CommitmentNum, 
            PurposeCode, 
            LoanSystem, 
            FinanceType, 
            UPDATABASE 
            from ScfPrimary where @oldprimarypkey = SCFPRIMARYPKEY
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[RealTimeDDAReadByPkey]'
GO

CREATE PROCEDURE [dbo].[RealTimeDDAReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from RealTimeDDA where pkey = @pkey
            select @rPkey = Pkey from RealTimeDDA where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimaryMove]'
GO

CREATE PROCEDURE [dbo].[ScfPrimaryMove]
    @LocPkey    int,
    @TPkey    int

AS

    Declare
    @Pkey                                         Int, 
    @ScfPrimaryPkey                               Int, 
    @EventPkey                                    Int, 
    @TransPkey                                    Int, 
    @ReplacePkey                                  Int, 
    @ScfPrimaryStatus                             varchar(6), 
    @Active                                       Bit, 
    @GTSAction                                    varchar(6), 
    @OurRefLegalEntity                            varchar(2), 
    @OurRefDivisionNum                            varchar(2), 
    @OurRefDepartmentNum                          varchar(2), 
    @OurReferenceNum                              varchar(8), 
    @LetterType                                   varchar(6), 
    @SellerPkey                                   Int, 
    @SellerReference                              varchar(25), 
    @SellerHow                                    varchar(3), 
    @SellerDDA                                    varchar(20), 
    @OriginalAmountBase                           money, 
    @OriginalAmount                               money, 
    @AmountOutstandingBase                        money, 
    @AmountOutstanding                            money, 
    @CurrencyCode                                 varchar(3), 
    @FXRate                                       Float, 
    @FXContract                                   varchar(25), 
    @EntryDate                                    DateTime, 
    @DocumentDate                                 DateTime, 
    @DateAccepted                                 DateTime, 
    @MaturityDate                                 DateTime, 
    @TenorDays                                    Int, 
    @TenorPhrase                                  varchar(50), 
    @LastTracerVia                                varchar(3), 
    @LastTracerDate                               DateTime, 
    @NumberOfTracers                              Int, 
    @TraceToday                                   Bit, 
    @BuyerPkey                                    Int, 
    @BuyerReference                               varchar(25), 
    @BuyerHow                                     varchar(3), 
    @BuyerDDA                                     varchar(20), 
    @CreatingProgram                              varchar(10), 
    @CollectionType                               varchar(3), 
    @BankingGroup                                 varchar(10), 
    @ExpenseCode                                  varchar(10), 
    @PaidDirect                                   Bit, 
    @CloseThisCollection                          Bit, 
    @Chk1Value                                    varchar(1), 
    @Chk2Value                                    varchar(1), 
    @Chk3Value                                    varchar(1), 
    @Chk4Value                                    varchar(1), 
    @Chk5Value                                    varchar(1), 
    @Chk6Value                                    varchar(1), 
    @Chk7Value                                    varchar(1), 
    @Chk8Value                                    varchar(1), 
    @Chk9Value                                    varchar(1), 
    @WaitingClarification                         varchar(1), 
    @WaitingAuthentication                        varchar(1), 
    @AmendTraceDays                               Int, 
    @AlternateAOPkey                              Int, 
    @AccountOfficerPkey                           Int, 
    @BLNumber                                     varchar(30), 
    @ReferencePerfix                              varchar(25), 
    @ConvertedRefNo                               varchar(25), 
    @InvoicePONo                                  varchar(35), 
    @ConvertedSystem                              varchar(10), 
    @Chk10Value                                   varchar(1), 
    @Chk11Value                                   varchar(1), 
    @Chk12Value                                   varchar(1), 
    @Chk13Value                                   varchar(1), 
    @Chk14Value                                   varchar(1), 
    @Chk15Value                                   varchar(1), 
    @Chk16Value                                   varchar(1), 
    @Chk17Value                                   varchar(1), 
    @Chk18Value                                   varchar(1), 
    @Chk19Value                                   varchar(1), 
    @Chk20Value                                   varchar(1), 
    @AuthForDebit                                 varchar(1), 
    @DoNotPurge                                   Bit, 
    @ClosedDate                                   DateTime, 
    @CommitmentNum                                varchar(16), 
    @PurposeCode                                  varchar(6), 
    @LoanSystem                                   varchar(20), 
    @FinanceType                                  varchar(20), 
    @UPDATABASE                                   varchar(1) 
    declare @done as int
    select @done = -1

    Declare ScfPrimary Cursor for select * from ScfPrimary
         Where @tpkey = Transpkey
    Open ScfPrimary

    while @done = -1
    Begin
        fetch next from ScfPrimary Into 
        @Pkey ,
        @ScfPrimaryPkey ,
        @EventPkey ,
        @TransPkey ,
        @ReplacePkey ,
        @ScfPrimaryStatus ,
        @Active ,
        @GTSAction ,
        @OurRefLegalEntity ,
        @OurRefDivisionNum ,
        @OurRefDepartmentNum ,
        @OurReferenceNum ,
        @LetterType ,
        @SellerPkey ,
        @SellerReference ,
        @SellerHow ,
        @SellerDDA ,
        @OriginalAmountBase ,
        @OriginalAmount ,
        @AmountOutstandingBase ,
        @AmountOutstanding ,
        @CurrencyCode ,
        @FXRate ,
        @FXContract ,
        @EntryDate ,
        @DocumentDate ,
        @DateAccepted ,
        @MaturityDate ,
        @TenorDays ,
        @TenorPhrase ,
        @LastTracerVia ,
        @LastTracerDate ,
        @NumberOfTracers ,
        @TraceToday ,
        @BuyerPkey ,
        @BuyerReference ,
        @BuyerHow ,
        @BuyerDDA ,
        @CreatingProgram ,
        @CollectionType ,
        @BankingGroup ,
        @ExpenseCode ,
        @PaidDirect ,
        @CloseThisCollection ,
        @Chk1Value ,
        @Chk2Value ,
        @Chk3Value ,
        @Chk4Value ,
        @Chk5Value ,
        @Chk6Value ,
        @Chk7Value ,
        @Chk8Value ,
        @Chk9Value ,
        @WaitingClarification ,
        @WaitingAuthentication ,
        @AmendTraceDays ,
        @AlternateAOPkey ,
        @AccountOfficerPkey ,
        @BLNumber ,
        @ReferencePerfix ,
        @ConvertedRefNo ,
        @InvoicePONo ,
        @ConvertedSystem ,
        @Chk10Value ,
        @Chk11Value ,
        @Chk12Value ,
        @Chk13Value ,
        @Chk14Value ,
        @Chk15Value ,
        @Chk16Value ,
        @Chk17Value ,
        @Chk18Value ,
        @Chk19Value ,
        @Chk20Value ,
        @AuthForDebit ,
        @DoNotPurge ,
        @ClosedDate ,
        @CommitmentNum ,
        @PurposeCode ,
        @LoanSystem ,
        @FinanceType ,
        @UPDATABASE

        If @@fetch_status = 0
        Begin
            if @GTSaction = 'ADD' 
                Begin
                    Insert into BalScfPrimary(
                        Pkey ,
                        ScfPrimaryPkey ,
                        EventPkey ,
                        TransPkey ,
                        ReplacePkey ,
                        ScfPrimaryStatus ,
                        Active ,
                        GTSAction ,
                        OurRefLegalEntity ,
                        OurRefDivisionNum ,
                        OurRefDepartmentNum ,
                        OurReferenceNum ,
                        LetterType ,
                        SellerPkey ,
                        SellerReference ,
                        SellerHow ,
                        SellerDDA ,
                        OriginalAmountBase ,
                        OriginalAmount ,
                        AmountOutstandingBase ,
                        AmountOutstanding ,
                        CurrencyCode ,
                        FXRate ,
                        FXContract ,
                        EntryDate ,
                        DocumentDate ,
                        DateAccepted ,
                        MaturityDate ,
                        TenorDays ,
                        TenorPhrase ,
                        LastTracerVia ,
                        LastTracerDate ,
                        NumberOfTracers ,
                        TraceToday ,
                        BuyerPkey ,
                        BuyerReference ,
                        BuyerHow ,
                        BuyerDDA ,
                        CreatingProgram ,
                        CollectionType ,
                        BankingGroup ,
                        ExpenseCode ,
                        PaidDirect ,
                        CloseThisCollection ,
                        Chk1Value ,
                        Chk2Value ,
                        Chk3Value ,
                        Chk4Value ,
                        Chk5Value ,
                        Chk6Value ,
                        Chk7Value ,
                        Chk8Value ,
                        Chk9Value ,
                        WaitingClarification ,
                        WaitingAuthentication ,
                        AmendTraceDays ,
                        AlternateAOPkey ,
                        AccountOfficerPkey ,
                        BLNumber ,
                        ReferencePerfix ,
                        ConvertedRefNo ,
                        InvoicePONo ,
                        ConvertedSystem ,
                        Chk10Value ,
                        Chk11Value ,
                        Chk12Value ,
                        Chk13Value ,
                        Chk14Value ,
                        Chk15Value ,
                        Chk16Value ,
                        Chk17Value ,
                        Chk18Value ,
                        Chk19Value ,
                        Chk20Value ,
                        AuthForDebit ,
                        DoNotPurge ,
                        ClosedDate ,
                        CommitmentNum ,
                        PurposeCode ,
                        LoanSystem ,
                        FinanceType ,
                        UPDATABASE)
values (
                        @Pkey ,
                        @ScfPrimaryPkey ,
                        @EventPkey ,
                        @TransPkey ,
                        @ReplacePkey ,
                        @ScfPrimaryStatus ,
                        @Active ,
                        @GTSAction ,
                        @OurRefLegalEntity ,
                        @OurRefDivisionNum ,
                        @OurRefDepartmentNum ,
                        @OurReferenceNum ,
                        @LetterType ,
                        @SellerPkey ,
                        @SellerReference ,
                        @SellerHow ,
                        @SellerDDA ,
                        @OriginalAmountBase ,
                        @OriginalAmount ,
                        @AmountOutstandingBase ,
                        @AmountOutstanding ,
                        @CurrencyCode ,
                        @FXRate ,
                        @FXContract ,
                        @EntryDate ,
                        @DocumentDate ,
                        @DateAccepted ,
                        @MaturityDate ,
                        @TenorDays ,
                        @TenorPhrase ,
                        @LastTracerVia ,
                        @LastTracerDate ,
                        @NumberOfTracers ,
                        @TraceToday ,
                        @BuyerPkey ,
                        @BuyerReference ,
                        @BuyerHow ,
                        @BuyerDDA ,
                        @CreatingProgram ,
                        @CollectionType ,
                        @BankingGroup ,
                        @ExpenseCode ,
                        @PaidDirect ,
                        @CloseThisCollection ,
                        @Chk1Value ,
                        @Chk2Value ,
                        @Chk3Value ,
                        @Chk4Value ,
                        @Chk5Value ,
                        @Chk6Value ,
                        @Chk7Value ,
                        @Chk8Value ,
                        @Chk9Value ,
                        @WaitingClarification ,
                        @WaitingAuthentication ,
                        @AmendTraceDays ,
                        @AlternateAOPkey ,
                        @AccountOfficerPkey ,
                        @BLNumber ,
                        @ReferencePerfix ,
                        @ConvertedRefNo ,
                        @InvoicePONo ,
                        @ConvertedSystem ,
                        @Chk10Value ,
                        @Chk11Value ,
                        @Chk12Value ,
                        @Chk13Value ,
                        @Chk14Value ,
                        @Chk15Value ,
                        @Chk16Value ,
                        @Chk17Value ,
                        @Chk18Value ,
                        @Chk19Value ,
                        @Chk20Value ,
                        @AuthForDebit ,
                        @DoNotPurge ,
                        @ClosedDate ,
                        @CommitmentNum ,
                        @PurposeCode ,
                        @LoanSystem ,
                        @FinanceType ,
                        @UPDATABASE)

                END

            IF @GTSACTION = 'AMEND'
                BEGIN
                    update  BalScfPrimary set 
                        ScfPrimaryPkey = @ScfPrimaryPkey, 
                        EventPkey = @EventPkey, 
                        TransPkey = @TransPkey, 
                        ReplacePkey = @ReplacePkey, 
                        ScfPrimaryStatus = @ScfPrimaryStatus, 
                        Active = @Active, 
                        GTSAction = @GTSAction, 
                        OurRefLegalEntity = @OurRefLegalEntity, 
                        OurRefDivisionNum = @OurRefDivisionNum, 
                        OurRefDepartmentNum = @OurRefDepartmentNum, 
                        OurReferenceNum = @OurReferenceNum, 
                        LetterType = @LetterType, 
                        SellerPkey = @SellerPkey, 
                        SellerReference = @SellerReference, 
                        SellerHow = @SellerHow, 
                        SellerDDA = @SellerDDA, 
                        OriginalAmountBase = @OriginalAmountBase, 
                        OriginalAmount = @OriginalAmount, 
                        AmountOutstandingBase = @AmountOutstandingBase, 
                        AmountOutstanding = @AmountOutstanding, 
                        CurrencyCode = @CurrencyCode, 
                        FXRate = @FXRate, 
                        FXContract = @FXContract, 
                        EntryDate = @EntryDate, 
                        DocumentDate = @DocumentDate, 
                        DateAccepted = @DateAccepted, 
                        MaturityDate = @MaturityDate, 
                        TenorDays = @TenorDays, 
                        TenorPhrase = @TenorPhrase, 
                        LastTracerVia = @LastTracerVia, 
                        LastTracerDate = @LastTracerDate, 
                        NumberOfTracers = @NumberOfTracers, 
                        TraceToday = @TraceToday, 
                        BuyerPkey = @BuyerPkey, 
                        BuyerReference = @BuyerReference, 
                        BuyerHow = @BuyerHow, 
                        BuyerDDA = @BuyerDDA, 
                        CreatingProgram = @CreatingProgram, 
                        CollectionType = @CollectionType, 
                        BankingGroup = @BankingGroup, 
                        ExpenseCode = @ExpenseCode, 
                        PaidDirect = @PaidDirect, 
                        CloseThisCollection = @CloseThisCollection, 
                        Chk1Value = @Chk1Value, 
                        Chk2Value = @Chk2Value, 
                        Chk3Value = @Chk3Value, 
                        Chk4Value = @Chk4Value, 
                        Chk5Value = @Chk5Value, 
                        Chk6Value = @Chk6Value, 
                        Chk7Value = @Chk7Value, 
                        Chk8Value = @Chk8Value, 
                        Chk9Value = @Chk9Value, 
                        WaitingClarification = @WaitingClarification, 
                        WaitingAuthentication = @WaitingAuthentication, 
                        AmendTraceDays = @AmendTraceDays, 
                        AlternateAOPkey = @AlternateAOPkey, 
                        AccountOfficerPkey = @AccountOfficerPkey, 
                        BLNumber = @BLNumber, 
                        ReferencePerfix = @ReferencePerfix, 
                        ConvertedRefNo = @ConvertedRefNo, 
                        InvoicePONo = @InvoicePONo, 
                        ConvertedSystem = @ConvertedSystem, 
                        Chk10Value = @Chk10Value, 
                        Chk11Value = @Chk11Value, 
                        Chk12Value = @Chk12Value, 
                        Chk13Value = @Chk13Value, 
                        Chk14Value = @Chk14Value, 
                        Chk15Value = @Chk15Value, 
                        Chk16Value = @Chk16Value, 
                        Chk17Value = @Chk17Value, 
                        Chk18Value = @Chk18Value, 
                        Chk19Value = @Chk19Value, 
                        Chk20Value = @Chk20Value, 
                        AuthForDebit = @AuthForDebit, 
                        DoNotPurge = @DoNotPurge, 
                        ClosedDate = @ClosedDate, 
                        CommitmentNum = @CommitmentNum, 
                        PurposeCode = @PurposeCode, 
                        LoanSystem = @LoanSystem, 
                        FinanceType = @FinanceType, 
                        UPDATABASE = @UPDATABASE 
                            where pkey = @Replacepkey
                End

            if @GTSaction = 'DELETE' 
                Begin
                    Delete From BalScfPrimary where pkey = @Replacepkey

                END

            End

            if @@fetch_status <> 0 select @done = 0

    end
    close ScfPrimary
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfPrimaryReadByPkey]'
GO

CREATE PROCEDURE [dbo].[ScfPrimaryReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from ScfPrimary where pkey = @pkey
            select @rPkey = Pkey from ScfPrimary where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalScfPrimaryInsert]'
GO

CREATE PROCEDURE [dbo].[BalScfPrimaryInsert]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @ScfPrimaryStatus                             varchar(6) = "  " ,
    @Active                                       Bit = 0 ,
    @GTSAction                                    varchar(6) = "  " ,
    @OurRefLegalEntity                            varchar(2) = "  " ,
    @OurRefDivisionNum                            varchar(2) = "  " ,
    @OurRefDepartmentNum                          varchar(2) = "  " ,
    @OurReferenceNum                              varchar(8) = "  " ,
    @LetterType                                   varchar(6) = "  " ,
    @SellerPkey                                   Int = 0 ,
    @SellerReference                              varchar(25) = "  " ,
    @SellerHow                                    varchar(3) = "  " ,
    @SellerDDA                                    varchar(20) = "  " ,
    @OriginalAmountBase                           money = 0 ,
    @OriginalAmount                               money = 0 ,
    @AmountOutstandingBase                        money = 0 ,
    @AmountOutstanding                            money = 0 ,
    @CurrencyCode                                 varchar(3) = "  " ,
    @FXRate                                       Float = 0 ,
    @FXContract                                   varchar(25) = "  " ,
    @EntryDate                                    DateTime = 0 ,
    @DocumentDate                                 DateTime = 0 ,
    @DateAccepted                                 DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @TenorDays                                    Int = 0 ,
    @TenorPhrase                                  varchar(50) = "  " ,
    @LastTracerVia                                varchar(3) = "  " ,
    @LastTracerDate                               DateTime = 0 ,
    @NumberOfTracers                              Int = 0 ,
    @TraceToday                                   Bit = 0 ,
    @BuyerPkey                                    Int = 0 ,
    @BuyerReference                               varchar(25) = "  " ,
    @BuyerHow                                     varchar(3) = "  " ,
    @BuyerDDA                                     varchar(20) = "  " ,
    @CreatingProgram                              varchar(10) = "  " ,
    @CollectionType                               varchar(3) = "  " ,
    @BankingGroup                                 varchar(10) = "  " ,
    @ExpenseCode                                  varchar(10) = "  " ,
    @PaidDirect                                   Bit = 0 ,
    @CloseThisCollection                          Bit = 0 ,
    @Chk1Value                                    varchar(1) = "  " ,
    @Chk2Value                                    varchar(1) = "  " ,
    @Chk3Value                                    varchar(1) = "  " ,
    @Chk4Value                                    varchar(1) = "  " ,
    @Chk5Value                                    varchar(1) = "  " ,
    @Chk6Value                                    varchar(1) = "  " ,
    @Chk7Value                                    varchar(1) = "  " ,
    @Chk8Value                                    varchar(1) = "  " ,
    @Chk9Value                                    varchar(1) = "  " ,
    @WaitingClarification                         varchar(1) = "  " ,
    @WaitingAuthentication                        varchar(1) = "  " ,
    @AmendTraceDays                               Int = 0 ,
    @AlternateAOPkey                              Int = 0 ,
    @AccountOfficerPkey                           Int = 0 ,
    @BLNumber                                     varchar(30) = "  " ,
    @ReferencePerfix                              varchar(25) = "  " ,
    @ConvertedRefNo                               varchar(25) = "  " ,
    @InvoicePONo                                  varchar(35) = "  " ,
    @ConvertedSystem                              varchar(10) = "  " ,
    @Chk10Value                                   varchar(1) = "  " ,
    @Chk11Value                                   varchar(1) = "  " ,
    @Chk12Value                                   varchar(1) = "  " ,
    @Chk13Value                                   varchar(1) = "  " ,
    @Chk14Value                                   varchar(1) = "  " ,
    @Chk15Value                                   varchar(1) = "  " ,
    @Chk16Value                                   varchar(1) = "  " ,
    @Chk17Value                                   varchar(1) = "  " ,
    @Chk18Value                                   varchar(1) = "  " ,
    @Chk19Value                                   varchar(1) = "  " ,
    @Chk20Value                                   varchar(1) = "  " ,
    @AuthForDebit                                 varchar(1) = "  " ,
    @DoNotPurge                                   Bit = 0 ,
    @ClosedDate                                   DateTime = 0 ,
    @CommitmentNum                                varchar(16) = "  " ,
    @PurposeCode                                  varchar(6) = "  " ,
    @LoanSystem                                   varchar(20) = "  " ,
    @FinanceType                                  varchar(20) = "  " ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into BalScfPrimary(
    Pkey ,
    ScfPrimaryPkey ,
    EventPkey ,
    TransPkey ,
    ReplacePkey ,
    ScfPrimaryStatus ,
    Active ,
    GTSAction ,
    OurRefLegalEntity ,
    OurRefDivisionNum ,
    OurRefDepartmentNum ,
    OurReferenceNum ,
    LetterType ,
    SellerPkey ,
    SellerReference ,
    SellerHow ,
    SellerDDA ,
    OriginalAmountBase ,
    OriginalAmount ,
    AmountOutstandingBase ,
    AmountOutstanding ,
    CurrencyCode ,
    FXRate ,
    FXContract ,
    EntryDate ,
    DocumentDate ,
    DateAccepted ,
    MaturityDate ,
    TenorDays ,
    TenorPhrase ,
    LastTracerVia ,
    LastTracerDate ,
    NumberOfTracers ,
    TraceToday ,
    BuyerPkey ,
    BuyerReference ,
    BuyerHow ,
    BuyerDDA ,
    CreatingProgram ,
    CollectionType ,
    BankingGroup ,
    ExpenseCode ,
    PaidDirect ,
    CloseThisCollection ,
    Chk1Value ,
    Chk2Value ,
    Chk3Value ,
    Chk4Value ,
    Chk5Value ,
    Chk6Value ,
    Chk7Value ,
    Chk8Value ,
    Chk9Value ,
    WaitingClarification ,
    WaitingAuthentication ,
    AmendTraceDays ,
    AlternateAOPkey ,
    AccountOfficerPkey ,
    BLNumber ,
    ReferencePerfix ,
    ConvertedRefNo ,
    InvoicePONo ,
    ConvertedSystem ,
    Chk10Value ,
    Chk11Value ,
    Chk12Value ,
    Chk13Value ,
    Chk14Value ,
    Chk15Value ,
    Chk16Value ,
    Chk17Value ,
    Chk18Value ,
    Chk19Value ,
    Chk20Value ,
    AuthForDebit ,
    DoNotPurge ,
    ClosedDate ,
    CommitmentNum ,
    PurposeCode ,
    LoanSystem ,
    FinanceType ,
    UPDATABASE)
values (
    @Pkey ,
    @ScfPrimaryPkey ,
    @EventPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @ScfPrimaryStatus ,
    @Active ,
    @GTSAction ,
    @OurRefLegalEntity ,
    @OurRefDivisionNum ,
    @OurRefDepartmentNum ,
    @OurReferenceNum ,
    @LetterType ,
    @SellerPkey ,
    @SellerReference ,
    @SellerHow ,
    @SellerDDA ,
    @OriginalAmountBase ,
    @OriginalAmount ,
    @AmountOutstandingBase ,
    @AmountOutstanding ,
    @CurrencyCode ,
    @FXRate ,
    @FXContract ,
    @EntryDate ,
    @DocumentDate ,
    @DateAccepted ,
    @MaturityDate ,
    @TenorDays ,
    @TenorPhrase ,
    @LastTracerVia ,
    @LastTracerDate ,
    @NumberOfTracers ,
    @TraceToday ,
    @BuyerPkey ,
    @BuyerReference ,
    @BuyerHow ,
    @BuyerDDA ,
    @CreatingProgram ,
    @CollectionType ,
    @BankingGroup ,
    @ExpenseCode ,
    @PaidDirect ,
    @CloseThisCollection ,
    @Chk1Value ,
    @Chk2Value ,
    @Chk3Value ,
    @Chk4Value ,
    @Chk5Value ,
    @Chk6Value ,
    @Chk7Value ,
    @Chk8Value ,
    @Chk9Value ,
    @WaitingClarification ,
    @WaitingAuthentication ,
    @AmendTraceDays ,
    @AlternateAOPkey ,
    @AccountOfficerPkey ,
    @BLNumber ,
    @ReferencePerfix ,
    @ConvertedRefNo ,
    @InvoicePONo ,
    @ConvertedSystem ,
    @Chk10Value ,
    @Chk11Value ,
    @Chk12Value ,
    @Chk13Value ,
    @Chk14Value ,
    @Chk15Value ,
    @Chk16Value ,
    @Chk17Value ,
    @Chk18Value ,
    @Chk19Value ,
    @Chk20Value ,
    @AuthForDebit ,
    @DoNotPurge ,
    @ClosedDate ,
    @CommitmentNum ,
    @PurposeCode ,
    @LoanSystem ,
    @FinanceType ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalScfPrimaryupdate]'
GO

CREATE PROCEDURE [dbo].[BalScfPrimaryupdate]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @ScfPrimaryStatus                             varchar(6) = " " ,
    @Active                                       Bit = 0 ,
    @GTSAction                                    varchar(6) = " " ,
    @OurRefLegalEntity                            varchar(2) = " " ,
    @OurRefDivisionNum                            varchar(2) = " " ,
    @OurRefDepartmentNum                          varchar(2) = " " ,
    @OurReferenceNum                              varchar(8) = " " ,
    @LetterType                                   varchar(6) = " " ,
    @SellerPkey                                   Int = 0 ,
    @SellerReference                              varchar(25) = " " ,
    @SellerHow                                    varchar(3) = " " ,
    @SellerDDA                                    varchar(20) = " " ,
    @OriginalAmountBase                           money = 0 ,
    @OriginalAmount                               money = 0 ,
    @AmountOutstandingBase                        money = 0 ,
    @AmountOutstanding                            money = 0 ,
    @CurrencyCode                                 varchar(3) = " " ,
    @FXRate                                       Float = 0 ,
    @FXContract                                   varchar(25) = " " ,
    @EntryDate                                    DateTime = 0 ,
    @DocumentDate                                 DateTime = 0 ,
    @DateAccepted                                 DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @TenorDays                                    Int = 0 ,
    @TenorPhrase                                  varchar(50) = " " ,
    @LastTracerVia                                varchar(3) = " " ,
    @LastTracerDate                               DateTime = 0 ,
    @NumberOfTracers                              Int = 0 ,
    @TraceToday                                   Bit = 0 ,
    @BuyerPkey                                    Int = 0 ,
    @BuyerReference                               varchar(25) = " " ,
    @BuyerHow                                     varchar(3) = " " ,
    @BuyerDDA                                     varchar(20) = " " ,
    @CreatingProgram                              varchar(10) = " " ,
    @CollectionType                               varchar(3) = " " ,
    @BankingGroup                                 varchar(10) = " " ,
    @ExpenseCode                                  varchar(10) = " " ,
    @PaidDirect                                   Bit = 0 ,
    @CloseThisCollection                          Bit = 0 ,
    @Chk1Value                                    varchar(1) = " " ,
    @Chk2Value                                    varchar(1) = " " ,
    @Chk3Value                                    varchar(1) = " " ,
    @Chk4Value                                    varchar(1) = " " ,
    @Chk5Value                                    varchar(1) = " " ,
    @Chk6Value                                    varchar(1) = " " ,
    @Chk7Value                                    varchar(1) = " " ,
    @Chk8Value                                    varchar(1) = " " ,
    @Chk9Value                                    varchar(1) = " " ,
    @WaitingClarification                         varchar(1) = " " ,
    @WaitingAuthentication                        varchar(1) = " " ,
    @AmendTraceDays                               Int = 0 ,
    @AlternateAOPkey                              Int = 0 ,
    @AccountOfficerPkey                           Int = 0 ,
    @BLNumber                                     varchar(30) = " " ,
    @ReferencePerfix                              varchar(25) = " " ,
    @ConvertedRefNo                               varchar(25) = " " ,
    @InvoicePONo                                  varchar(35) = " " ,
    @ConvertedSystem                              varchar(10) = " " ,
    @Chk10Value                                   varchar(1) = " " ,
    @Chk11Value                                   varchar(1) = " " ,
    @Chk12Value                                   varchar(1) = " " ,
    @Chk13Value                                   varchar(1) = " " ,
    @Chk14Value                                   varchar(1) = " " ,
    @Chk15Value                                   varchar(1) = " " ,
    @Chk16Value                                   varchar(1) = " " ,
    @Chk17Value                                   varchar(1) = " " ,
    @Chk18Value                                   varchar(1) = " " ,
    @Chk19Value                                   varchar(1) = " " ,
    @Chk20Value                                   varchar(1) = " " ,
    @AuthForDebit                                 varchar(1) = " " ,
    @DoNotPurge                                   Bit = 0 ,
    @ClosedDate                                   DateTime = 0 ,
    @CommitmentNum                                varchar(16) = " " ,
    @PurposeCode                                  varchar(6) = " " ,
    @LoanSystem                                   varchar(20) = " " ,
    @FinanceType                                  varchar(20) = " " ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update BalScfPrimary set
    ScfPrimaryPkey = @ScfPrimaryPkey,
    EventPkey = @EventPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    ScfPrimaryStatus = @ScfPrimaryStatus,
    Active = @Active,
    GTSAction = @GTSAction,
    OurRefLegalEntity = @OurRefLegalEntity,
    OurRefDivisionNum = @OurRefDivisionNum,
    OurRefDepartmentNum = @OurRefDepartmentNum,
    OurReferenceNum = @OurReferenceNum,
    LetterType = @LetterType,
    SellerPkey = @SellerPkey,
    SellerReference = @SellerReference,
    SellerHow = @SellerHow,
    SellerDDA = @SellerDDA,
    OriginalAmountBase = @OriginalAmountBase,
    OriginalAmount = @OriginalAmount,
    AmountOutstandingBase = @AmountOutstandingBase,
    AmountOutstanding = @AmountOutstanding,
    CurrencyCode = @CurrencyCode,
    FXRate = @FXRate,
    FXContract = @FXContract,
    EntryDate = @EntryDate,
    DocumentDate = @DocumentDate,
    DateAccepted = @DateAccepted,
    MaturityDate = @MaturityDate,
    TenorDays = @TenorDays,
    TenorPhrase = @TenorPhrase,
    LastTracerVia = @LastTracerVia,
    LastTracerDate = @LastTracerDate,
    NumberOfTracers = @NumberOfTracers,
    TraceToday = @TraceToday,
    BuyerPkey = @BuyerPkey,
    BuyerReference = @BuyerReference,
    BuyerHow = @BuyerHow,
    BuyerDDA = @BuyerDDA,
    CreatingProgram = @CreatingProgram,
    CollectionType = @CollectionType,
    BankingGroup = @BankingGroup,
    ExpenseCode = @ExpenseCode,
    PaidDirect = @PaidDirect,
    CloseThisCollection = @CloseThisCollection,
    Chk1Value = @Chk1Value,
    Chk2Value = @Chk2Value,
    Chk3Value = @Chk3Value,
    Chk4Value = @Chk4Value,
    Chk5Value = @Chk5Value,
    Chk6Value = @Chk6Value,
    Chk7Value = @Chk7Value,
    Chk8Value = @Chk8Value,
    Chk9Value = @Chk9Value,
    WaitingClarification = @WaitingClarification,
    WaitingAuthentication = @WaitingAuthentication,
    AmendTraceDays = @AmendTraceDays,
    AlternateAOPkey = @AlternateAOPkey,
    AccountOfficerPkey = @AccountOfficerPkey,
    BLNumber = @BLNumber,
    ReferencePerfix = @ReferencePerfix,
    ConvertedRefNo = @ConvertedRefNo,
    InvoicePONo = @InvoicePONo,
    ConvertedSystem = @ConvertedSystem,
    Chk10Value = @Chk10Value,
    Chk11Value = @Chk11Value,
    Chk12Value = @Chk12Value,
    Chk13Value = @Chk13Value,
    Chk14Value = @Chk14Value,
    Chk15Value = @Chk15Value,
    Chk16Value = @Chk16Value,
    Chk17Value = @Chk17Value,
    Chk18Value = @Chk18Value,
    Chk19Value = @Chk19Value,
    Chk20Value = @Chk20Value,
    AuthForDebit = @AuthForDebit,
    DoNotPurge = @DoNotPurge,
    ClosedDate = @ClosedDate,
    CommitmentNum = @CommitmentNum,
    PurposeCode = @PurposeCode,
    LoanSystem = @LoanSystem,
    FinanceType = @FinanceType,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainBalScfPrimary]'
GO

CREATE PROCEDURE [dbo].[MainBalScfPrimary]
            @Pkey                                         Int = 0 ,
            @ScfPrimaryPkey                               Int = 0 ,
            @EventPkey                                    Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @ScfPrimaryStatus                             varchar(6) = "  " ,
            @Active                                       Bit = 0 ,
            @GTSAction                                    varchar(6) = "  " ,
            @OurRefLegalEntity                            varchar(2) = "  " ,
            @OurRefDivisionNum                            varchar(2) = "  " ,
            @OurRefDepartmentNum                          varchar(2) = "  " ,
            @OurReferenceNum                              varchar(8) = "  " ,
            @LetterType                                   varchar(6) = "  " ,
            @SellerPkey                                   Int = 0 ,
            @SellerReference                              varchar(25) = "  " ,
            @SellerHow                                    varchar(3) = "  " ,
            @SellerDDA                                    varchar(20) = "  " ,
            @OriginalAmountBase                           money = 0 ,
            @OriginalAmount                               money = 0 ,
            @AmountOutstandingBase                        money = 0 ,
            @AmountOutstanding                            money = 0 ,
            @CurrencyCode                                 varchar(3) = "  " ,
            @FXRate                                       Float = 0 ,
            @FXContract                                   varchar(25) = "  " ,
            @EntryDate                                    DateTime = 0 ,
            @DocumentDate                                 DateTime = 0 ,
            @DateAccepted                                 DateTime = 0 ,
            @MaturityDate                                 DateTime = 0 ,
            @TenorDays                                    Int = 0 ,
            @TenorPhrase                                  varchar(50) = "  " ,
            @LastTracerVia                                varchar(3) = "  " ,
            @LastTracerDate                               DateTime = 0 ,
            @NumberOfTracers                              Int = 0 ,
            @TraceToday                                   Bit = 0 ,
            @BuyerPkey                                    Int = 0 ,
            @BuyerReference                               varchar(25) = "  " ,
            @BuyerHow                                     varchar(3) = "  " ,
            @BuyerDDA                                     varchar(20) = "  " ,
            @CreatingProgram                              varchar(10) = "  " ,
            @CollectionType                               varchar(3) = "  " ,
            @BankingGroup                                 varchar(10) = "  " ,
            @ExpenseCode                                  varchar(10) = "  " ,
            @PaidDirect                                   Bit = 0 ,
            @CloseThisCollection                          Bit = 0 ,
            @Chk1Value                                    varchar(1) = "  " ,
            @Chk2Value                                    varchar(1) = "  " ,
            @Chk3Value                                    varchar(1) = "  " ,
            @Chk4Value                                    varchar(1) = "  " ,
            @Chk5Value                                    varchar(1) = "  " ,
            @Chk6Value                                    varchar(1) = "  " ,
            @Chk7Value                                    varchar(1) = "  " ,
            @Chk8Value                                    varchar(1) = "  " ,
            @Chk9Value                                    varchar(1) = "  " ,
            @WaitingClarification                         varchar(1) = "  " ,
            @WaitingAuthentication                        varchar(1) = "  " ,
            @AmendTraceDays                               Int = 0 ,
            @AlternateAOPkey                              Int = 0 ,
            @AccountOfficerPkey                           Int = 0 ,
            @BLNumber                                     varchar(30) = "  " ,
            @ReferencePerfix                              varchar(25) = "  " ,
            @ConvertedRefNo                               varchar(25) = "  " ,
            @InvoicePONo                                  varchar(35) = "  " ,
            @ConvertedSystem                              varchar(10) = "  " ,
            @Chk10Value                                   varchar(1) = "  " ,
            @Chk11Value                                   varchar(1) = "  " ,
            @Chk12Value                                   varchar(1) = "  " ,
            @Chk13Value                                   varchar(1) = "  " ,
            @Chk14Value                                   varchar(1) = "  " ,
            @Chk15Value                                   varchar(1) = "  " ,
            @Chk16Value                                   varchar(1) = "  " ,
            @Chk17Value                                   varchar(1) = "  " ,
            @Chk18Value                                   varchar(1) = "  " ,
            @Chk19Value                                   varchar(1) = "  " ,
            @Chk20Value                                   varchar(1) = "  " ,
            @AuthForDebit                                 varchar(1) = "  " ,
            @DoNotPurge                                   Bit = 0 ,
            @ClosedDate                                   DateTime = 0 ,
            @CommitmentNum                                varchar(16) = "  " ,
            @PurposeCode                                  varchar(6) = "  " ,
            @LoanSystem                                   varchar(20) = "  " ,
            @FinanceType                                  varchar(20) = "  " ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from BalScfPrimary with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = BalScfPrimaryinsert
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @ScfPrimaryStatus                              ,
        @Active                                        ,
        @GTSAction                                     ,
        @OurRefLegalEntity                             ,
        @OurRefDivisionNum                             ,
        @OurRefDepartmentNum                           ,
        @OurReferenceNum                               ,
        @LetterType                                    ,
        @SellerPkey                                    ,
        @SellerReference                               ,
        @SellerHow                                     ,
        @SellerDDA                                     ,
        @OriginalAmountBase                            ,
        @OriginalAmount                                ,
        @AmountOutstandingBase                         ,
        @AmountOutstanding                             ,
        @CurrencyCode                                  ,
        @FXRate                                        ,
        @FXContract                                    ,
        @EntryDate                                     ,
        @DocumentDate                                  ,
        @DateAccepted                                  ,
        @MaturityDate                                  ,
        @TenorDays                                     ,
        @TenorPhrase                                   ,
        @LastTracerVia                                 ,
        @LastTracerDate                                ,
        @NumberOfTracers                               ,
        @TraceToday                                    ,
        @BuyerPkey                                     ,
        @BuyerReference                                ,
        @BuyerHow                                      ,
        @BuyerDDA                                      ,
        @CreatingProgram                               ,
        @CollectionType                                ,
        @BankingGroup                                  ,
        @ExpenseCode                                   ,
        @PaidDirect                                    ,
        @CloseThisCollection                           ,
        @Chk1Value                                     ,
        @Chk2Value                                     ,
        @Chk3Value                                     ,
        @Chk4Value                                     ,
        @Chk5Value                                     ,
        @Chk6Value                                     ,
        @Chk7Value                                     ,
        @Chk8Value                                     ,
        @Chk9Value                                     ,
        @WaitingClarification                          ,
        @WaitingAuthentication                         ,
        @AmendTraceDays                                ,
        @AlternateAOPkey                               ,
        @AccountOfficerPkey                            ,
        @BLNumber                                      ,
        @ReferencePerfix                               ,
        @ConvertedRefNo                                ,
        @InvoicePONo                                   ,
        @ConvertedSystem                               ,
        @Chk10Value                                    ,
        @Chk11Value                                    ,
        @Chk12Value                                    ,
        @Chk13Value                                    ,
        @Chk14Value                                    ,
        @Chk15Value                                    ,
        @Chk16Value                                    ,
        @Chk17Value                                    ,
        @Chk18Value                                    ,
        @Chk19Value                                    ,
        @Chk20Value                                    ,
        @AuthForDebit                                  ,
        @DoNotPurge                                    ,
        @ClosedDate                                    ,
        @CommitmentNum                                 ,
        @PurposeCode                                   ,
        @LoanSystem                                    ,
        @FinanceType                                   ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = BalScfPrimaryupdate
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @ScfPrimaryStatus                              ,
        @Active                                        ,
        @GTSAction                                     ,
        @OurRefLegalEntity                             ,
        @OurRefDivisionNum                             ,
        @OurRefDepartmentNum                           ,
        @OurReferenceNum                               ,
        @LetterType                                    ,
        @SellerPkey                                    ,
        @SellerReference                               ,
        @SellerHow                                     ,
        @SellerDDA                                     ,
        @OriginalAmountBase                            ,
        @OriginalAmount                                ,
        @AmountOutstandingBase                         ,
        @AmountOutstanding                             ,
        @CurrencyCode                                  ,
        @FXRate                                        ,
        @FXContract                                    ,
        @EntryDate                                     ,
        @DocumentDate                                  ,
        @DateAccepted                                  ,
        @MaturityDate                                  ,
        @TenorDays                                     ,
        @TenorPhrase                                   ,
        @LastTracerVia                                 ,
        @LastTracerDate                                ,
        @NumberOfTracers                               ,
        @TraceToday                                    ,
        @BuyerPkey                                     ,
        @BuyerReference                                ,
        @BuyerHow                                      ,
        @BuyerDDA                                      ,
        @CreatingProgram                               ,
        @CollectionType                                ,
        @BankingGroup                                  ,
        @ExpenseCode                                   ,
        @PaidDirect                                    ,
        @CloseThisCollection                           ,
        @Chk1Value                                     ,
        @Chk2Value                                     ,
        @Chk3Value                                     ,
        @Chk4Value                                     ,
        @Chk5Value                                     ,
        @Chk6Value                                     ,
        @Chk7Value                                     ,
        @Chk8Value                                     ,
        @Chk9Value                                     ,
        @WaitingClarification                          ,
        @WaitingAuthentication                         ,
        @AmendTraceDays                                ,
        @AlternateAOPkey                               ,
        @AccountOfficerPkey                            ,
        @BLNumber                                      ,
        @ReferencePerfix                               ,
        @ConvertedRefNo                                ,
        @InvoicePONo                                   ,
        @ConvertedSystem                               ,
        @Chk10Value                                    ,
        @Chk11Value                                    ,
        @Chk12Value                                    ,
        @Chk13Value                                    ,
        @Chk14Value                                    ,
        @Chk15Value                                    ,
        @Chk16Value                                    ,
        @Chk17Value                                    ,
        @Chk18Value                                    ,
        @Chk19Value                                    ,
        @Chk20Value                                    ,
        @AuthForDebit                                  ,
        @DoNotPurge                                    ,
        @ClosedDate                                    ,
        @CommitmentNum                                 ,
        @PurposeCode                                   ,
        @LoanSystem                                    ,
        @FinanceType                                   ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalScfPrimaryReadByPkey]'
GO

CREATE PROCEDURE [dbo].[BalScfPrimaryReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from BalScfPrimary where pkey = @pkey
            select @rPkey = Pkey from BalScfPrimary where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledgesDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[LocPledgesDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from LocPledges where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfPrimaryInsert]'
GO

CREATE PROCEDURE [dbo].[ModelScfPrimaryInsert]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @ScfPrimaryStatus                             varchar(6) = "  " ,
    @Active                                       Bit = 0 ,
    @GTSAction                                    varchar(6) = "  " ,
    @OurRefLegalEntity                            varchar(2) = "  " ,
    @OurRefDivisionNum                            varchar(2) = "  " ,
    @OurRefDepartmentNum                          varchar(2) = "  " ,
    @OurReferenceNum                              varchar(8) = "  " ,
    @LetterType                                   varchar(6) = "  " ,
    @SellerPkey                                   Int = 0 ,
    @SellerReference                              varchar(25) = "  " ,
    @SellerHow                                    varchar(3) = "  " ,
    @SellerDDA                                    varchar(20) = "  " ,
    @OriginalAmountBase                           money = 0 ,
    @OriginalAmount                               money = 0 ,
    @AmountOutstandingBase                        money = 0 ,
    @AmountOutstanding                            money = 0 ,
    @CurrencyCode                                 varchar(3) = "  " ,
    @FXRate                                       Float = 0 ,
    @FXContract                                   varchar(25) = "  " ,
    @EntryDate                                    DateTime = 0 ,
    @DocumentDate                                 DateTime = 0 ,
    @DateAccepted                                 DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @TenorDays                                    Int = 0 ,
    @TenorPhrase                                  varchar(50) = "  " ,
    @LastTracerVia                                varchar(3) = "  " ,
    @LastTracerDate                               DateTime = 0 ,
    @NumberOfTracers                              Int = 0 ,
    @TraceToday                                   Bit = 0 ,
    @BuyerPkey                                    Int = 0 ,
    @BuyerReference                               varchar(25) = "  " ,
    @BuyerHow                                     varchar(3) = "  " ,
    @BuyerDDA                                     varchar(20) = "  " ,
    @CreatingProgram                              varchar(10) = "  " ,
    @CollectionType                               varchar(3) = "  " ,
    @BankingGroup                                 varchar(10) = "  " ,
    @ExpenseCode                                  varchar(10) = "  " ,
    @PaidDirect                                   Bit = 0 ,
    @CloseThisCollection                          Bit = 0 ,
    @Chk1Value                                    varchar(1) = "  " ,
    @Chk2Value                                    varchar(1) = "  " ,
    @Chk3Value                                    varchar(1) = "  " ,
    @Chk4Value                                    varchar(1) = "  " ,
    @Chk5Value                                    varchar(1) = "  " ,
    @Chk6Value                                    varchar(1) = "  " ,
    @Chk7Value                                    varchar(1) = "  " ,
    @Chk8Value                                    varchar(1) = "  " ,
    @Chk9Value                                    varchar(1) = "  " ,
    @WaitingClarification                         varchar(1) = "  " ,
    @WaitingAuthentication                        varchar(1) = "  " ,
    @AmendTraceDays                               Int = 0 ,
    @AlternateAOPkey                              Int = 0 ,
    @AccountOfficerPkey                           Int = 0 ,
    @BLNumber                                     varchar(30) = "  " ,
    @ReferencePerfix                              varchar(25) = "  " ,
    @ConvertedRefNo                               varchar(25) = "  " ,
    @InvoicePONo                                  varchar(35) = "  " ,
    @ConvertedSystem                              varchar(10) = "  " ,
    @Chk10Value                                   varchar(1) = "  " ,
    @Chk11Value                                   varchar(1) = "  " ,
    @Chk12Value                                   varchar(1) = "  " ,
    @Chk13Value                                   varchar(1) = "  " ,
    @Chk14Value                                   varchar(1) = "  " ,
    @Chk15Value                                   varchar(1) = "  " ,
    @Chk16Value                                   varchar(1) = "  " ,
    @Chk17Value                                   varchar(1) = "  " ,
    @Chk18Value                                   varchar(1) = "  " ,
    @Chk19Value                                   varchar(1) = "  " ,
    @Chk20Value                                   varchar(1) = "  " ,
    @AuthForDebit                                 varchar(1) = "  " ,
    @DoNotPurge                                   Bit = 0 ,
    @ClosedDate                                   DateTime = 0 ,
    @CommitmentNum                                varchar(16) = "  " ,
    @PurposeCode                                  varchar(6) = "  " ,
    @LoanSystem                                   varchar(20) = "  " ,
    @FinanceType                                  varchar(20) = "  " ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into ModelScfPrimary(
    Pkey ,
    ScfPrimaryPkey ,
    EventPkey ,
    TransPkey ,
    ReplacePkey ,
    ScfPrimaryStatus ,
    Active ,
    GTSAction ,
    OurRefLegalEntity ,
    OurRefDivisionNum ,
    OurRefDepartmentNum ,
    OurReferenceNum ,
    LetterType ,
    SellerPkey ,
    SellerReference ,
    SellerHow ,
    SellerDDA ,
    OriginalAmountBase ,
    OriginalAmount ,
    AmountOutstandingBase ,
    AmountOutstanding ,
    CurrencyCode ,
    FXRate ,
    FXContract ,
    EntryDate ,
    DocumentDate ,
    DateAccepted ,
    MaturityDate ,
    TenorDays ,
    TenorPhrase ,
    LastTracerVia ,
    LastTracerDate ,
    NumberOfTracers ,
    TraceToday ,
    BuyerPkey ,
    BuyerReference ,
    BuyerHow ,
    BuyerDDA ,
    CreatingProgram ,
    CollectionType ,
    BankingGroup ,
    ExpenseCode ,
    PaidDirect ,
    CloseThisCollection ,
    Chk1Value ,
    Chk2Value ,
    Chk3Value ,
    Chk4Value ,
    Chk5Value ,
    Chk6Value ,
    Chk7Value ,
    Chk8Value ,
    Chk9Value ,
    WaitingClarification ,
    WaitingAuthentication ,
    AmendTraceDays ,
    AlternateAOPkey ,
    AccountOfficerPkey ,
    BLNumber ,
    ReferencePerfix ,
    ConvertedRefNo ,
    InvoicePONo ,
    ConvertedSystem ,
    Chk10Value ,
    Chk11Value ,
    Chk12Value ,
    Chk13Value ,
    Chk14Value ,
    Chk15Value ,
    Chk16Value ,
    Chk17Value ,
    Chk18Value ,
    Chk19Value ,
    Chk20Value ,
    AuthForDebit ,
    DoNotPurge ,
    ClosedDate ,
    CommitmentNum ,
    PurposeCode ,
    LoanSystem ,
    FinanceType ,
    UPDATABASE)
values (
    @Pkey ,
    @ScfPrimaryPkey ,
    @EventPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @ScfPrimaryStatus ,
    @Active ,
    @GTSAction ,
    @OurRefLegalEntity ,
    @OurRefDivisionNum ,
    @OurRefDepartmentNum ,
    @OurReferenceNum ,
    @LetterType ,
    @SellerPkey ,
    @SellerReference ,
    @SellerHow ,
    @SellerDDA ,
    @OriginalAmountBase ,
    @OriginalAmount ,
    @AmountOutstandingBase ,
    @AmountOutstanding ,
    @CurrencyCode ,
    @FXRate ,
    @FXContract ,
    @EntryDate ,
    @DocumentDate ,
    @DateAccepted ,
    @MaturityDate ,
    @TenorDays ,
    @TenorPhrase ,
    @LastTracerVia ,
    @LastTracerDate ,
    @NumberOfTracers ,
    @TraceToday ,
    @BuyerPkey ,
    @BuyerReference ,
    @BuyerHow ,
    @BuyerDDA ,
    @CreatingProgram ,
    @CollectionType ,
    @BankingGroup ,
    @ExpenseCode ,
    @PaidDirect ,
    @CloseThisCollection ,
    @Chk1Value ,
    @Chk2Value ,
    @Chk3Value ,
    @Chk4Value ,
    @Chk5Value ,
    @Chk6Value ,
    @Chk7Value ,
    @Chk8Value ,
    @Chk9Value ,
    @WaitingClarification ,
    @WaitingAuthentication ,
    @AmendTraceDays ,
    @AlternateAOPkey ,
    @AccountOfficerPkey ,
    @BLNumber ,
    @ReferencePerfix ,
    @ConvertedRefNo ,
    @InvoicePONo ,
    @ConvertedSystem ,
    @Chk10Value ,
    @Chk11Value ,
    @Chk12Value ,
    @Chk13Value ,
    @Chk14Value ,
    @Chk15Value ,
    @Chk16Value ,
    @Chk17Value ,
    @Chk18Value ,
    @Chk19Value ,
    @Chk20Value ,
    @AuthForDebit ,
    @DoNotPurge ,
    @ClosedDate ,
    @CommitmentNum ,
    @PurposeCode ,
    @LoanSystem ,
    @FinanceType ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledgesInsert]'
GO

CREATE PROCEDURE [dbo].[LocPledgesInsert]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = "  " ,
    @PledgeID                                     Int = 0 ,
    @DepositorsPkey                               Int = 0 ,
    @DepositorsName                               varchar(35) = "  " ,
    @StartDate                                    DateTime = 0 ,
    @EndDate                                      DateTime = 0 ,
    @Amount                                       money = 0 ,
    @Adjustment                                   varchar(1) = "  " ,
    @DepositorsAddress1                           varchar(35) = "  " ,
    @DepositorsAddress2                           varchar(35) = "  " ,
    @DepositorsAddress3                           varchar(35) = "  " ,
    @DepositorsZip                                varchar(5) = "  " ,
    @DepositorsPhone                              varchar(25) = "  " ,
    @DepositorsEmail                              varchar(200) = "  " ,
    @SafeKeepingTicketNum                         varchar(30) = "  " ,
    @IccDepositorsPkey                            Int = 0 ,
    @DepositorsAttnLine1                          varchar(35) = "  " ,
    @DepositorsGtsPartyID                         varchar(18) = "  " ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into LocPledges(
    Pkey ,
    LocPrimaryPkey ,
    TransPkey ,
    ReplacePkey ,
    GtsAction ,
    PledgeID ,
    DepositorsPkey ,
    DepositorsName ,
    StartDate ,
    EndDate ,
    Amount ,
    Adjustment ,
    DepositorsAddress1 ,
    DepositorsAddress2 ,
    DepositorsAddress3 ,
    DepositorsZip ,
    DepositorsPhone ,
    DepositorsEmail ,
    SafeKeepingTicketNum ,
    IccDepositorsPkey ,
    DepositorsAttnLine1 ,
    DepositorsGtsPartyID ,
    UPDATABASE)
values (
    @Pkey ,
    @LocPrimaryPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @GtsAction ,
    @PledgeID ,
    @DepositorsPkey ,
    @DepositorsName ,
    @StartDate ,
    @EndDate ,
    @Amount ,
    @Adjustment ,
    @DepositorsAddress1 ,
    @DepositorsAddress2 ,
    @DepositorsAddress3 ,
    @DepositorsZip ,
    @DepositorsPhone ,
    @DepositorsEmail ,
    @SafeKeepingTicketNum ,
    @IccDepositorsPkey ,
    @DepositorsAttnLine1 ,
    @DepositorsGtsPartyID ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfPrimaryupdate]'
GO

CREATE PROCEDURE [dbo].[ModelScfPrimaryupdate]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @ScfPrimaryStatus                             varchar(6) = " " ,
    @Active                                       Bit = 0 ,
    @GTSAction                                    varchar(6) = " " ,
    @OurRefLegalEntity                            varchar(2) = " " ,
    @OurRefDivisionNum                            varchar(2) = " " ,
    @OurRefDepartmentNum                          varchar(2) = " " ,
    @OurReferenceNum                              varchar(8) = " " ,
    @LetterType                                   varchar(6) = " " ,
    @SellerPkey                                   Int = 0 ,
    @SellerReference                              varchar(25) = " " ,
    @SellerHow                                    varchar(3) = " " ,
    @SellerDDA                                    varchar(20) = " " ,
    @OriginalAmountBase                           money = 0 ,
    @OriginalAmount                               money = 0 ,
    @AmountOutstandingBase                        money = 0 ,
    @AmountOutstanding                            money = 0 ,
    @CurrencyCode                                 varchar(3) = " " ,
    @FXRate                                       Float = 0 ,
    @FXContract                                   varchar(25) = " " ,
    @EntryDate                                    DateTime = 0 ,
    @DocumentDate                                 DateTime = 0 ,
    @DateAccepted                                 DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @TenorDays                                    Int = 0 ,
    @TenorPhrase                                  varchar(50) = " " ,
    @LastTracerVia                                varchar(3) = " " ,
    @LastTracerDate                               DateTime = 0 ,
    @NumberOfTracers                              Int = 0 ,
    @TraceToday                                   Bit = 0 ,
    @BuyerPkey                                    Int = 0 ,
    @BuyerReference                               varchar(25) = " " ,
    @BuyerHow                                     varchar(3) = " " ,
    @BuyerDDA                                     varchar(20) = " " ,
    @CreatingProgram                              varchar(10) = " " ,
    @CollectionType                               varchar(3) = " " ,
    @BankingGroup                                 varchar(10) = " " ,
    @ExpenseCode                                  varchar(10) = " " ,
    @PaidDirect                                   Bit = 0 ,
    @CloseThisCollection                          Bit = 0 ,
    @Chk1Value                                    varchar(1) = " " ,
    @Chk2Value                                    varchar(1) = " " ,
    @Chk3Value                                    varchar(1) = " " ,
    @Chk4Value                                    varchar(1) = " " ,
    @Chk5Value                                    varchar(1) = " " ,
    @Chk6Value                                    varchar(1) = " " ,
    @Chk7Value                                    varchar(1) = " " ,
    @Chk8Value                                    varchar(1) = " " ,
    @Chk9Value                                    varchar(1) = " " ,
    @WaitingClarification                         varchar(1) = " " ,
    @WaitingAuthentication                        varchar(1) = " " ,
    @AmendTraceDays                               Int = 0 ,
    @AlternateAOPkey                              Int = 0 ,
    @AccountOfficerPkey                           Int = 0 ,
    @BLNumber                                     varchar(30) = " " ,
    @ReferencePerfix                              varchar(25) = " " ,
    @ConvertedRefNo                               varchar(25) = " " ,
    @InvoicePONo                                  varchar(35) = " " ,
    @ConvertedSystem                              varchar(10) = " " ,
    @Chk10Value                                   varchar(1) = " " ,
    @Chk11Value                                   varchar(1) = " " ,
    @Chk12Value                                   varchar(1) = " " ,
    @Chk13Value                                   varchar(1) = " " ,
    @Chk14Value                                   varchar(1) = " " ,
    @Chk15Value                                   varchar(1) = " " ,
    @Chk16Value                                   varchar(1) = " " ,
    @Chk17Value                                   varchar(1) = " " ,
    @Chk18Value                                   varchar(1) = " " ,
    @Chk19Value                                   varchar(1) = " " ,
    @Chk20Value                                   varchar(1) = " " ,
    @AuthForDebit                                 varchar(1) = " " ,
    @DoNotPurge                                   Bit = 0 ,
    @ClosedDate                                   DateTime = 0 ,
    @CommitmentNum                                varchar(16) = " " ,
    @PurposeCode                                  varchar(6) = " " ,
    @LoanSystem                                   varchar(20) = " " ,
    @FinanceType                                  varchar(20) = " " ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update ModelScfPrimary set
    ScfPrimaryPkey = @ScfPrimaryPkey,
    EventPkey = @EventPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    ScfPrimaryStatus = @ScfPrimaryStatus,
    Active = @Active,
    GTSAction = @GTSAction,
    OurRefLegalEntity = @OurRefLegalEntity,
    OurRefDivisionNum = @OurRefDivisionNum,
    OurRefDepartmentNum = @OurRefDepartmentNum,
    OurReferenceNum = @OurReferenceNum,
    LetterType = @LetterType,
    SellerPkey = @SellerPkey,
    SellerReference = @SellerReference,
    SellerHow = @SellerHow,
    SellerDDA = @SellerDDA,
    OriginalAmountBase = @OriginalAmountBase,
    OriginalAmount = @OriginalAmount,
    AmountOutstandingBase = @AmountOutstandingBase,
    AmountOutstanding = @AmountOutstanding,
    CurrencyCode = @CurrencyCode,
    FXRate = @FXRate,
    FXContract = @FXContract,
    EntryDate = @EntryDate,
    DocumentDate = @DocumentDate,
    DateAccepted = @DateAccepted,
    MaturityDate = @MaturityDate,
    TenorDays = @TenorDays,
    TenorPhrase = @TenorPhrase,
    LastTracerVia = @LastTracerVia,
    LastTracerDate = @LastTracerDate,
    NumberOfTracers = @NumberOfTracers,
    TraceToday = @TraceToday,
    BuyerPkey = @BuyerPkey,
    BuyerReference = @BuyerReference,
    BuyerHow = @BuyerHow,
    BuyerDDA = @BuyerDDA,
    CreatingProgram = @CreatingProgram,
    CollectionType = @CollectionType,
    BankingGroup = @BankingGroup,
    ExpenseCode = @ExpenseCode,
    PaidDirect = @PaidDirect,
    CloseThisCollection = @CloseThisCollection,
    Chk1Value = @Chk1Value,
    Chk2Value = @Chk2Value,
    Chk3Value = @Chk3Value,
    Chk4Value = @Chk4Value,
    Chk5Value = @Chk5Value,
    Chk6Value = @Chk6Value,
    Chk7Value = @Chk7Value,
    Chk8Value = @Chk8Value,
    Chk9Value = @Chk9Value,
    WaitingClarification = @WaitingClarification,
    WaitingAuthentication = @WaitingAuthentication,
    AmendTraceDays = @AmendTraceDays,
    AlternateAOPkey = @AlternateAOPkey,
    AccountOfficerPkey = @AccountOfficerPkey,
    BLNumber = @BLNumber,
    ReferencePerfix = @ReferencePerfix,
    ConvertedRefNo = @ConvertedRefNo,
    InvoicePONo = @InvoicePONo,
    ConvertedSystem = @ConvertedSystem,
    Chk10Value = @Chk10Value,
    Chk11Value = @Chk11Value,
    Chk12Value = @Chk12Value,
    Chk13Value = @Chk13Value,
    Chk14Value = @Chk14Value,
    Chk15Value = @Chk15Value,
    Chk16Value = @Chk16Value,
    Chk17Value = @Chk17Value,
    Chk18Value = @Chk18Value,
    Chk19Value = @Chk19Value,
    Chk20Value = @Chk20Value,
    AuthForDebit = @AuthForDebit,
    DoNotPurge = @DoNotPurge,
    ClosedDate = @ClosedDate,
    CommitmentNum = @CommitmentNum,
    PurposeCode = @PurposeCode,
    LoanSystem = @LoanSystem,
    FinanceType = @FinanceType,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledgesupdate]'
GO

CREATE PROCEDURE [dbo].[LocPledgesupdate]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = " " ,
    @PledgeID                                     Int = 0 ,
    @DepositorsPkey                               Int = 0 ,
    @DepositorsName                               varchar(35) = " " ,
    @StartDate                                    DateTime = 0 ,
    @EndDate                                      DateTime = 0 ,
    @Amount                                       money = 0 ,
    @Adjustment                                   varchar(1) = " " ,
    @DepositorsAddress1                           varchar(35) = " " ,
    @DepositorsAddress2                           varchar(35) = " " ,
    @DepositorsAddress3                           varchar(35) = " " ,
    @DepositorsZip                                varchar(5) = " " ,
    @DepositorsPhone                              varchar(25) = " " ,
    @DepositorsEmail                              varchar(200) = " " ,
    @SafeKeepingTicketNum                         varchar(30) = " " ,
    @IccDepositorsPkey                            Int = 0 ,
    @DepositorsAttnLine1                          varchar(35) = " " ,
    @DepositorsGtsPartyID                         varchar(18) = " " ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update LocPledges set
    LocPrimaryPkey = @LocPrimaryPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    GtsAction = @GtsAction,
    PledgeID = @PledgeID,
    DepositorsPkey = @DepositorsPkey,
    DepositorsName = @DepositorsName,
    StartDate = @StartDate,
    EndDate = @EndDate,
    Amount = @Amount,
    Adjustment = @Adjustment,
    DepositorsAddress1 = @DepositorsAddress1,
    DepositorsAddress2 = @DepositorsAddress2,
    DepositorsAddress3 = @DepositorsAddress3,
    DepositorsZip = @DepositorsZip,
    DepositorsPhone = @DepositorsPhone,
    DepositorsEmail = @DepositorsEmail,
    SafeKeepingTicketNum = @SafeKeepingTicketNum,
    IccDepositorsPkey = @IccDepositorsPkey,
    DepositorsAttnLine1 = @DepositorsAttnLine1,
    DepositorsGtsPartyID = @DepositorsGtsPartyID,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainModelScfPrimary]'
GO

CREATE PROCEDURE [dbo].[MainModelScfPrimary]
            @Pkey                                         Int = 0 ,
            @ScfPrimaryPkey                               Int = 0 ,
            @EventPkey                                    Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @ScfPrimaryStatus                             varchar(6) = "  " ,
            @Active                                       Bit = 0 ,
            @GTSAction                                    varchar(6) = "  " ,
            @OurRefLegalEntity                            varchar(2) = "  " ,
            @OurRefDivisionNum                            varchar(2) = "  " ,
            @OurRefDepartmentNum                          varchar(2) = "  " ,
            @OurReferenceNum                              varchar(8) = "  " ,
            @LetterType                                   varchar(6) = "  " ,
            @SellerPkey                                   Int = 0 ,
            @SellerReference                              varchar(25) = "  " ,
            @SellerHow                                    varchar(3) = "  " ,
            @SellerDDA                                    varchar(20) = "  " ,
            @OriginalAmountBase                           money = 0 ,
            @OriginalAmount                               money = 0 ,
            @AmountOutstandingBase                        money = 0 ,
            @AmountOutstanding                            money = 0 ,
            @CurrencyCode                                 varchar(3) = "  " ,
            @FXRate                                       Float = 0 ,
            @FXContract                                   varchar(25) = "  " ,
            @EntryDate                                    DateTime = 0 ,
            @DocumentDate                                 DateTime = 0 ,
            @DateAccepted                                 DateTime = 0 ,
            @MaturityDate                                 DateTime = 0 ,
            @TenorDays                                    Int = 0 ,
            @TenorPhrase                                  varchar(50) = "  " ,
            @LastTracerVia                                varchar(3) = "  " ,
            @LastTracerDate                               DateTime = 0 ,
            @NumberOfTracers                              Int = 0 ,
            @TraceToday                                   Bit = 0 ,
            @BuyerPkey                                    Int = 0 ,
            @BuyerReference                               varchar(25) = "  " ,
            @BuyerHow                                     varchar(3) = "  " ,
            @BuyerDDA                                     varchar(20) = "  " ,
            @CreatingProgram                              varchar(10) = "  " ,
            @CollectionType                               varchar(3) = "  " ,
            @BankingGroup                                 varchar(10) = "  " ,
            @ExpenseCode                                  varchar(10) = "  " ,
            @PaidDirect                                   Bit = 0 ,
            @CloseThisCollection                          Bit = 0 ,
            @Chk1Value                                    varchar(1) = "  " ,
            @Chk2Value                                    varchar(1) = "  " ,
            @Chk3Value                                    varchar(1) = "  " ,
            @Chk4Value                                    varchar(1) = "  " ,
            @Chk5Value                                    varchar(1) = "  " ,
            @Chk6Value                                    varchar(1) = "  " ,
            @Chk7Value                                    varchar(1) = "  " ,
            @Chk8Value                                    varchar(1) = "  " ,
            @Chk9Value                                    varchar(1) = "  " ,
            @WaitingClarification                         varchar(1) = "  " ,
            @WaitingAuthentication                        varchar(1) = "  " ,
            @AmendTraceDays                               Int = 0 ,
            @AlternateAOPkey                              Int = 0 ,
            @AccountOfficerPkey                           Int = 0 ,
            @BLNumber                                     varchar(30) = "  " ,
            @ReferencePerfix                              varchar(25) = "  " ,
            @ConvertedRefNo                               varchar(25) = "  " ,
            @InvoicePONo                                  varchar(35) = "  " ,
            @ConvertedSystem                              varchar(10) = "  " ,
            @Chk10Value                                   varchar(1) = "  " ,
            @Chk11Value                                   varchar(1) = "  " ,
            @Chk12Value                                   varchar(1) = "  " ,
            @Chk13Value                                   varchar(1) = "  " ,
            @Chk14Value                                   varchar(1) = "  " ,
            @Chk15Value                                   varchar(1) = "  " ,
            @Chk16Value                                   varchar(1) = "  " ,
            @Chk17Value                                   varchar(1) = "  " ,
            @Chk18Value                                   varchar(1) = "  " ,
            @Chk19Value                                   varchar(1) = "  " ,
            @Chk20Value                                   varchar(1) = "  " ,
            @AuthForDebit                                 varchar(1) = "  " ,
            @DoNotPurge                                   Bit = 0 ,
            @ClosedDate                                   DateTime = 0 ,
            @CommitmentNum                                varchar(16) = "  " ,
            @PurposeCode                                  varchar(6) = "  " ,
            @LoanSystem                                   varchar(20) = "  " ,
            @FinanceType                                  varchar(20) = "  " ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from ModelScfPrimary with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = ModelScfPrimaryinsert
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @ScfPrimaryStatus                              ,
        @Active                                        ,
        @GTSAction                                     ,
        @OurRefLegalEntity                             ,
        @OurRefDivisionNum                             ,
        @OurRefDepartmentNum                           ,
        @OurReferenceNum                               ,
        @LetterType                                    ,
        @SellerPkey                                    ,
        @SellerReference                               ,
        @SellerHow                                     ,
        @SellerDDA                                     ,
        @OriginalAmountBase                            ,
        @OriginalAmount                                ,
        @AmountOutstandingBase                         ,
        @AmountOutstanding                             ,
        @CurrencyCode                                  ,
        @FXRate                                        ,
        @FXContract                                    ,
        @EntryDate                                     ,
        @DocumentDate                                  ,
        @DateAccepted                                  ,
        @MaturityDate                                  ,
        @TenorDays                                     ,
        @TenorPhrase                                   ,
        @LastTracerVia                                 ,
        @LastTracerDate                                ,
        @NumberOfTracers                               ,
        @TraceToday                                    ,
        @BuyerPkey                                     ,
        @BuyerReference                                ,
        @BuyerHow                                      ,
        @BuyerDDA                                      ,
        @CreatingProgram                               ,
        @CollectionType                                ,
        @BankingGroup                                  ,
        @ExpenseCode                                   ,
        @PaidDirect                                    ,
        @CloseThisCollection                           ,
        @Chk1Value                                     ,
        @Chk2Value                                     ,
        @Chk3Value                                     ,
        @Chk4Value                                     ,
        @Chk5Value                                     ,
        @Chk6Value                                     ,
        @Chk7Value                                     ,
        @Chk8Value                                     ,
        @Chk9Value                                     ,
        @WaitingClarification                          ,
        @WaitingAuthentication                         ,
        @AmendTraceDays                                ,
        @AlternateAOPkey                               ,
        @AccountOfficerPkey                            ,
        @BLNumber                                      ,
        @ReferencePerfix                               ,
        @ConvertedRefNo                                ,
        @InvoicePONo                                   ,
        @ConvertedSystem                               ,
        @Chk10Value                                    ,
        @Chk11Value                                    ,
        @Chk12Value                                    ,
        @Chk13Value                                    ,
        @Chk14Value                                    ,
        @Chk15Value                                    ,
        @Chk16Value                                    ,
        @Chk17Value                                    ,
        @Chk18Value                                    ,
        @Chk19Value                                    ,
        @Chk20Value                                    ,
        @AuthForDebit                                  ,
        @DoNotPurge                                    ,
        @ClosedDate                                    ,
        @CommitmentNum                                 ,
        @PurposeCode                                   ,
        @LoanSystem                                    ,
        @FinanceType                                   ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = ModelScfPrimaryupdate
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @ScfPrimaryStatus                              ,
        @Active                                        ,
        @GTSAction                                     ,
        @OurRefLegalEntity                             ,
        @OurRefDivisionNum                             ,
        @OurRefDepartmentNum                           ,
        @OurReferenceNum                               ,
        @LetterType                                    ,
        @SellerPkey                                    ,
        @SellerReference                               ,
        @SellerHow                                     ,
        @SellerDDA                                     ,
        @OriginalAmountBase                            ,
        @OriginalAmount                                ,
        @AmountOutstandingBase                         ,
        @AmountOutstanding                             ,
        @CurrencyCode                                  ,
        @FXRate                                        ,
        @FXContract                                    ,
        @EntryDate                                     ,
        @DocumentDate                                  ,
        @DateAccepted                                  ,
        @MaturityDate                                  ,
        @TenorDays                                     ,
        @TenorPhrase                                   ,
        @LastTracerVia                                 ,
        @LastTracerDate                                ,
        @NumberOfTracers                               ,
        @TraceToday                                    ,
        @BuyerPkey                                     ,
        @BuyerReference                                ,
        @BuyerHow                                      ,
        @BuyerDDA                                      ,
        @CreatingProgram                               ,
        @CollectionType                                ,
        @BankingGroup                                  ,
        @ExpenseCode                                   ,
        @PaidDirect                                    ,
        @CloseThisCollection                           ,
        @Chk1Value                                     ,
        @Chk2Value                                     ,
        @Chk3Value                                     ,
        @Chk4Value                                     ,
        @Chk5Value                                     ,
        @Chk6Value                                     ,
        @Chk7Value                                     ,
        @Chk8Value                                     ,
        @Chk9Value                                     ,
        @WaitingClarification                          ,
        @WaitingAuthentication                         ,
        @AmendTraceDays                                ,
        @AlternateAOPkey                               ,
        @AccountOfficerPkey                            ,
        @BLNumber                                      ,
        @ReferencePerfix                               ,
        @ConvertedRefNo                                ,
        @InvoicePONo                                   ,
        @ConvertedSystem                               ,
        @Chk10Value                                    ,
        @Chk11Value                                    ,
        @Chk12Value                                    ,
        @Chk13Value                                    ,
        @Chk14Value                                    ,
        @Chk15Value                                    ,
        @Chk16Value                                    ,
        @Chk17Value                                    ,
        @Chk18Value                                    ,
        @Chk19Value                                    ,
        @Chk20Value                                    ,
        @AuthForDebit                                  ,
        @DoNotPurge                                    ,
        @ClosedDate                                    ,
        @CommitmentNum                                 ,
        @PurposeCode                                   ,
        @LoanSystem                                    ,
        @FinanceType                                   ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainLocPledges]'
GO

CREATE PROCEDURE [dbo].[MainLocPledges]
            @Pkey                                         Int = 0 ,
            @LocPrimaryPkey                               Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @GtsAction                                    varchar(6) = "  " ,
            @PledgeID                                     Int = 0 ,
            @DepositorsPkey                               Int = 0 ,
            @DepositorsName                               varchar(35) = "  " ,
            @StartDate                                    DateTime = 0 ,
            @EndDate                                      DateTime = 0 ,
            @Amount                                       money = 0 ,
            @Adjustment                                   varchar(1) = "  " ,
            @DepositorsAddress1                           varchar(35) = "  " ,
            @DepositorsAddress2                           varchar(35) = "  " ,
            @DepositorsAddress3                           varchar(35) = "  " ,
            @DepositorsZip                                varchar(5) = "  " ,
            @DepositorsPhone                              varchar(25) = "  " ,
            @DepositorsEmail                              varchar(200) = "  " ,
            @SafeKeepingTicketNum                         varchar(30) = "  " ,
            @IccDepositorsPkey                            Int = 0 ,
            @DepositorsAttnLine1                          varchar(35) = "  " ,
            @DepositorsGtsPartyID                         varchar(18) = "  " ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from LocPledges with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = LocPledgesinsert
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @PledgeID                                      ,
        @DepositorsPkey                                ,
        @DepositorsName                                ,
        @StartDate                                     ,
        @EndDate                                       ,
        @Amount                                        ,
        @Adjustment                                    ,
        @DepositorsAddress1                            ,
        @DepositorsAddress2                            ,
        @DepositorsAddress3                            ,
        @DepositorsZip                                 ,
        @DepositorsPhone                               ,
        @DepositorsEmail                               ,
        @SafeKeepingTicketNum                          ,
        @IccDepositorsPkey                             ,
        @DepositorsAttnLine1                           ,
        @DepositorsGtsPartyID                          ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = LocPledgesupdate
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @PledgeID                                      ,
        @DepositorsPkey                                ,
        @DepositorsName                                ,
        @StartDate                                     ,
        @EndDate                                       ,
        @Amount                                        ,
        @Adjustment                                    ,
        @DepositorsAddress1                            ,
        @DepositorsAddress2                            ,
        @DepositorsAddress3                            ,
        @DepositorsZip                                 ,
        @DepositorsPhone                               ,
        @DepositorsEmail                               ,
        @SafeKeepingTicketNum                          ,
        @IccDepositorsPkey                             ,
        @DepositorsAttnLine1                           ,
        @DepositorsGtsPartyID                          ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfPrimaryReadByPkey]'
GO

CREATE PROCEDURE [dbo].[ModelScfPrimaryReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from ModelScfPrimary where pkey = @pkey
            select @rPkey = Pkey from ModelScfPrimary where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledgesIssRel]'
GO

CREATE PROCEDURE [dbo].[LocPledgesIssRel]
    @OldPrimaryPkey    int

AS

            Insert into BalLocPledges Select
            Pkey, 
            LocPrimaryPkey, 
            TransPkey, 
            ReplacePkey, 
            GtsAction, 
            PledgeID, 
            DepositorsPkey, 
            DepositorsName, 
            StartDate, 
            EndDate, 
            Amount, 
            Adjustment, 
            DepositorsAddress1, 
            DepositorsAddress2, 
            DepositorsAddress3, 
            DepositorsZip, 
            DepositorsPhone, 
            DepositorsEmail, 
            SafeKeepingTicketNum, 
            IccDepositorsPkey, 
            DepositorsAttnLine1, 
            DepositorsGtsPartyID, 
            UPDATABASE 
            from LocPledges where @oldprimarypkey = LOCPRIMARYPkey
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfPrimaryDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[ModelScfPrimaryDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from ModelScfPrimary where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledgesMove]'
GO

CREATE PROCEDURE [dbo].[LocPledgesMove]
    @LocPkey    int,
    @TPkey    int

AS

    Declare
    @Pkey                                         Int, 
    @LocPrimaryPkey                               Int, 
    @TransPkey                                    Int, 
    @ReplacePkey                                  Int, 
    @GtsAction                                    varchar(6), 
    @PledgeID                                     Int, 
    @DepositorsPkey                               Int, 
    @DepositorsName                               varchar(35), 
    @StartDate                                    DateTime, 
    @EndDate                                      DateTime, 
    @Amount                                       money, 
    @Adjustment                                   varchar(1), 
    @DepositorsAddress1                           varchar(35), 
    @DepositorsAddress2                           varchar(35), 
    @DepositorsAddress3                           varchar(35), 
    @DepositorsZip                                varchar(5), 
    @DepositorsPhone                              varchar(25), 
    @DepositorsEmail                              varchar(200), 
    @SafeKeepingTicketNum                         varchar(30), 
    @IccDepositorsPkey                            Int, 
    @DepositorsAttnLine1                          varchar(35), 
    @DepositorsGtsPartyID                         varchar(18), 
    @UPDATABASE                                   varchar(1) 
    declare @done as int
    select @done = -1

    Declare LocPledges Cursor for select * from LocPledges
         Where @tpkey = Transpkey
    Open LocPledges

    while @done = -1
    Begin
        fetch next from LocPledges Into 
        @Pkey ,
        @LocPrimaryPkey ,
        @TransPkey ,
        @ReplacePkey ,
        @GtsAction ,
        @PledgeID ,
        @DepositorsPkey ,
        @DepositorsName ,
        @StartDate ,
        @EndDate ,
        @Amount ,
        @Adjustment ,
        @DepositorsAddress1 ,
        @DepositorsAddress2 ,
        @DepositorsAddress3 ,
        @DepositorsZip ,
        @DepositorsPhone ,
        @DepositorsEmail ,
        @SafeKeepingTicketNum ,
        @IccDepositorsPkey ,
        @DepositorsAttnLine1 ,
        @DepositorsGtsPartyID ,
        @UPDATABASE

        If @@fetch_status = 0
        Begin
            if @GTSaction = 'ADD' 
                Begin
                    Insert into BalLocPledges(
                        Pkey ,
                        LocPrimaryPkey ,
                        TransPkey ,
                        ReplacePkey ,
                        GtsAction ,
                        PledgeID ,
                        DepositorsPkey ,
                        DepositorsName ,
                        StartDate ,
                        EndDate ,
                        Amount ,
                        Adjustment ,
                        DepositorsAddress1 ,
                        DepositorsAddress2 ,
                        DepositorsAddress3 ,
                        DepositorsZip ,
                        DepositorsPhone ,
                        DepositorsEmail ,
                        SafeKeepingTicketNum ,
                        IccDepositorsPkey ,
                        DepositorsAttnLine1 ,
                        DepositorsGtsPartyID ,
                        UPDATABASE)
values (
                        @Pkey ,
                        @LocPrimaryPkey ,
                        @TransPkey ,
                        @ReplacePkey ,
                        @GtsAction ,
                        @PledgeID ,
                        @DepositorsPkey ,
                        @DepositorsName ,
                        @StartDate ,
                        @EndDate ,
                        @Amount ,
                        @Adjustment ,
                        @DepositorsAddress1 ,
                        @DepositorsAddress2 ,
                        @DepositorsAddress3 ,
                        @DepositorsZip ,
                        @DepositorsPhone ,
                        @DepositorsEmail ,
                        @SafeKeepingTicketNum ,
                        @IccDepositorsPkey ,
                        @DepositorsAttnLine1 ,
                        @DepositorsGtsPartyID ,
                        @UPDATABASE)

                END

            IF @GTSACTION = 'AMEND'
                BEGIN
                    update  BalLocPledges set 
                        LocPrimaryPkey = @LocPrimaryPkey, 
                        TransPkey = @TransPkey, 
                        ReplacePkey = @ReplacePkey, 
                        GtsAction = @GtsAction, 
                        PledgeID = @PledgeID, 
                        DepositorsPkey = @DepositorsPkey, 
                        DepositorsName = @DepositorsName, 
                        StartDate = @StartDate, 
                        EndDate = @EndDate, 
                        Amount = @Amount, 
                        Adjustment = @Adjustment, 
                        DepositorsAddress1 = @DepositorsAddress1, 
                        DepositorsAddress2 = @DepositorsAddress2, 
                        DepositorsAddress3 = @DepositorsAddress3, 
                        DepositorsZip = @DepositorsZip, 
                        DepositorsPhone = @DepositorsPhone, 
                        DepositorsEmail = @DepositorsEmail, 
                        SafeKeepingTicketNum = @SafeKeepingTicketNum, 
                        IccDepositorsPkey = @IccDepositorsPkey, 
                        DepositorsAttnLine1 = @DepositorsAttnLine1, 
                        DepositorsGtsPartyID = @DepositorsGtsPartyID, 
                        UPDATABASE = @UPDATABASE 
                            where pkey = @Replacepkey
                End

            if @GTSaction = 'DELETE' 
                Begin
                    Delete From BalLocPledges where pkey = @Replacepkey

                END

            End

            if @@fetch_status <> 0 select @done = 0

    end
    close LocPledges
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocPledgesReadByPkey]'
GO

CREATE PROCEDURE [dbo].[LocPledgesReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from LocPledges where pkey = @pkey
            select @rPkey = Pkey from LocPledges where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocPledgesInsert]'
GO

CREATE PROCEDURE [dbo].[BalLocPledgesInsert]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = "  " ,
    @PledgeID                                     Int = 0 ,
    @DepositorsPkey                               Int = 0 ,
    @DepositorsName                               varchar(35) = "  " ,
    @StartDate                                    DateTime = 0 ,
    @EndDate                                      DateTime = 0 ,
    @Amount                                       money = 0 ,
    @Adjustment                                   varchar(1) = "  " ,
    @DepositorsAddress1                           varchar(35) = "  " ,
    @DepositorsAddress2                           varchar(35) = "  " ,
    @DepositorsAddress3                           varchar(35) = "  " ,
    @DepositorsZip                                varchar(5) = "  " ,
    @DepositorsPhone                              varchar(25) = "  " ,
    @DepositorsEmail                              varchar(200) = "  " ,
    @SafeKeepingTicketNum                         varchar(30) = "  " ,
    @IccDepositorsPkey                            Int = 0 ,
    @DepositorsAttnLine1                          varchar(35) = "  " ,
    @DepositorsGtsPartyID                         varchar(18) = "  " ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into BalLocPledges(
    Pkey ,
    LocPrimaryPkey ,
    TransPkey ,
    ReplacePkey ,
    GtsAction ,
    PledgeID ,
    DepositorsPkey ,
    DepositorsName ,
    StartDate ,
    EndDate ,
    Amount ,
    Adjustment ,
    DepositorsAddress1 ,
    DepositorsAddress2 ,
    DepositorsAddress3 ,
    DepositorsZip ,
    DepositorsPhone ,
    DepositorsEmail ,
    SafeKeepingTicketNum ,
    IccDepositorsPkey ,
    DepositorsAttnLine1 ,
    DepositorsGtsPartyID ,
    UPDATABASE)
values (
    @Pkey ,
    @LocPrimaryPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @GtsAction ,
    @PledgeID ,
    @DepositorsPkey ,
    @DepositorsName ,
    @StartDate ,
    @EndDate ,
    @Amount ,
    @Adjustment ,
    @DepositorsAddress1 ,
    @DepositorsAddress2 ,
    @DepositorsAddress3 ,
    @DepositorsZip ,
    @DepositorsPhone ,
    @DepositorsEmail ,
    @SafeKeepingTicketNum ,
    @IccDepositorsPkey ,
    @DepositorsAttnLine1 ,
    @DepositorsGtsPartyID ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocPledgesupdate]'
GO

CREATE PROCEDURE [dbo].[BalLocPledgesupdate]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = " " ,
    @PledgeID                                     Int = 0 ,
    @DepositorsPkey                               Int = 0 ,
    @DepositorsName                               varchar(35) = " " ,
    @StartDate                                    DateTime = 0 ,
    @EndDate                                      DateTime = 0 ,
    @Amount                                       money = 0 ,
    @Adjustment                                   varchar(1) = " " ,
    @DepositorsAddress1                           varchar(35) = " " ,
    @DepositorsAddress2                           varchar(35) = " " ,
    @DepositorsAddress3                           varchar(35) = " " ,
    @DepositorsZip                                varchar(5) = " " ,
    @DepositorsPhone                              varchar(25) = " " ,
    @DepositorsEmail                              varchar(200) = " " ,
    @SafeKeepingTicketNum                         varchar(30) = " " ,
    @IccDepositorsPkey                            Int = 0 ,
    @DepositorsAttnLine1                          varchar(35) = " " ,
    @DepositorsGtsPartyID                         varchar(18) = " " ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update BalLocPledges set
    LocPrimaryPkey = @LocPrimaryPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    GtsAction = @GtsAction,
    PledgeID = @PledgeID,
    DepositorsPkey = @DepositorsPkey,
    DepositorsName = @DepositorsName,
    StartDate = @StartDate,
    EndDate = @EndDate,
    Amount = @Amount,
    Adjustment = @Adjustment,
    DepositorsAddress1 = @DepositorsAddress1,
    DepositorsAddress2 = @DepositorsAddress2,
    DepositorsAddress3 = @DepositorsAddress3,
    DepositorsZip = @DepositorsZip,
    DepositorsPhone = @DepositorsPhone,
    DepositorsEmail = @DepositorsEmail,
    SafeKeepingTicketNum = @SafeKeepingTicketNum,
    IccDepositorsPkey = @IccDepositorsPkey,
    DepositorsAttnLine1 = @DepositorsAttnLine1,
    DepositorsGtsPartyID = @DepositorsGtsPartyID,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainBalLocPledges]'
GO

CREATE PROCEDURE [dbo].[MainBalLocPledges]
            @Pkey                                         Int = 0 ,
            @LocPrimaryPkey                               Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @GtsAction                                    varchar(6) = "  " ,
            @PledgeID                                     Int = 0 ,
            @DepositorsPkey                               Int = 0 ,
            @DepositorsName                               varchar(35) = "  " ,
            @StartDate                                    DateTime = 0 ,
            @EndDate                                      DateTime = 0 ,
            @Amount                                       money = 0 ,
            @Adjustment                                   varchar(1) = "  " ,
            @DepositorsAddress1                           varchar(35) = "  " ,
            @DepositorsAddress2                           varchar(35) = "  " ,
            @DepositorsAddress3                           varchar(35) = "  " ,
            @DepositorsZip                                varchar(5) = "  " ,
            @DepositorsPhone                              varchar(25) = "  " ,
            @DepositorsEmail                              varchar(200) = "  " ,
            @SafeKeepingTicketNum                         varchar(30) = "  " ,
            @IccDepositorsPkey                            Int = 0 ,
            @DepositorsAttnLine1                          varchar(35) = "  " ,
            @DepositorsGtsPartyID                         varchar(18) = "  " ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from BalLocPledges with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = BalLocPledgesinsert
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @PledgeID                                      ,
        @DepositorsPkey                                ,
        @DepositorsName                                ,
        @StartDate                                     ,
        @EndDate                                       ,
        @Amount                                        ,
        @Adjustment                                    ,
        @DepositorsAddress1                            ,
        @DepositorsAddress2                            ,
        @DepositorsAddress3                            ,
        @DepositorsZip                                 ,
        @DepositorsPhone                               ,
        @DepositorsEmail                               ,
        @SafeKeepingTicketNum                          ,
        @IccDepositorsPkey                             ,
        @DepositorsAttnLine1                           ,
        @DepositorsGtsPartyID                          ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = BalLocPledgesupdate
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @PledgeID                                      ,
        @DepositorsPkey                                ,
        @DepositorsName                                ,
        @StartDate                                     ,
        @EndDate                                       ,
        @Amount                                        ,
        @Adjustment                                    ,
        @DepositorsAddress1                            ,
        @DepositorsAddress2                            ,
        @DepositorsAddress3                            ,
        @DepositorsZip                                 ,
        @DepositorsPhone                               ,
        @DepositorsEmail                               ,
        @SafeKeepingTicketNum                          ,
        @IccDepositorsPkey                             ,
        @DepositorsAttnLine1                           ,
        @DepositorsGtsPartyID                          ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[BalLocPledgesReadByPkey]'
GO

CREATE PROCEDURE [dbo].[BalLocPledgesReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from BalLocPledges where pkey = @pkey
            select @rPkey = Pkey from BalLocPledges where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocShippingPartiesDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[LocShippingPartiesDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from LocShippingParties where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocShippingPartiesInsert]'
GO

CREATE PROCEDURE [dbo].[LocShippingPartiesInsert]
    @Pkey                                         Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @PartyPkey                                    Int = 0 ,
    @Amount                                       money = 0 ,
    @AmountBase                                   money = 0 ,
    @CurrencyCode                                 varchar(3) = "  " ,
    @FxRate                                       Float = 0 ,
    @FreeForm                                     varchar(1) = "  " 
AS
Insert into LocShippingParties(
    TransPkey ,
    LocPrimaryPkey ,
    PartyPkey ,
    Amount ,
    AmountBase ,
    CurrencyCode ,
    FxRate ,
    FreeForm)
values (
    @TransPkey ,
    @LocPrimaryPkey ,
    @PartyPkey ,
    @Amount ,
    @AmountBase ,
    @CurrencyCode ,
    @FxRate ,
    @FreeForm)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocShippingPartiesupdate]'
GO

CREATE PROCEDURE [dbo].[LocShippingPartiesupdate]
    @Pkey                                         Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @PartyPkey                                    Int = 0 ,
    @Amount                                       money = 0 ,
    @AmountBase                                   money = 0 ,
    @CurrencyCode                                 varchar(3) = " " ,
    @FxRate                                       Float = 0 ,
    @FreeForm                                     varchar(1) = " " 
AS
Update LocShippingParties set
    TransPkey = @TransPkey,
    LocPrimaryPkey = @LocPrimaryPkey,
    PartyPkey = @PartyPkey,
    Amount = @Amount,
    AmountBase = @AmountBase,
    CurrencyCode = @CurrencyCode,
    FxRate = @FxRate,
    FreeForm = @FreeForm
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainLocShippingParties]'
GO

CREATE PROCEDURE [dbo].[MainLocShippingParties]
            @Pkey                                         Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @LocPrimaryPkey                               Int = 0 ,
            @PartyPkey                                    Int = 0 ,
            @Amount                                       money = 0 ,
            @AmountBase                                   money = 0 ,
            @CurrencyCode                                 varchar(3) = "  " ,
            @FxRate                                       Float = 0 ,
            @FreeForm                                     varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from LocShippingParties with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = LocShippingPartiesinsert
        @Pkey                                          ,
        @TransPkey                                     ,
        @LocPrimaryPkey                                ,
        @PartyPkey                                     ,
        @Amount                                        ,
        @AmountBase                                    ,
        @CurrencyCode                                  ,
        @FxRate                                        ,
        @FreeForm                                     

    End

    
    Else
    Begin
        Exec @lpkey = LocShippingPartiesupdate
        @Pkey                                          ,
        @TransPkey                                     ,
        @LocPrimaryPkey                                ,
        @PartyPkey                                     ,
        @Amount                                        ,
        @AmountBase                                    ,
        @CurrencyCode                                  ,
        @FxRate                                        ,
        @FreeForm                                     
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocShippingPartiesReadByPkey]'
GO

CREATE PROCEDURE [dbo].[LocShippingPartiesReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from LocShippingParties where pkey = @pkey
            select @rPkey = Pkey from LocShippingParties where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfTextDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[ScfTextDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from ScfText where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfTextInsert]'
GO

CREATE PROCEDURE [dbo].[ScfTextInsert]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GTSAction                                    varchar(6) = "  " ,
    @Active                                       Bit = 0 ,
    @TextType                                     Int = 0 ,
    @NumberBytes                                  Int = 0 ,
    @Description                                  varchar(MAX) = " " ,
    @Width                                        Int = 0 ,
    @CheckSwfChars                                varchar(1) = "  " ,
    @updatabase                                   varchar(1) = "  " 
AS
Insert into ScfText(
    ScfPrimaryPkey ,
    EventPkey ,
    TransPkey ,
    ReplacePkey ,
    GTSAction ,
    Active ,
    TextType ,
    NumberBytes ,
    Description ,
    Width ,
    CheckSwfChars ,
    updatabase)
values (
    @ScfPrimaryPkey ,
    @EventPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @GTSAction ,
    @Active ,
    @TextType ,
    @NumberBytes ,
    @Description ,
    @Width ,
    @CheckSwfChars ,
    @updatabase)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfTextupdate]'
GO

CREATE PROCEDURE [dbo].[ScfTextupdate]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GTSAction                                    varchar(6) = " " ,
    @Active                                       Bit = 0 ,
    @TextType                                     Int = 0 ,
    @NumberBytes                                  Int = 0 ,
    @Description                                  varchar(MAX) = " " ,
    @Width                                        Int = 0 ,
    @CheckSwfChars                                varchar(1) = " " ,
    @updatabase                                   varchar(1) = " " 
AS
Update ScfText set
    ScfPrimaryPkey = @ScfPrimaryPkey,
    EventPkey = @EventPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    GTSAction = @GTSAction,
    Active = @Active,
    TextType = @TextType,
    NumberBytes = @NumberBytes,
    Description = @Description,
    Width = @Width,
    CheckSwfChars = @CheckSwfChars,
    updatabase = @updatabase
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainScfText]'
GO

CREATE PROCEDURE [dbo].[MainScfText]
            @Pkey                                         Int = 0 ,
            @ScfPrimaryPkey                               Int = 0 ,
            @EventPkey                                    Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @GTSAction                                    varchar(6) = "  " ,
            @Active                                       Bit = 0 ,
            @TextType                                     Int = 0 ,
            @NumberBytes                                  Int = 0 ,
            @Description                                  varchar(MAX) = " " ,
            @Width                                        Int = 0 ,
            @CheckSwfChars                                varchar(1) = "  " ,
            @updatabase                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from ScfText with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = ScfTextinsert
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GTSAction                                     ,
        @Active                                        ,
        @TextType                                      ,
        @NumberBytes                                   ,
        @Description                                   ,
        @Width                                         ,
        @CheckSwfChars                                 ,
        @updatabase                                   

    End

    
    Else
    Begin
        Exec @lpkey = ScfTextupdate
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GTSAction                                     ,
        @Active                                        ,
        @TextType                                      ,
        @NumberBytes                                   ,
        @Description                                   ,
        @Width                                         ,
        @CheckSwfChars                                 ,
        @updatabase                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfTextIssRel]'
GO

CREATE PROCEDURE [dbo].[ScfTextIssRel]
    @OldPrimaryPkey    int

AS

            Insert into BalScfText Select
            ScfPrimaryPkey, 
            EventPkey, 
            TransPkey, 
            ReplacePkey, 
            GTSAction, 
            Active, 
            TextType, 
            NumberBytes, 
            Description, 
            Width, 
            CheckSwfChars, 
            updatabase 
            from ScfText where @oldprimarypkey = SCFPRIMARYPKEY
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ScfTextReadByPkey]'
GO

CREATE PROCEDURE [dbo].[ScfTextReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from ScfText where pkey = @pkey
            select @rPkey = Pkey from ScfText where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfTextInsert]'
GO

CREATE PROCEDURE [dbo].[ModelScfTextInsert]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GTSAction                                    varchar(6) = "  " ,
    @Active                                       Bit = 0 ,
    @TextType                                     Int = 0 ,
    @NumberBytes                                  Int = 0 ,
    @Description                                  varchar(MAX) = " " ,
    @Width                                        Int = 0 ,
    @CheckSwfChars                                varchar(1) = "  " ,
    @updatabase                                   varchar(1) = "  " 
AS
Insert into ModelScfText(
    ScfPrimaryPkey ,
    EventPkey ,
    TransPkey ,
    ReplacePkey ,
    GTSAction ,
    Active ,
    TextType ,
    NumberBytes ,
    Description ,
    Width ,
    CheckSwfChars ,
    updatabase)
values (
    @ScfPrimaryPkey ,
    @EventPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @GTSAction ,
    @Active ,
    @TextType ,
    @NumberBytes ,
    @Description ,
    @Width ,
    @CheckSwfChars ,
    @updatabase)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfTextupdate]'
GO

CREATE PROCEDURE [dbo].[ModelScfTextupdate]
    @Pkey                                         Int = 0 ,
    @ScfPrimaryPkey                               Int = 0 ,
    @EventPkey                                    Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GTSAction                                    varchar(6) = " " ,
    @Active                                       Bit = 0 ,
    @TextType                                     Int = 0 ,
    @NumberBytes                                  Int = 0 ,
    @Description                                  varchar(MAX) = " " ,
    @Width                                        Int = 0 ,
    @CheckSwfChars                                varchar(1) = " " ,
    @updatabase                                   varchar(1) = " " 
AS
Update ModelScfText set
    ScfPrimaryPkey = @ScfPrimaryPkey,
    EventPkey = @EventPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    GTSAction = @GTSAction,
    Active = @Active,
    TextType = @TextType,
    NumberBytes = @NumberBytes,
    Description = @Description,
    Width = @Width,
    CheckSwfChars = @CheckSwfChars,
    updatabase = @updatabase
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainModelScfText]'
GO

CREATE PROCEDURE [dbo].[MainModelScfText]
            @Pkey                                         Int = 0 ,
            @ScfPrimaryPkey                               Int = 0 ,
            @EventPkey                                    Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @GTSAction                                    varchar(6) = "  " ,
            @Active                                       Bit = 0 ,
            @TextType                                     Int = 0 ,
            @NumberBytes                                  Int = 0 ,
            @Description                                  varchar(MAX) = " " ,
            @Width                                        Int = 0 ,
            @CheckSwfChars                                varchar(1) = "  " ,
            @updatabase                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from ModelScfText with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = ModelScfTextinsert
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GTSAction                                     ,
        @Active                                        ,
        @TextType                                      ,
        @NumberBytes                                   ,
        @Description                                   ,
        @Width                                         ,
        @CheckSwfChars                                 ,
        @updatabase                                   

    End

    
    Else
    Begin
        Exec @lpkey = ModelScfTextupdate
        @Pkey                                          ,
        @ScfPrimaryPkey                                ,
        @EventPkey                                     ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GTSAction                                     ,
        @Active                                        ,
        @TextType                                      ,
        @NumberBytes                                   ,
        @Description                                   ,
        @Width                                         ,
        @CheckSwfChars                                 ,
        @updatabase                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfTextReadByPkey]'
GO

CREATE PROCEDURE [dbo].[ModelScfTextReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from ModelScfText where pkey = @pkey
            select @rPkey = Pkey from ModelScfText where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[ModelScfTextDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[ModelScfTextDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from ModelScfText where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteDDADeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[MetavanteDDADeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from MetavanteDDA where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteDDAInsert]'
GO

CREATE PROCEDURE [dbo].[MetavanteDDAInsert]
    @Pkey                                         Int = 0 ,
    @Transpkey                                    Int = 0 ,
    @RequestId                                    varchar(35) = "  " ,
    @DDANumber                                    varchar(20) = "  " ,
    @ReferenceNum                                 varchar(10) = "  " ,
    @RecType                                      varchar(3) = "  " ,
    @Transtatus                                   Int = 0 ,
    @PartyID                                      varchar(18) = "  " ,
    @Amount                                       money = 0 ,
    @IncDec                                       varchar(1) = "  " ,
    @ValueDate                                    DateTime = 0 ,
    @FXrate                                       Float = 0 ,
    @AuthorizeAmount                              money = 0 ,
    @OverRide                                     varchar(50) = "  " ,
    @Rejectreason                                 varchar(132) = "  " ,
    @Currency                                     varchar(3) = "  " ,
    @ProcessDate                                  DateTime = 0 ,
    @ErrorCode                                    Int = 0 ,
    @ErrorReasonCode                              varchar(50) = "  " ,
    @ErrorMsgNum                                  varchar(100) = "  " ,
    @ErrorMsgText                                 varchar(500) = "  " ,
    @ErrorMsgField                                varchar(100) = "  " ,
    @OutgoingMsgText                              varchar(MAX) = " " ,
    @ResponseMsgText                              varchar(MAX) = " " 
AS
Insert into MetavanteDDA(
    Transpkey ,
    RequestId ,
    DDANumber ,
    ReferenceNum ,
    RecType ,
    Transtatus ,
    PartyID ,
    Amount ,
    IncDec ,
    ValueDate ,
    FXrate ,
    AuthorizeAmount ,
    OverRide ,
    Rejectreason ,
    Currency ,
    ProcessDate ,
    ErrorCode ,
    ErrorReasonCode ,
    ErrorMsgNum ,
    ErrorMsgText ,
    ErrorMsgField ,
    OutgoingMsgText ,
    ResponseMsgText)
values (
    @Transpkey ,
    @RequestId ,
    @DDANumber ,
    @ReferenceNum ,
    @RecType ,
    @Transtatus ,
    @PartyID ,
    @Amount ,
    @IncDec ,
    @ValueDate ,
    @FXrate ,
    @AuthorizeAmount ,
    @OverRide ,
    @Rejectreason ,
    @Currency ,
    @ProcessDate ,
    @ErrorCode ,
    @ErrorReasonCode ,
    @ErrorMsgNum ,
    @ErrorMsgText ,
    @ErrorMsgField ,
    @OutgoingMsgText ,
    @ResponseMsgText)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteDDAupdate]'
GO

CREATE PROCEDURE [dbo].[MetavanteDDAupdate]
    @Pkey                                         Int = 0 ,
    @Transpkey                                    Int = 0 ,
    @RequestId                                    varchar(35) = " " ,
    @DDANumber                                    varchar(20) = " " ,
    @ReferenceNum                                 varchar(10) = " " ,
    @RecType                                      varchar(3) = " " ,
    @Transtatus                                   Int = 0 ,
    @PartyID                                      varchar(18) = " " ,
    @Amount                                       money = 0 ,
    @IncDec                                       varchar(1) = " " ,
    @ValueDate                                    DateTime = 0 ,
    @FXrate                                       Float = 0 ,
    @AuthorizeAmount                              money = 0 ,
    @OverRide                                     varchar(50) = " " ,
    @Rejectreason                                 varchar(132) = " " ,
    @Currency                                     varchar(3) = " " ,
    @ProcessDate                                  DateTime = 0 ,
    @ErrorCode                                    Int = 0 ,
    @ErrorReasonCode                              varchar(50) = " " ,
    @ErrorMsgNum                                  varchar(100) = " " ,
    @ErrorMsgText                                 varchar(500) = " " ,
    @ErrorMsgField                                varchar(100) = " " ,
    @OutgoingMsgText                              varchar(MAX) = " " ,
    @ResponseMsgText                              varchar(MAX) = " " 
AS
Update MetavanteDDA set
    Transpkey = @Transpkey,
    RequestId = @RequestId,
    DDANumber = @DDANumber,
    ReferenceNum = @ReferenceNum,
    RecType = @RecType,
    Transtatus = @Transtatus,
    PartyID = @PartyID,
    Amount = @Amount,
    IncDec = @IncDec,
    ValueDate = @ValueDate,
    FXrate = @FXrate,
    AuthorizeAmount = @AuthorizeAmount,
    OverRide = @OverRide,
    Rejectreason = @Rejectreason,
    Currency = @Currency,
    ProcessDate = @ProcessDate,
    ErrorCode = @ErrorCode,
    ErrorReasonCode = @ErrorReasonCode,
    ErrorMsgNum = @ErrorMsgNum,
    ErrorMsgText = @ErrorMsgText,
    ErrorMsgField = @ErrorMsgField,
    OutgoingMsgText = @OutgoingMsgText,
    ResponseMsgText = @ResponseMsgText
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainMetavanteDDA]'
GO

CREATE PROCEDURE [dbo].[MainMetavanteDDA]
            @Pkey                                         Int = 0 ,
            @Transpkey                                    Int = 0 ,
            @RequestId                                    varchar(35) = "  " ,
            @DDANumber                                    varchar(20) = "  " ,
            @ReferenceNum                                 varchar(10) = "  " ,
            @RecType                                      varchar(3) = "  " ,
            @Transtatus                                   Int = 0 ,
            @PartyID                                      varchar(18) = "  " ,
            @Amount                                       money = 0 ,
            @IncDec                                       varchar(1) = "  " ,
            @ValueDate                                    DateTime = 0 ,
            @FXrate                                       Float = 0 ,
            @AuthorizeAmount                              money = 0 ,
            @OverRide                                     varchar(50) = "  " ,
            @Rejectreason                                 varchar(132) = "  " ,
            @Currency                                     varchar(3) = "  " ,
            @ProcessDate                                  DateTime = 0 ,
            @ErrorCode                                    Int = 0 ,
            @ErrorReasonCode                              varchar(50) = "  " ,
            @ErrorMsgNum                                  varchar(100) = "  " ,
            @ErrorMsgText                                 varchar(500) = "  " ,
            @ErrorMsgField                                varchar(100) = "  " ,
            @OutgoingMsgText                              varchar(MAX) = " " ,
            @ResponseMsgText                              varchar(MAX) = " " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from MetavanteDDA with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = MetavanteDDAinsert
        @Pkey                                          ,
        @Transpkey                                     ,
        @RequestId                                     ,
        @DDANumber                                     ,
        @ReferenceNum                                  ,
        @RecType                                       ,
        @Transtatus                                    ,
        @PartyID                                       ,
        @Amount                                        ,
        @IncDec                                        ,
        @ValueDate                                     ,
        @FXrate                                        ,
        @AuthorizeAmount                               ,
        @OverRide                                      ,
        @Rejectreason                                  ,
        @Currency                                      ,
        @ProcessDate                                   ,
        @ErrorCode                                     ,
        @ErrorReasonCode                               ,
        @ErrorMsgNum                                   ,
        @ErrorMsgText                                  ,
        @ErrorMsgField                                 ,
        @OutgoingMsgText                               ,
        @ResponseMsgText                              

    End

    
    Else
    Begin
        Exec @lpkey = MetavanteDDAupdate
        @Pkey                                          ,
        @Transpkey                                     ,
        @RequestId                                     ,
        @DDANumber                                     ,
        @ReferenceNum                                  ,
        @RecType                                       ,
        @Transtatus                                    ,
        @PartyID                                       ,
        @Amount                                        ,
        @IncDec                                        ,
        @ValueDate                                     ,
        @FXrate                                        ,
        @AuthorizeAmount                               ,
        @OverRide                                      ,
        @Rejectreason                                  ,
        @Currency                                      ,
        @ProcessDate                                   ,
        @ErrorCode                                     ,
        @ErrorReasonCode                               ,
        @ErrorMsgNum                                   ,
        @ErrorMsgText                                  ,
        @ErrorMsgField                                 ,
        @OutgoingMsgText                               ,
        @ResponseMsgText                              
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteDDAReadByPkey]'
GO

CREATE PROCEDURE [dbo].[MetavanteDDAReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from MetavanteDDA where pkey = @pkey
            select @rPkey = Pkey from MetavanteDDA where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteLoansDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[MetavanteLoansDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from MetavanteLoans where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteLoansInsert]'
GO

CREATE PROCEDURE [dbo].[MetavanteLoansInsert]
    @Pkey                                         Int = 0 ,
    @Transpkey                                    Int = 0 ,
    @RequestId                                    varchar(35) = "  " ,
    @Commitnumber                                 varchar(35) = "  " ,
    @ReferenceNum                                 varchar(10) = "  " ,
    @RecType                                      varchar(3) = "  " ,
    @Transtatus                                   Int = 0 ,
    @PartyID                                      varchar(18) = "  " ,
    @Amount                                       money = 0 ,
    @ValueDate                                    DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @FXrate                                       Float = 0 ,
    @OverRide                                     varchar(50) = "  " ,
    @Rejectreason                                 varchar(132) = "  " ,
    @LoanState                                    varchar(50) = "  " ,
    @Currency                                     varchar(3) = "  " ,
    @IncDec                                       varchar(2) = "  " ,
    @ProcessDate                                  DateTime = 0 ,
    @ErrorCode                                    Int = 0 ,
    @ErrorReasonCode                              varchar(50) = "  " ,
    @ErrorMsgNum                                  varchar(100) = "  " ,
    @ErrorMsgText                                 varchar(500) = "  " ,
    @ErrorMsgField                                varchar(100) = "  " ,
    @OutgoingMsgText                              varchar(MAX) = " " ,
    @ResponseMsgText                              varchar(MAX) = " " 
AS
Insert into MetavanteLoans(
    Transpkey ,
    RequestId ,
    Commitnumber ,
    ReferenceNum ,
    RecType ,
    Transtatus ,
    PartyID ,
    Amount ,
    ValueDate ,
    MaturityDate ,
    FXrate ,
    OverRide ,
    Rejectreason ,
    LoanState ,
    Currency ,
    IncDec ,
    ProcessDate ,
    ErrorCode ,
    ErrorReasonCode ,
    ErrorMsgNum ,
    ErrorMsgText ,
    ErrorMsgField ,
    OutgoingMsgText ,
    ResponseMsgText)
values (
    @Transpkey ,
    @RequestId ,
    @Commitnumber ,
    @ReferenceNum ,
    @RecType ,
    @Transtatus ,
    @PartyID ,
    @Amount ,
    @ValueDate ,
    @MaturityDate ,
    @FXrate ,
    @OverRide ,
    @Rejectreason ,
    @LoanState ,
    @Currency ,
    @IncDec ,
    @ProcessDate ,
    @ErrorCode ,
    @ErrorReasonCode ,
    @ErrorMsgNum ,
    @ErrorMsgText ,
    @ErrorMsgField ,
    @OutgoingMsgText ,
    @ResponseMsgText)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteLoansupdate]'
GO

CREATE PROCEDURE [dbo].[MetavanteLoansupdate]
    @Pkey                                         Int = 0 ,
    @Transpkey                                    Int = 0 ,
    @RequestId                                    varchar(35) = " " ,
    @Commitnumber                                 varchar(35) = " " ,
    @ReferenceNum                                 varchar(10) = " " ,
    @RecType                                      varchar(3) = " " ,
    @Transtatus                                   Int = 0 ,
    @PartyID                                      varchar(18) = " " ,
    @Amount                                       money = 0 ,
    @ValueDate                                    DateTime = 0 ,
    @MaturityDate                                 DateTime = 0 ,
    @FXrate                                       Float = 0 ,
    @OverRide                                     varchar(50) = " " ,
    @Rejectreason                                 varchar(132) = " " ,
    @LoanState                                    varchar(50) = " " ,
    @Currency                                     varchar(3) = " " ,
    @IncDec                                       varchar(2) = " " ,
    @ProcessDate                                  DateTime = 0 ,
    @ErrorCode                                    Int = 0 ,
    @ErrorReasonCode                              varchar(50) = " " ,
    @ErrorMsgNum                                  varchar(100) = " " ,
    @ErrorMsgText                                 varchar(500) = " " ,
    @ErrorMsgField                                varchar(100) = " " ,
    @OutgoingMsgText                              varchar(MAX) = " " ,
    @ResponseMsgText                              varchar(MAX) = " " 
AS
Update MetavanteLoans set
    Transpkey = @Transpkey,
    RequestId = @RequestId,
    Commitnumber = @Commitnumber,
    ReferenceNum = @ReferenceNum,
    RecType = @RecType,
    Transtatus = @Transtatus,
    PartyID = @PartyID,
    Amount = @Amount,
    ValueDate = @ValueDate,
    MaturityDate = @MaturityDate,
    FXrate = @FXrate,
    OverRide = @OverRide,
    Rejectreason = @Rejectreason,
    LoanState = @LoanState,
    Currency = @Currency,
    IncDec = @IncDec,
    ProcessDate = @ProcessDate,
    ErrorCode = @ErrorCode,
    ErrorReasonCode = @ErrorReasonCode,
    ErrorMsgNum = @ErrorMsgNum,
    ErrorMsgText = @ErrorMsgText,
    ErrorMsgField = @ErrorMsgField,
    OutgoingMsgText = @OutgoingMsgText,
    ResponseMsgText = @ResponseMsgText
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainMetavanteLoans]'
GO

CREATE PROCEDURE [dbo].[MainMetavanteLoans]
            @Pkey                                         Int = 0 ,
            @Transpkey                                    Int = 0 ,
            @RequestId                                    varchar(35) = "  " ,
            @Commitnumber                                 varchar(35) = "  " ,
            @ReferenceNum                                 varchar(10) = "  " ,
            @RecType                                      varchar(3) = "  " ,
            @Transtatus                                   Int = 0 ,
            @PartyID                                      varchar(18) = "  " ,
            @Amount                                       money = 0 ,
            @ValueDate                                    DateTime = 0 ,
            @MaturityDate                                 DateTime = 0 ,
            @FXrate                                       Float = 0 ,
            @OverRide                                     varchar(50) = "  " ,
            @Rejectreason                                 varchar(132) = "  " ,
            @LoanState                                    varchar(50) = "  " ,
            @Currency                                     varchar(3) = "  " ,
            @IncDec                                       varchar(2) = "  " ,
            @ProcessDate                                  DateTime = 0 ,
            @ErrorCode                                    Int = 0 ,
            @ErrorReasonCode                              varchar(50) = "  " ,
            @ErrorMsgNum                                  varchar(100) = "  " ,
            @ErrorMsgText                                 varchar(500) = "  " ,
            @ErrorMsgField                                varchar(100) = "  " ,
            @OutgoingMsgText                              varchar(MAX) = " " ,
            @ResponseMsgText                              varchar(MAX) = " " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from MetavanteLoans with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = MetavanteLoansinsert
        @Pkey                                          ,
        @Transpkey                                     ,
        @RequestId                                     ,
        @Commitnumber                                  ,
        @ReferenceNum                                  ,
        @RecType                                       ,
        @Transtatus                                    ,
        @PartyID                                       ,
        @Amount                                        ,
        @ValueDate                                     ,
        @MaturityDate                                  ,
        @FXrate                                        ,
        @OverRide                                      ,
        @Rejectreason                                  ,
        @LoanState                                     ,
        @Currency                                      ,
        @IncDec                                        ,
        @ProcessDate                                   ,
        @ErrorCode                                     ,
        @ErrorReasonCode                               ,
        @ErrorMsgNum                                   ,
        @ErrorMsgText                                  ,
        @ErrorMsgField                                 ,
        @OutgoingMsgText                               ,
        @ResponseMsgText                              

    End

    
    Else
    Begin
        Exec @lpkey = MetavanteLoansupdate
        @Pkey                                          ,
        @Transpkey                                     ,
        @RequestId                                     ,
        @Commitnumber                                  ,
        @ReferenceNum                                  ,
        @RecType                                       ,
        @Transtatus                                    ,
        @PartyID                                       ,
        @Amount                                        ,
        @ValueDate                                     ,
        @MaturityDate                                  ,
        @FXrate                                        ,
        @OverRide                                      ,
        @Rejectreason                                  ,
        @LoanState                                     ,
        @Currency                                      ,
        @IncDec                                        ,
        @ProcessDate                                   ,
        @ErrorCode                                     ,
        @ErrorReasonCode                               ,
        @ErrorMsgNum                                   ,
        @ErrorMsgText                                  ,
        @ErrorMsgField                                 ,
        @OutgoingMsgText                               ,
        @ResponseMsgText                              
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MetavanteLoansReadByPkey]'
GO

CREATE PROCEDURE [dbo].[MetavanteLoansReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from MetavanteLoans where pkey = @pkey
            select @rPkey = Pkey from MetavanteLoans where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtilDeleteByPkey]'
GO

CREATE PROCEDURE [dbo].[LocCertOfUtilDeleteByPkey]
            @Pkey    int
    As
            Declare @rPkey as int
            delete from LocCertOfUtil where Pkey = @pkey

            Return (@@rowcount)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtilInsert]'
GO

CREATE PROCEDURE [dbo].[LocCertOfUtilInsert]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = "  " ,
    @UtilizedAmount                               money = 0 ,
    @AverageDailyBalance                          money = 0 ,
    @CollateralizationPercentage                  Float = 0 ,
    @UPDATABASE                                   varchar(1) = "  " 
AS
Insert into LocCertOfUtil(
    Pkey ,
    LocPrimaryPkey ,
    TransPkey ,
    ReplacePkey ,
    GtsAction ,
    UtilizedAmount ,
    AverageDailyBalance ,
    CollateralizationPercentage ,
    UPDATABASE)
values (
    @Pkey ,
    @LocPrimaryPkey ,
    @TransPkey ,
    @ReplacePkey ,
    @GtsAction ,
    @UtilizedAmount ,
    @AverageDailyBalance ,
    @CollateralizationPercentage ,
    @UPDATABASE)

Return (@@identity)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtilupdate]'
GO

CREATE PROCEDURE [dbo].[LocCertOfUtilupdate]
    @Pkey                                         Int = 0 ,
    @LocPrimaryPkey                               Int = 0 ,
    @TransPkey                                    Int = 0 ,
    @ReplacePkey                                  Int = 0 ,
    @GtsAction                                    varchar(6) = " " ,
    @UtilizedAmount                               money = 0 ,
    @AverageDailyBalance                          money = 0 ,
    @CollateralizationPercentage                  Float = 0 ,
    @UPDATABASE                                   varchar(1) = " " 
AS
Update LocCertOfUtil set
    LocPrimaryPkey = @LocPrimaryPkey,
    TransPkey = @TransPkey,
    ReplacePkey = @ReplacePkey,
    GtsAction = @GtsAction,
    UtilizedAmount = @UtilizedAmount,
    AverageDailyBalance = @AverageDailyBalance,
    CollateralizationPercentage = @CollateralizationPercentage,
    UPDATABASE = @UPDATABASE
        Where Pkey = @Pkey
Return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[MainLocCertOfUtil]'
GO

CREATE PROCEDURE [dbo].[MainLocCertOfUtil]
            @Pkey                                         Int = 0 ,
            @LocPrimaryPkey                               Int = 0 ,
            @TransPkey                                    Int = 0 ,
            @ReplacePkey                                  Int = 0 ,
            @GtsAction                                    varchar(6) = "  " ,
            @UtilizedAmount                               money = 0 ,
            @AverageDailyBalance                          money = 0 ,
            @CollateralizationPercentage                  Float = 0 ,
            @UPDATABASE                                   varchar(1) = "  " 
AS
    declare @lpkey integer
    select @lpkey = -1
    select @lpkey = pkey  from LocCertOfUtil with (nolock) where @pkey = pkey

    If @lpkey = -1
    Begin
        Exec @lpkey = LocCertOfUtilinsert
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @UtilizedAmount                                ,
        @AverageDailyBalance                           ,
        @CollateralizationPercentage                   ,
        @UPDATABASE                                   

    End

    
    Else
    Begin
        Exec @lpkey = LocCertOfUtilupdate
        @Pkey                                          ,
        @LocPrimaryPkey                                ,
        @TransPkey                                     ,
        @ReplacePkey                                   ,
        @GtsAction                                     ,
        @UtilizedAmount                                ,
        @AverageDailyBalance                           ,
        @CollateralizationPercentage                   ,
        @UPDATABASE                                   
    end
    Return (@lpkey)

GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtilIssRel]'
GO

CREATE PROCEDURE [dbo].[LocCertOfUtilIssRel]
    @OldPrimaryPkey    int

AS

            Insert into BalLocCertOfUtil Select
            Pkey, 
            LocPrimaryPkey, 
            TransPkey, 
            ReplacePkey, 
            GtsAction, 
            UtilizedAmount, 
            AverageDailyBalance, 
            CollateralizationPercentage, 
            UPDATABASE 
            from LocCertOfUtil where @oldprimarypkey = LOCPRIMARYPkey
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtilMove]'
GO

CREATE PROCEDURE [dbo].[LocCertOfUtilMove]
    @LocPkey    int,
    @TPkey    int

AS

    Declare
    @Pkey                                         Int, 
    @LocPrimaryPkey                               Int, 
    @TransPkey                                    Int, 
    @ReplacePkey                                  Int, 
    @GtsAction                                    varchar(6), 
    @UtilizedAmount                               money, 
    @AverageDailyBalance                          money, 
    @CollateralizationPercentage                  Float, 
    @UPDATABASE                                   varchar(1) 
    declare @done as int
    select @done = -1

    Declare LocCertOfUtil Cursor for select * from LocCertOfUtil
         Where @tpkey = Transpkey
    Open LocCertOfUtil

    while @done = -1
    Begin
        fetch next from LocCertOfUtil Into 
        @Pkey ,
        @LocPrimaryPkey ,
        @TransPkey ,
        @ReplacePkey ,
        @GtsAction ,
        @UtilizedAmount ,
        @AverageDailyBalance ,
        @CollateralizationPercentage ,
        @UPDATABASE

        If @@fetch_status = 0
        Begin
            if @GTSaction = 'ADD' 
                Begin
                    Insert into BalLocCertOfUtil(
                        Pkey ,
                        LocPrimaryPkey ,
                        TransPkey ,
                        ReplacePkey ,
                        GtsAction ,
                        UtilizedAmount ,
                        AverageDailyBalance ,
                        CollateralizationPercentage ,
                        UPDATABASE)
values (
                        @Pkey ,
                        @LocPrimaryPkey ,
                        @TransPkey ,
                        @ReplacePkey ,
                        @GtsAction ,
                        @UtilizedAmount ,
                        @AverageDailyBalance ,
                        @CollateralizationPercentage ,
                        @UPDATABASE)

                END

            IF @GTSACTION = 'AMEND'
                BEGIN
                    update  BalLocCertOfUtil set 
                        LocPrimaryPkey = @LocPrimaryPkey, 
                        TransPkey = @TransPkey, 
                        ReplacePkey = @ReplacePkey, 
                        GtsAction = @GtsAction, 
                        UtilizedAmount = @UtilizedAmount, 
                        AverageDailyBalance = @AverageDailyBalance, 
                        CollateralizationPercentage = @CollateralizationPercentage, 
                        UPDATABASE = @UPDATABASE 
                            where pkey = @Replacepkey
                End

            if @GTSaction = 'DELETE' 
                Begin
                    Delete From BalLocCertOfUtil where pkey = @Replacepkey

                END

            End

            if @@fetch_status <> 0 select @done = 0

    end
    close LocCertOfUtil
    return (@@error)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
PRINT N'Creating [dbo].[LocCertOfUtilReadByPkey]'
GO

CREATE PROCEDURE [dbo].[LocCertOfUtilReadByPkey]
            @Pkey    int
    As
            Declare @rPkey AS int
            Select @rPkey = 0
            Select * from LocCertOfUtil where pkey = @pkey
            select @rPkey = Pkey from LocCertOfUtil where pkey = @pkey

            Return (@rpkey)
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
COMMIT TRANSACTION
GO
IF @@ERROR <> 0 SET NOEXEC ON
GO
DECLARE @Success AS BIT
SET @Success = 1
SET NOEXEC OFF
IF (@Success = 1) PRINT 'The database update succeeded'
ELSE BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
	PRINT 'The database update failed'
END
GO
