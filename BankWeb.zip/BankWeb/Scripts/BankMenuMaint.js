// var BTNBACK = 0
// var BTNADDNEW = 1
// var BTNUPDATE = 2
// var BTNDELETE = 3

////////////////////////////////////////////////////////////////
// function to validate a field on a form for bank maint
function Validate(form, button){
	var iIndex = 0

	switch (button) {
		case 2:  // BTNUPDATE
		case 3:  // BTNDELETE
			iIndex = form.lstMenuItems.selectedIndex
			if (iIndex <= 0) {							// 0 is for Add new
				alert ("Bank function selection is required")
				form.lstMenuItems.focus();
				return (false);
			}
			break;
	}
	
	switch (button) {
		case 1:  // BTNADDNEW
		case 2:  // BTNUPDATE
		   if(!CheckRequired(form.txtDescription))
		      return(false);

		   if(!CheckRequired(form.txtURL))
		      return(false);

		   if(!CheckRequired(form.txtOrderBy))
		      return(false);
		        
		   if (!chkNumeric(form.txtOrderBy)) {
		   	alert ("Order By must be numeric.")
		   	form.txtOrderBy.focus()
		   	return (false)
		   }

			break;
	}
	
	return(true);
}

function BankMenuMaint_Submit(form, button){
	var bOk
	
	switch(button) 	{
		case 0:  // BTNBACK												
			// cancel button pressed, now handled in submit routine
			//document.location = "../bank.asp";	
			// so that session variables can be cleared
			//return (false);
			break;

		case 1:  // BTNADDNEW
			if(!Validate(form, button)) {
				return (false);
			}
			break;
			
		case 2:  // BTNUPDATE
			if(!Validate(form, button)) {
				return (false);
			}
			break;
			
		case 3:  // BTNDELETE
			if(!Validate(form, button)) {
				return (false);
			}
			bOk = confirm("Do you really want to delete this Menu Item ?")
			if (bOk == false) {
				return (false)
			}
			break;

		case 11:  // BTNCOPY
			break;
			
		default:
			alert ("Button " + button + " not implemented.")
			return (false);
			break;
	}
	form.txtAction.value = button
	form.submit();
}

function BankChanged() {
	var iIndex
	var sLe
	
	// this list box does not have an empty option
	// so we always use the selectedIndex
	iIndex = document.BankMenuMaint.lstBanks.selectedIndex
	
	sLe = document.BankMenuMaint.lstBanks[iIndex].value

	document.location = "BankMenuMaint.asp?WCI=BankMenuMaint" + "&Le=" + sLe + "&clr=Y"
}


function MenuItemChanged() {
	var sLe
	var sPKey
	var iIndex
	var sMore
	
	sPKey = ""
	iIndex = -1
	sMore = ""
	
	// this list box does not have an empty option
	// so we always use the selectedIndex
	iIndex = document.BankMenuMaint.lstBanks.selectedIndex
	sLe = document.BankMenuMaint.lstBanks[iIndex].value
	sMore = sMore + "&Le=" + sLe

	// this list box does not have an empty option
	// so we always use the selectedIndex
	iIndex = document.BankMenuMaint.lstMenuItems.selectedIndex
	sPKey = document.BankMenuMaint.lstMenuItems[iIndex].value
	sMore = sMore + "&PKey=" + sPKey

	document.location = "BankMenuMaint.asp?WCI=BankMenuMaint" + sMore + "&clr=Y"
}

//********************************************************************************
// 2. THIS SECTION IS FOR THE BankMenuMaintCopy HTML page
//********************************************************************************
function SaveFromStuff(form) {
	var sMore
	
	sMore = SetQueryFromList(form.lstBanks(0), "&srcBankId=")
	sMore = sMore + SetQueryFromChkBoxList(form.chkFunctions,"&srcFunctions=")
	
	return (sMore)
}

function SaveToStuff(form) {
	var sMore
	
	sMore = SetQueryFromList(form.lstBanks(1), "&dstBankId=")

	return (sMore)
}


// var COPY_FROM_CHANGED = 0
// var COPY_TO_CHANGED = 1
//********************************************************************************
// If the user selects a bank...
//--------------------------------------------------------------------------------
function CopyBankChanged(form,iToOrFrom) {
	var sMore
	
	sMore = ""
	
	switch (iToOrFrom) {
		case 0:  // COPY_FROM_CHANGED
			// save all the Destination information
			// pass the new src Bank id on the URL
			sMore = SaveToStuff(form) + SetQueryFromList(form.lstBanks(0), "&srcBankId=")
			break;
			
		case 1:  // COPY_TO_CHANGED
			// save all the Source information
			// pass the new dest Bank id on the URL
			sMore = SaveFromStuff(form) + SetQueryFromList(form.lstBanks(1), "&dstBankId=") 
			break;
			
		default:
			break;
	}
	
	//sMore = sMore + REQ_CLEAR

	document.location = "BankMenuMaint.asp?WCI=BankMenuMaintCopy" + sMore 
}

//********************************************************************************
// Submit
//--------------------------------------------------------------------------------
function BankMenuMaintCopy_Submit(form, button){
	switch (button) {
		case 0:  // BTNBACK
			break;
			
		case 11:  // BTNCOPY
			break;
			
		default:
			alert ("Button " + button + " not implemented.")
			return (false);
			break;
	}
	
	form.txtAction.value = button
	form.submit();
}
