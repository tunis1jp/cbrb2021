/* *************************************************** */
/* Alter LCApplication Table Drop Unique Constraints  */
/* ************************************************** */
BEGIN TRY
	BEGIN TRAN
		IF  EXISTS (
            Select COLUMN_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE 
			where TABLE_NAME = 'LCApplication' and CONSTRAINT_NAME = 'IX_LcApplication'
            )
		BEGIN
			ALTER TABLE LCApplication DROP CONSTRAINT IX_LcApplication;
			print 'Unique Constraints dropped from LCApplication table'
		END
		ELSE BEGIN
			print 'Unique Constraints already dropped from LCApplication table'
		END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback TRAN
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE() 
END CATCH
