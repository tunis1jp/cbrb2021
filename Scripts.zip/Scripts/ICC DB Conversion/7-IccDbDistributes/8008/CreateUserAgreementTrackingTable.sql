/*
	User Tracking tables-every user gets 1 of these for each possible GtsService-GtsFunction combination:
	UserEntitled is based on individual user entitlement=>this should be maintained by UserMaint function
*/
IF NOT EXISTS (SELECT *
           FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_TYPE='BASE TABLE' 
           AND TABLE_NAME='UserAgreementTracking') BEGIN
	CREATE TABLE UserAgreementTracking(
		PKey INT Constraint PK_UserAgreementTracking_PKey PRIMARY KEY IDENTITY(1,1) NOT NULL,
		UserPKey INT NOT NULL CONSTRAINT DF_UserAgreementTracking_UserPKey DEFAULT (0),
		AgreementFilePKey INT NOT NULL CONSTRAINT DF_UserAgreementTracking_AgreementFilePKey DEFAULT (0),
		GtsService varchar(4) NOT NULL CONSTRAINT DF_UserAgreementTracking_GtsService DEFAULT (''),
		UserEntitled varchar(1) NOT NULL CONSTRAINT DF_UserAgreementTracking_UserEntitled DEFAULT ('N'),
		AgreementVerified varchar(1) NOT NULL CONSTRAINT DF_UserAgreementTracking_AgreementVerified DEFAULT ('N'),
		VerifiedDate datetime NOT NULL CONSTRAINT DF_UserAgreementTracking_VerifiedDate  DEFAULT (1/1/1900)
	);
	
CREATE  INDEX IX_UserAgreementTracking_UserPKey ON UserAgreementTracking(UserPKey);
CREATE  INDEX IX_UserAgreementTracking_AgreementFilePKey ON UserAgreementTracking(AgreementFilePKey);
CREATE  INDEX IX_UserAgreementTracking_GtsService ON UserAgreementTracking(GtsService);
	
	print 'Created UserAgreementTracking table'
END
ELSE BEGIN
	print 'UserAgreementTracking table already exists in this DB'
END
