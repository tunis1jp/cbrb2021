delete CustomScreen
where Product in ('MT760freefrm', 'MT767freefrm')