function VerifyDelete(ThisWhatever) {
    return (confirm("Do you really want to delete this " + ThisWhatever + "?"));
}

/////////////////////////////////////////////////////////////////////////////
// appExit() - close browser (aka. exit application)
//
function appExit()
{
	window.close();
}

//-------------------------------------------------------------------
// Function added by DCB to display help in a new window.
// Feel free to tweak this to improve the appearance.
// --dependent doesn't do what I had hoped...
//-------------------------------------------------------------------
function ShowHelp (sThisPage) {
	var helpWindow

	helpWindow = window.open(sThisPage,'Help',"resizable,scrollbars,HEIGHT=600,WIDTH=600")
}

function CloseHelp () {
	self.close()
}

//* Added this function to check for invalid characters in the saving of report names.
function chkReportValChars(field, sDescription) {
    var sValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_?:. &"
    var sMsg = '';

    sMsg = FindInvalidChars(field, sValidChars)
    if (sMsg != "") {
        sMsg = "The " + sDescription + " data includes the following disallowed character(s):\n" + sMsg + "\n Please replace these before continuing."
        alert(sMsg);
        field.focus();
        return (false)
    }
    else {
        return (true);
    }
}

function SelectAll(chkBox, sClass) {
    var chkValue;
    var chkCategory;
    var chkAll;
    var iCnt;
    
    chkValue = chkBox.checked;
    
    chkCategory = document.getElementsByName("chkCategory");
	iCnt = chkCategory.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        if ((sClass == 'ALL') || (chkCategory[iIdx].className == sClass)) {
            chkCategory[iIdx].checked = chkValue;
        }
    }

    chkAll = document.getElementsByName("chkall");
	iCnt = chkAll.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        if ((sClass == 'ALL') || (chkAll[iIdx].className == sClass)) {
            chkAll[iIdx].checked = chkValue;
        }
    }
}

function SetQueryFromChkBoxList(objChkBox,sQueryKey) {
	var iLen
	var j
	var sResult
	var bAddComma
	
	sResult = ""
	
	if (objChkBox != null) {
		iLen = objChkBox.length		// this is for an array of check boxes
		if (iLen == null)		
			iLen = 1						// there is only the 1 check box
			
		switch (iLen) {
			case 0:
				break;
				
			case 1:
				if (objChkBox.checked)
					sResult = objChkBox.value
				break;
				
			default:
				bAddComma = false
				
				for (j = 0; j < iLen; j++) {
					if (objChkBox(j).checked) {
						if (bAddComma) {
							sResult = sResult + ","
						}
						else {
							bAddComma = true
						}
						sResult = sResult + objChkBox(j).value
					}
				}
				break;
		}
	}
	if (sResult != "")
		sResult = sQueryKey + sResult
		
	return (sResult)
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
function SetQueryFromList(oListObject,sQueryKey) {
	var sId
	var iIndex
	
	sId = ""
	iIndex = -1
	
	// save customer id
	// this list box does not have an empty option
	// so we always use the selectedIndex
	if (oListObject != null) {
		iIndex = oListObject.selectedIndex
		
		sId = sQueryKey + oListObject[iIndex].value
	}
	
	return (sId)
}

function objExists (objThis) {
	if (objThis != null) {
		return (true)
	}
	return(false)
}

//----------------------------------------------------------------------
// Check to see if an object is hidden
//----------------------------------------------------------------------
function objHidden (objThis) {
	if (objThis.type == "hidden") {
		return (true)
	}
	return (false)
}

//----------------------------------------------------------------------
// Let's have 1 PosCursor for all the simplest cases
//----------------------------------------------------------------------
function PosCursor(objHere) {
	if (objHere != null) {
		if (! objHidden(objHere)) {
			objHere.focus();
			return (true)
		}
	}
	return (false)
}

// 'global' vars
var sOrgColor;			// original color of text element

// pop up a message box with a lame excuse why this isn't done ;)
function showNoDemo() {
    window.alert("Feature under construction.");
}

////////////////////////////////////////////////////////////////
// CheckRequired() - check the length of a field, if zero, fail
function CheckRequired(field,sDesc) {
	if(field.value.length == 0) {
		// tell 'em to enter something!
		if (sDesc == null) {
			window.alert("You must enter the required field");
			if(CheckRequired.arguments.length < 2)
				field.focus();          // take 'em to that field
		}
		else {
			window.alert(sDesc + " is a required field.");
			if(CheckRequired.arguments.length < 3)
				field.focus();          // take 'em to that field
		}
	  
	  return(false);
	}
	
	return(true);
}
////////////////////////////////////////////////////////////////
// function check for spaces in a field if found return false
function chkSpaces (field) {
	var achar
	
	for (var i = 1; i <= field.value.length; i++)  {
		achar = field.value.charAt(i);
		
		if (achar != " ") {
			return ( false );
		}

	}

	return ( true );
}

// check if a field is numeric return false if not
function IsNumeric(field) {
	if(field.value.length == 0)
		return(true);

	var sData = null
	var nopt = IsNumeric.arguments.length
	if (nopt == 2)
	// if second parameter then it is a string and check it
		 sData  = IsNumeric.arguments[1];

	if (sData != null) {
		if (isNaN(sData)) {
			return (false);
		}
		else {
			return (true)
		}
	}


	if (isNaN(field.value)) {
		alert ("Numeric is required");
		field.focus();
		return (false);
	}
	
	return(true);
}

// function check for dollar amounts in a field if found return true
function chkAmount (field) {
	if(field.value.length == 0)
		return(true);

	var decplaces = null
	var nopt = chkAmount.arguments.length
	
	if (nopt == 2)
		 decplaces = chkAmount.arguments[1];

	var comma = null
	var decpos = 0
	var x = ",.1234567890"
	var ws = null
	var nc = 0
	var lenck = 0
// check comma position
	ws = field.value
// the first comma can be anywhere
	var i = ws.indexOf(",")
	
	if (i > 0) {
		nc = 1;
	
		while (true) {
			nc = nc + 1
			comma = word(",",nc,ws)
			lenck = 3
	// account there may 2 decimal places on the last one
	
			if (comma.indexOf(".") == 3)
				lenck = 6					
			if (comma == "")
				break;
			if (comma.length != lenck) {
				alert ("Invalid Amount Format " )
				field.focus();
				return(false);
			}
		}
	}

	var isdec = field.value.indexOf(".")
	var lisdec = field.value.lastIndexOf(".")

	if (isdec > 0 ) {
		comma = word(".",3,field.value)
		if (comma != "") {
			alert ("Invalid Format");
			field.focus();
			return (false);
		}
	}
		
	decpos = -1;
	
	for (var i = 0; i < field.value.length ; i++) {
		var achar = field.value.charAt(i);
		
		var t = x.indexOf(achar)
		if (t == -1 ) {
			alert ("Non numeric characters entered")
			field.focus();
			return ( false );
		}
		if (t == 1) {	
			decpos = i;
		}

	}
	if ((decplaces == 2) || (decplaces == null)) {
		if ((decpos > 0) && (decpos != field.value.length - 3)) {
			alert ("Two decimal positions required")
			field.focus();
			return (false);
		}
	} 
	else {
		if ((decpos >= 0) && (field.value.length - (decpos+1) > decplaces)) {
			alert ("Too many decimal positions entered");
			field.focus();
			return (false);
		}
	}
	return ( true );

}

function chkNumeric(field, sDescription) {
    var sValidChars = "1234567890"
	var sMsg = '';

	if(field.value.length == 0)
		return(true);

	sMsg = FindInvalidChars(field, sValidChars)
	if (sMsg != "") {
	    sMsg = "The " + sDescription + " data includes the following disallowed character(s):\n" + sMsg + "\n Please replace these before continuing."
	    alert(sMsg);
	    field.focus();
	    return (false)
	}
	else {
	    return (true);
	}
}
function goHome(depth) {
	var temp = "";

	if(depth > 0) {
		for(var count = 0; count < depth; count++) {
			temp += "../";
		}
	}
	self.location = temp + "bank.asp?WCI=MainPage";
}

function putDateTogether(year, month, day) {
	if(month == "") {
		return;
	}
	if(month < 1 || month > 12) {
		alert("Invalid month.")
		return;
	}
	var d
	d = new Date(year, month - 1, day)
	if(day > 31 || day < 0 || d.getDate() != day) {
		alert("Invalid day.")
		return;
	}
	return d;
}
function parseFixedDateGeneric(dateStr, partOrder, yearSize, monthSize, daySize) {
	var year;
	var month;
	var day;
	var partNum;
	var i;
	i=0;
	for(partNum=0;partNum<3;partNum++) {
		if(partOrder.charAt(partNum) == "Y") {
			year = fixYear(dateStr.substr(i, yearSize)); i+=yearSize;
		} else if(partOrder.charAt(partNum) == "M") {
			month = fixMonth(dateStr.substr(i, monthSize)); i+=monthSize;
		} else if(partOrder.charAt(partNum) == "D") {
			day = dateStr.substr(i, daySize); i+=daySize;
		} else {
			alert("Invalid date part in " + partOrder);
		}
	}
	return putDateTogether(year, month, day);
}
function parseDateGeneric(dateStr, partOrder, dateType) {
	dateStr = stripCharsNotInBag(dateStr, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz/-");

	if(strIsAlphaNum(dateStr)) {
		if(dateStr.length == 6) {
			return parseFixedDateGeneric(dateStr, partOrder, 2, 2, 2)
		} else if(dateStr.length == 8) {
			return parseFixedDateGeneric(dateStr, partOrder, 4, 2, 2)
		} else if(dateStr.length == 7) {
			return parseFixedDateGeneric(dateStr, partOrder, 2, 3, 2)
		} else if(dateStr.length == 9) {
			return parseFixedDateGeneric(dateStr, partOrder, 4, 3, 2)
		} else {
			alert("Invalid date.  Date format is " + dateType);
			return;
		}
	} else {
		// Convert variable length formats
		var dateArray;
		dateArray = dateStr.split('/');
		if(dateArray.length != 3) {
			dateArray = dateStr.split('-');
			if(dateArray.length != 3) {
				alert("Invalid date.  Date format is " + dateType);
				return;
			}
		}

		var year;
		var month;
		var day;
		var partNum;
		for(partNum=0;partNum<3;partNum++) {
			if(partOrder.charAt(partNum) == "Y") {
				year = fixYear(dateArray[partNum]);
			} else if(partOrder.charAt(partNum) == "M") {
				month = fixMonth(dateArray[partNum]);
			} else if(partOrder.charAt(partNum) == "D") {
				day = dateArray[partNum];
			} else {
				alert("Invalid date part in " + partOrder);
			}
		}

		return putDateTogether(year, month, day);
	}
}

function checkdate(dateField) {
	return chkdate(dateField, 'MM/DD/YYYY');
}
function chkdate(field, dateType) {
	if(field.value == '') {
		return true;
	}

	var actualDate;
	actualDate = getDate(field, dateType);
	if(actualDate == null) {
		field.focus();
		return false;
	} else {
		setDateField(field, dateType, actualDate);
		return true;
	}
}
function formatDate(actualDate, dateType) {
	if(dateType.toUpperCase () == 'MM/DD/YYYY') {
		return padZeroes(actualDate.getMonth() + 1, 2)
		        + "/" + padZeroes(actualDate.getDate(), 2)
		        + "/" + padZeroes(actualDate.getFullYear(), 4);
	}  else if(dateType.toUpperCase () == 'DD/MM/YYYY') {
		return padZeroes(actualDate.getDate(), 2)
		        + "/" + padZeroes(actualDate.getMonth() + 1, 2)
		        + "/" + padZeroes(actualDate.getFullYear(), 4);
	}  else if(dateType.toUpperCase () == 'DD-MMM-YYYY') {
		return padZeroes(actualDate.getDate(), 2)
		        + "-" + getMonthString(actualDate.getMonth() + 1)
		        + "-" + padZeroes(actualDate.getFullYear(), 4);
	} else {
        	alert("Unrecognized format " + dateType.toUpperCase ());
        	return;
	}
}
function setDateField(field, dateType, actualDate) {
	var newDate = formatDate(actualDate, dateType);

	if(field.value != newDate) {
		field.value = newDate;
	}
}
function getDate(field, dateType) {
		var dateStr = field.value

        if(dateType.toUpperCase () == 'MM/DD/YYYY') {
        	return parseDateGeneric(dateStr, "MDY", dateType)
        } else if(dateType.toUpperCase () == 'DD/MM/YYYY') {
        	return parseDateGeneric(dateStr, "DMY", dateType)
        } else if(dateType.toUpperCase () == 'DD-MMM-YYYY') {
        	return parseDateGeneric(dateStr, "DMY", dateType)
        } else {
        	alert("Unrecognized format " + dateType.toUpperCase ())
        	return;
        }
}
function fixMonth(val) {
	if(!isNaN(parseInt(val))) {
		return val;
	}
	switch(val.toUpperCase()) {
		case "JAN":
			return "1";
		case "FEB":
			return "2";
		case "MAR":
			return "3";
		case "APR":
			return "4";
		case "MAY":
			return "5";
		case "JUN":
			return "6";
		case "JUL":
			return "7";
		case "AUG":
			return "8";
		case "SEP":
			return "9";
		case "OCT":
			return "10";
		case "NOV":
			return "11";
		case "DEC":
			return "12";
	}

	alert("Invalid month " + val + ".");
	return "";
}
function fixYear(val) {
	var year;
	year = parseInt(val, 10);
	if(isNaN(year)) {
		return "";
	}

	if(year < 70) {
		year = year + 2000;
	} else if(year < 100) {
		year = year + 1900;
	}

	return new String(year);
}
function stripCharsNotInBag (s, bag)
{   var i;
    var returnString = "";

    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (bag.indexOf(c) != -1) returnString += c;
    }

    return returnString;
}
function isNum(c) {
	return (c >= '0' && c <= '9');
}
function isAlpha(c) {
	return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}
function strIsAlphaNum(s) {
	var i;
	for(i=0; i<s.length; i++) {
		if(!isAlpha(s.charAt(i)) && !isNum(s.charAt(i))) {
			return false;
		}
	}
	return true;
}
function padZeroes(val, totalLength) {
	val = new String(val);
	var i;
	
	for(i=0; i<totalLength-val.length; i++) {
		val = "0" + val;
	}
    
	return val;
}
