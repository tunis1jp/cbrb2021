-- Add Standby Drafting
Declare @LE varchar(2)
Declare @Service VarChar(3)
Declare @ServiceDesc VarChar(35)
Declare @Product VarChar(3)
Declare @ProductDesc VarChar(35)


Set @Service = 'STB'
Set @ServiceDesc = (select ServiceDesc from ServiceProduct where Service = @Service and Product = 'iss')
set @Product = 'DRF'
set @ProductDesc = 'Draft'

--Need the below changed for each LE at Bank
Set @LE = 'TD'
INSERT [dbo].[ServiceProduct] ([LegalEntity], [Service], [ServiceDesc], [Product], [ProductDesc], [Active], [AutoAssign], [Category], [ServiceType], [WipItem], [SortOrder], [InqOptions], [IMPR], [validDept], [NoJumping], [AMLStatus], [DetailedDescription], [ReturnForCorrection]) VALUES (@LE, @Service, @ServiceDesc, @Product, @ProductDesc, 1, 0, N'', N'', N'X', 0, 16, N'', N'', N'N', 0, N'', 0)
