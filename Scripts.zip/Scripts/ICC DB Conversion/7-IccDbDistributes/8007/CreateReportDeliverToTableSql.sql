/* ******************************************* */

/* Report Deliver To Table */

/* ******************************************* */
BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT *
           FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_TYPE='BASE TABLE'
           AND TABLE_NAME='ReportDeliverTo') 
			BEGIN 
                CREATE TABLE ReportDeliverTo(
                                DeliverToPkey INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
                                UsersFkey INT NOT NULL Constraint DF_ReportDeliverTo_UsersFkey DEFAULT (0),
                                ReportSchedulerFkey INT NOT NULL Constraint DF_ReportDeliverTo_ReportSchedulerFkey DEFAULT (0),
                                BankCustomer varchar(64) NOT NULL CONSTRAINT DF_ReportDeliverTo_BankCustomer DEFAULT ('')
                );
                CREATE  INDEX IX_ReportDeliverTo_DeliverToPkey ON ReportDeliverTo(DeliverToPkey);
                print 'Created ReportDeliverTo table'
			END
			ELSE BEGIN
                print 'ReportDeliverTo table already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error creating table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH