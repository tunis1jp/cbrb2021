﻿function CheckDisabled(chk) {
    chk.checked = true
}

function CheckAll(master) {
    var iCnt;
    var checked = master.checked;
    
    chkApps = document.getElementsByName("chkApplications");
	iCnt = chkApps.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        chkApps[iIdx].checked = checked;
    }
}
